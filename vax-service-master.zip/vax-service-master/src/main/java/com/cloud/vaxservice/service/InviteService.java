package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.InviteQueryParamDTO;
import com.cloud.vaxservice.entity.Invite;

import java.util.Date;
import java.util.List;

/**
 * 邀请服务接口
 *
 * @author feng
 * @since 2022/09/24
 */
public interface InviteService extends IService<Invite> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Invite> query(InviteQueryParamDTO paramDTO);

    List<Invite> listByDate(Date date);

    Invite getByInviteeId(Long inviteeId);

    boolean exist(Long userId);
}
