package com.cloud.gateway.bean;

import lombok.Data;

@Data
public class ReleaseInfo {

    private String version;
    private String userId;
    private String userArea;

}
