package com.cloud.vaxservice.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;
import javax.validation.constraints.NotNull;

/**
 * 分享查询参数
 *
 * @author feng
 * @since 2022/06/11
 */
@Data
public class ShareQueryParamDTO {
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 文章ID
     */
    private Integer articleId;

    /**
     * 页码（1~100之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 100, message = "页码（1~100之间）")
    private Integer pageNo;

    /**
     * 分页大小（1~100之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 1, max = 100, message = "分页大小（1~100之间）")
    private Integer pageSize;
}