package com.cloud.gateway.bean;

import lombok.Data;

@Data
public class FrequencyLimit {

    private String requestURI;
    private int limitCount;
    private int timeSeconds;

}
