package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/09/27
 */
@Data
public class TetrisCanPlayDTO {
    /**
     * 是否可以
     */
    private boolean enable;

    /**
     * 失败消息
     */
    private String failureMsg;
}
