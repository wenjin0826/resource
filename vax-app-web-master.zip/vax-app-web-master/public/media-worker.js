var jz = jz || {}, mp4js, Flv, getBox, getString, getUint16BE, getUint16LE, getUint24BE, getUint24LE, getUint32BE,
    getUint32LE, newArray, putString, putUint16BE, putUint16LE, putUint24BE, putUint24LE, putUint32BE, putUint32LE, mp4,
    swf;
jz.zip = jz.zip || {};
jz.zip.LOCAL_FILE_SIGNATURE = 67324752;
jz.zip.CENTRAL_DIR_SIGNATURE = 33639248;
jz.zip.END_SIGNATURE = 101010256;
jz.BlobBuilder;
jz.utils = jz.utils || {}, function (n, t) {
    t.utils.arrayBufferToBytes = function (n) {
        return n.constructor === Uint8Array ? n : new Uint8Array(n);
    };
    t.utils.stringToArrayBuffer = function (n) {
        for (var e = n.length, r = -1, i = [], u, t, f = 0; f < e; ++f) if (t = n.charCodeAt(f), 127 >= t) i[++r] = t; else if (2047 >= t) i[++r] = 192 | t >>> 6, i[++r] = 128 | t & 63; else if (65535 >= t) i[++r] = 224 | t >>> 12, i[++r] = 128 | t >>> 6 & 63, i[++r] = 128 | t & 63; else {
            for (u = 4; t >> 6 * u;) ++u;
            for (i[++r] = 65280 >>> u & 255 | t >>> 6 * --u; u--;) i[++r] = 128 | t >>> 6 * u & 63;
        }
        return new Uint8Array(i).buffer;
    };
    t.utils.readUintLE = function (n, i) {
        return n = t.utils.arrayBufferToBytes(n), n[i] | n[i + 1] << 8 | n[i + 2] << 16 | n[i + 3] << 24;
    };
    t.utils.readUshortLE = function (n, i) {
        return n = t.utils.arrayBufferToBytes(n), n[i] | n[i + 1] << 8;
    };
    t.utils.readUintBE = function (n, i) {
        return n = t.utils.arrayBufferToBytes(n), n[i + 3] | n[i + 2] << 8 | n[i + 1] << 16 | n[i] << 24;
    };
    t.utils.readUshortBE = function (n, i) {
        return n = t.utils.arrayBufferToBytes(n), n[i + 1] | n[i] << 8;
    };
    t.utils.readString = function (n, i, r) {
        for (var f = '', n = t.utils.arrayBufferToBytes(n), u = i, i = i + r; u < i; ++u) f += String.fromCharCode(n[u]);
        return f;
    };
    t.utils.loadFileBuffer = function (n) {
        var t = new XMLHttpRequest;
        return t.open('GET', n, !1), t.setRequestHeader('If-Modified-Since', '01 Jan 1970 00:00:00 GMT'), t.responseType = 'arraybuffer', t.send(), t.response;
    };
}(this, jz);
jz.algorithms = jz.algorithms || {};
jz.algorithms.adler32 = function (n) {
    for (var n = jz.utils.arrayBufferToBytes(n), t = 1, r = 0, f = 0, i = n.length, u; 0 < i;) {
        u = 5550 < i ? 5550 : i;
        i -= u;
        do t += n[f++], r += t; while (--u);
        t %= 65521;
        r %= 65521;
    }
    return r << 16 | t;
};
jz.algorithms = jz.algorithms || {};
jz.algorithms.crc32 = function () {
    var n = function () {
        for (var r = new Uint32Array(new ArrayBuffer(1024)), n, i, t = 0; 256 > t; ++t) {
            for (n = t, i = 0; 8 > i; ++i) n = n & 1 ? n >>> 1 ^ 3988292384 : n >>> 1;
            r[t] = n;
        }
        return r;
    }();
    return function (t) {
        for (var i = 4294967295, t = jz.utils.arrayBufferToBytes(t), r = 0, u = t.length; r < u; ++r) i = i >>> 8 ^ n[t[r] ^ i & 255];
        return ~i;
    };
}();
jz.algorithms = jz.algorithms || {}, function (n) {
    var ct, e, ri, pi, lt = null, h, o, ui, t, wi, bi, p, st, w, nt, b, ht, or, bt, r, a, i, kt, tt, f, sr, ki, at, hr,
        k, it, rt, vt, s, v, y, ut, c, u, ft, pt, d, dt, yt, di, fi, ei, et, oi, gi, gt, si, wt, hi, ci, nr,
        ni = function () {
            this.dl = this.fc = 0;
        }, tr = function () {
            this.extra_bits = this.static_tree = this.dyn_tree = null;
            this.max_code = this.max_length = this.elems = this.extra_base = 0;
        }, g = function (n, t, i, r) {
            this.good_length = n;
            this.max_lazy = t;
            this.nice_length = i;
            this.max_chain = r;
        }, tu = function () {
            this.next = null;
            this.len = 0;
            this.ptr = new Uint8Array(8192);
            this.off = 0;
        }, ir = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]),
        ti = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
        iu = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]),
        cr = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
        rr = [new g(0, 0, 0, 0), new g(4, 4, 8, 4), new g(4, 5, 16, 8), new g(4, 6, 32, 32), new g(4, 4, 16, 16), new g(8, 16, 32, 32), new g(8, 16, 128, 128), new g(8, 32, 128, 256), new g(32, 128, 258, 1024), new g(32, 258, 258, 4096)],
        li = function (n) {
            if (lt[o + h++] = n, 8192 === o + h && 0 !== h) {
                var t;
                for (null != ct ? (n = ct, ct = ct.next) : n = new tu, n.next = null, n.len = n.off = 0, null == e ? e = ri = n : ri = ri.next = n, n.len = h - o, t = 0; t < n.len; t++) n.ptr[t] = lt[o + t];
                h = o = 0;
            }
        }, ai = function (n) {
            n &= 65535;
            8190 > o + h ? (lt[o + h++] = n & 255, lt[o + h++] = n >>> 8) : (li(n & 255), li(n >>> 8));
        }, vi = function () {
            b = (b << 5 ^ t[i + 3 - 1] & 255) & 8191;
            ht = p[32768 + b];
            p[i & 32767] = ht;
            p[32768 + b] = i;
        }, ot = function (n, t) {
            l(t[n].fc, t[n].dl);
        }, lr = function (n, t, i) {
            return n[t].fc < n[i].fc || n[t].fc === n[i].fc && d[t] <= d[i];
        }, ar = function (n, t, i) {
            for (var r = 0; r < i && nr < ci.length; r++) n[t + r] = ci[nr++];
            return r;
        }, vr = function (n) {
            var o = sr, r = i, u, f = a, c = 32506 < i ? i - 32506 : 0, e = i + 258, s = t[r + f - 1], h = t[r + f];
            a >= hr && (o >>= 2);
            do if (u = n, !(t[u + f] !== h || t[u + f - 1] !== s || t[u] !== t[r] || t[++u] !== t[r + 1])) {
                r += 2;
                u++;
                do ; while (t[++r] === t[++u] && t[++r] === t[++u] && t[++r] === t[++u] && t[++r] === t[++u] && t[++r] === t[++u] && t[++r] === t[++u] && t[++r] === t[++u] && t[++r] === t[++u] && r < e);
                if (u = 258 - (e - r), r = e - 258, u > f) {
                    if (kt = n, f = u, 258 <= u) break;
                    s = t[r + f - 1];
                    h = t[r + f];
                }
            } while ((n = p[n & 32767]) > c && 0 != --o);
            return f;
        }, ur = function () {
            var n, r, u = 65536 - f - i;
            if (-1 === u) u--; else if (65274 <= i) {
                for (n = 0; 32768 > n; n++) t[n] = t[n + 32768];
                for (kt -= 32768, i -= 32768, nt -= 32768, n = 0; 8192 > n; n++) r = p[32768 + n], p[32768 + n] = 32768 <= r ? r - 32768 : 0;
                for (n = 0; 32768 > n; n++) r = p[n], p[n] = 32768 <= r ? r - 32768 : 0;
                u += 32768;
            }
            tt || (n = ar(t, i + f, u), 0 >= n ? tt = !0 : f += n);
        }, ru = function (n, u, l) {
            var d, ft, g;
            if (!pi) {
                if (!tt) {
                    if (w = st = 0, 0 === vt[0].dl) {
                        for (v.dyn_tree = k, v.static_tree = rt, v.extra_bits = ir, v.extra_base = 257, v.elems = 286, v.max_length = 15, v.max_code = 0, y.dyn_tree = it, y.static_tree = vt, y.extra_bits = ti, y.extra_base = 0, y.elems = 30, y.max_length = 15, y.max_code = 0, ut.dyn_tree = s, ut.static_tree = null, ut.extra_bits = iu, ut.extra_base = 0, ut.elems = 19, ut.max_length = 7, g = ft = ut.max_code = 0; 28 > g; g++) for (di[g] = ft, d = 0; d < 1 << ir[g]; d++) dt[ft++] = g;
                        for (dt[ft - 1] = g, g = ft = 0; 16 > g; g++) for (fi[g] = ft, d = 0; d < 1 << ti[g]; d++) yt[ft++] = g;
                        for (ft >>= 7; 30 > g; g++) for (fi[g] = ft << 7, d = 0; d < 1 << ti[g] - 7; d++) yt[256 + ft++] = g;
                        for (d = 0; 15 >= d; d++) c[d] = 0;
                        for (d = 0; 143 >= d;) rt[d++].dl = 8, c[8]++;
                        for (; 255 >= d;) rt[d++].dl = 9, c[9]++;
                        for (; 279 >= d;) rt[d++].dl = 7, c[7]++;
                        for (; 287 >= d;) rt[d++].dl = 8, c[8]++;
                        for (wr(rt, 287), d = 0; 30 > d; d++) vt[d].dl = 5, vt[d].fc = gr(d, 5);
                        pr();
                    }
                    for (d = 0; 8192 > d; d++) p[32768 + d] = 0;
                    if (ki = rr[at].max_lazy, hr = rr[at].good_length, sr = rr[at].max_chain, nt = i = 0, f = ar(t, 0, 65536), 0 >= f) tt = !0, f = 0; else {
                        for (tt = !1; 262 > f && !tt;) ur();
                        for (d = b = 0; 2 > d; d++) b = (b << 5 ^ t[d] & 255) & 8191;
                    }
                    e = null;
                    o = h = 0;
                    3 >= at ? (a = 2, r = 0) : (r = 2, bt = 0);
                    ui = !1;
                }
                if (pi = !0, 0 === f) return ui = !0, 0;
            }
            if ((d = yr(n, u, l)) === l) return l;
            if (ui) return d;
            if (3 >= at) for (; 0 !== f && null == e;) {
                if (vi(), 0 != ht && 32506 >= i - ht && (r = vr(ht), r > f && (r = f)), 3 <= r) if (g = ii(i - kt, r - 3), f -= r, r <= ki) {
                    r--;
                    do i++, vi(); while (0 != --r);
                    i++;
                } else i += r, r = 0, b = t[i] & 255, b = (b << 5 ^ t[i + 1] & 255) & 8191; else g = ii(0, t[i] & 255), f--, i++;
                for (g && (yi(0), nt = i); 262 > f && !tt;) ur();
            } else for (; 0 !== f && null == e;) {
                if (vi(), a = r, or = kt, r = 2, 0 != ht && a < ki && 32506 >= i - ht && (r = vr(ht), r > f && (r = f), 3 === r && 4096 < i - kt && r--), 3 <= a && r <= a) {
                    g = ii(i - 1 - or, a - 3);
                    f -= a - 1;
                    a -= 2;
                    do i++, vi(); while (0 != --a);
                    bt = 0;
                    r = 2;
                    i++;
                    g && (yi(0), nt = i);
                } else 0 !== bt ? ii(0, t[i - 1] & 255) && (yi(0), nt = i) : bt = 1, i++, f--;
                for (; 262 > f && !tt;) ur();
            }
            return 0 === f && (0 !== bt && ii(0, t[i - 1] & 255), yi(1), ui = !0), d + yr(n, d + u, l - d);
        }, yr = function (n, t, i) {
            for (var r, f, u = 0; null != e && u < i;) {
                for (r = i - u, r > e.len && (r = e.len), f = 0; f < r; f++) n[t + u + f] = e.ptr[e.off + f];
                e.off += r;
                e.len -= r;
                u += r;
                0 === e.len && (r = e, e = e.next, r.next = ct, ct = r);
            }
            if (u === i) return u;
            if (o < h) {
                for (r = i - u, r > h - o && (r = h - o), f = 0; f < r; f++) n[t + u + f] = lt[o + f];
                o += r;
                u += r;
                h === o && (h = o = 0);
            }
            return u;
        }, pr = function () {
            for (var n = 0; 286 > n; n++) k[n].fc = 0;
            for (n = 0; 30 > n; n++) it[n].fc = 0;
            for (n = 0; 19 > n; n++) s[n].fc = 0;
            k[256].fc = 1;
            gt = et = oi = gi = wt = hi = 0;
            si = 1;
        }, fr = function (n, t) {
            for (var r = u[t], i = t << 1; i <= ft;) {
                if (i < ft && lr(n, u[i + 1], u[i]) && i++, lr(n, r, u[i])) break;
                u[t] = u[i];
                t = i;
                i <<= 1;
            }
            u[t] = r;
        }, wr = function (n, t) {
            for (var u = Array(16), r = 0, i = 1; 15 >= i; i++) r = r + c[i - 1] << 1, u[i] = r;
            for (r = 0; r <= t; r++) i = n[r].dl, 0 != i && (n[r].fc = gr(u[i]++, i));
        }, er = function (n) {
            var f = n.dyn_tree, o = n.static_tree, l = n.elems, t, s = -1, r = l;
            for (ft = 0, pt = 573, t = 0; t < l; t++) 0 !== f[t].fc ? (u[++ft] = s = t, d[t] = 0) : f[t].dl = 0;
            for (; 2 > ft;) t = u[++ft] = 2 > s ? ++s : 0, f[t].fc = 1, d[t] = 0, wt--, null != o && (hi -= o[t].dl);
            for (n.max_code = s, t = ft >> 1; 1 <= t; t--) fr(f, t);
            do t = u[1], u[1] = u[ft--], fr(f, 1), o = u[1], u[--pt] = t, u[--pt] = o, f[r].fc = f[t].fc + f[o].fc, d[r] = d[t] > d[o] + 1 ? d[t] : d[o] + 1, f[t].dl = f[o].dl = r, u[1] = r++, fr(f, 1); while (2 <= ft);
            u[--pt] = u[1];
            r = n.dyn_tree;
            t = n.extra_bits;
            for (var l = n.extra_base, o = n.max_code, h = n.max_length, p = n.static_tree, e, a, y, v = 0, i = 0; 15 >= i; i++) c[i] = 0;
            for (r[u[pt]].dl = 0, n = pt + 1; 573 > n; n++) e = u[n], i = r[r[e].dl].dl + 1, i > h && (i = h, v++), r[e].dl = i, e > o || (c[i]++, a = 0, e >= l && (a = t[e - l]), y = r[e].fc, wt += y * (i + a), null != p && (hi += y * (p[e].dl + a)));
            if (0 != v) {
                do {
                    for (i = h - 1; 0 == c[i];) i--;
                    c[i]--;
                    c[i + 1] += 2;
                    c[h]--;
                    v -= 2;
                } while (0 < v);
                for (i = h; 0 !== i; i--) for (e = c[i]; 0 !== e;) t = u[--n], t > o || (r[t].dl !== i && (wt += (i - r[t].dl) * r[t].fc, r[t].fc = i), e--);
            }
            wr(f, s);
        }, br = function (n, t) {
            var o, h = -1, i, r = n[0].dl, u = 0, f = 7, e = 4;
            for (0 == r && (f = 138, e = 3), n[t + 1].dl = 65535, o = 0; o <= t; o++) i = r, r = n[o + 1].dl, ++u < f && i == r || (u < e ? s[i].fc += u : 0 !== i ? (i !== h && s[i].fc++, s[16].fc++) : 10 >= u ? s[17].fc++ : s[18].fc++, u = 0, h = i, 0 == r ? (f = 138, e = 3) : i == r ? (f = 6, e = 3) : (f = 7, e = 4));
        }, kr = function (n, t) {
            var o, h = -1, r, u = n[0].dl, i = 0, f = 7, e = 4;
            for (0 == u && (f = 138, e = 3), o = 0; o <= t; o++) if (r = u, u = n[o + 1].dl, !(++i < f && r == u)) {
                if (i < e) {
                    do ot(r, s); while (0 != --i);
                } else 0 !== r ? (r !== h && (ot(r, s), i--), ot(16, s), l(i - 3, 2)) : 10 >= i ? (ot(17, s), l(i - 3, 3)) : (ot(18, s), l(i - 11, 7));
                i = 0;
                h = r;
                0 == u ? (f = 138, e = 3) : r == u ? (f = 6, e = 3) : (f = 7, e = 4);
            }
        }, yi = function (n) {
            var u, f, r, e;
            for (e = i - nt, ei[gi] = gt, er(v), er(y), br(k, v.max_code), br(it, y.max_code), er(ut), r = 18; 3 <= r && !(0 !== s[cr[r]].dl); r--) ;
            if (wt += 3 * (r + 1) + 14, u = wt + 3 + 7 >> 3, f = hi + 3 + 7 >> 3, f <= u && (u = f), e + 4 <= u && 0 <= nt) for (l(0 + n, 3), nu(), ai(e), ai(~e), r = 0; r < e; r++) li(t[nt + r]); else if (f == u) l(2 + n, 3), dr(rt, vt); else {
                for (l(4 + n, 3), e = v.max_code + 1, u = y.max_code + 1, r += 1, l(e - 257, 5), l(u - 1, 5), l(r - 4, 4), f = 0; f < r; f++) l(s[cr[f]].dl, 3);
                kr(k, e - 1);
                kr(it, u - 1);
                dr(k, it);
            }
            pr();
            0 !== n && nu();
        }, ii = function (n, t) {
            if (bi[et++] = t, 0 == n ? k[t].fc++ : (n--, k[dt[t] + 256 + 1].fc++, it[(256 > n ? yt[n] : yt[256 + (n >> 7)]) & 255].fc++, wi[oi++] = n, gt |= si), si <<= 1, 0 == (et & 7) && (ei[gi++] = gt, gt = 0, si = 1), 2 < at && 0 == (et & 4095)) {
                for (var u = 8 * et, f = i - nt, r = 0; 30 > r; r++) u += it[r].fc * (5 + ti[r]);
                if (u >>= 3, oi < parseInt(et / 2) && u < parseInt(f / 2)) return !0;
            }
            return 8191 == et || 8192 == oi;
        }, dr = function (n, t) {
            var i, f = 0, o = 0, s = 0, e = 0, r, u;
            if (0 !== et) do 0 == (f & 7) && (e = ei[s++]), i = bi[f++] & 255, 0 == (e & 1) ? ot(i, n) : (r = dt[i], ot(r + 256 + 1, n), u = ir[r], 0 !== u && (i -= di[r], l(i, u)), i = wi[o++], r = (256 > i ? yt[i] : yt[256 + (i >> 7)]) & 255, ot(r, t), u = ti[r], 0 !== u && (i -= fi[r], l(i, u))), e >>= 1; while (f < et);
            ot(256, n);
        }, l = function (n, t) {
            w > 16 - t ? (st |= n << w, ai(st), st = n >> 16 - w, w += t - 16) : (st |= n << w, w += t);
        }, gr = function (n, t) {
            var i = 0;
            do i |= n & 1, n >>= 1, i <<= 1; while (0 < --t);
            return i >> 1;
        }, nu = function () {
            8 < w ? ai(st) : 0 < w && li(st);
            w = st = 0;
        };
    n.algorithms.deflate = function (i, r) {
        var f, o, h, l;
        if (ci = n.utils.arrayBufferToBytes(i), nr = 0, 'undefined' == typeof r && (r = 6), (f = r) ? 1 > f ? f = 1 : 9 < f && (f = 9) : f = 6, at = f, tt = pi = !1, null == lt) {
            for (ct = e = ri = null, lt = new Uint8Array(8192), t = new Uint8Array(65536), wi = Array(8192), bi = Array(32832), p = Array(65536), k = Array(573), f = 0; 573 > f; f++) k[f] = new ni;
            for (it = Array(61), f = 0; 61 > f; f++) it[f] = new ni;
            for (rt = Array(288), f = 0; 288 > f; f++) rt[f] = new ni;
            for (vt = Array(30), f = 0; 30 > f; f++) vt[f] = new ni;
            for (s = Array(39), f = 0; 39 > f; f++) s[f] = new ni;
            v = new tr;
            y = new tr;
            ut = new tr;
            c = Array(16);
            u = Array(573);
            d = Array(573);
            dt = Array(256);
            yt = Array(512);
            di = Array(29);
            fi = Array(30);
            ei = Array(1024);
        }
        for (h = new Uint8Array(1024), l = []; 0 < (f = ru(h, 0, h.length));) for (o = 0; o < f; o++) l[l.length] = h[o];
        return ci = null, new Uint8Array(l).buffer;
    };
}(jz);
jz.algorithms = jz.algorithms || {}, function (n) {
    function it() {
        this.list = this.next = null;
    }

    function rt() {
        this.n = this.b = this.e = 0;
        this.t = null;
    }

    function y(n, t, i, r, u, f) {
        var l, k, nt, d, tt;
        this.BMAX = 16;
        this.N_MAX = 288;
        this.status = 0;
        this.root = null;
        this.m = 0;
        var v = Array(this.BMAX + 1), ft, p, ut, s, e, o, w, b = Array(this.BMAX + 1), y, a, c, h = new rt,
            g = Array(this.BMAX);
        for (s = Array(this.N_MAX), k = Array(this.BMAX + 1), tt = this.root = null, e = 0; e < v.length; e++) v[e] = 0;
        for (e = 0; e < b.length; e++) b[e] = 0;
        for (e = 0; e < g.length; e++) g[e] = null;
        for (e = 0; e < s.length; e++) s[e] = 0;
        for (e = 0; e < k.length; e++) k[e] = 0;
        ft = 256 < t ? n[256] : this.BMAX;
        y = n;
        a = 0;
        e = t;
        do v[y[a]]++, a++; while (0 < --e);
        if (v[0] === t) this.root = null, this.status = this.m = 0; else {
            for (o = 1; o <= this.BMAX && !(0 !== v[o]); o++) ;
            for (w = o, f < o && (f = o), e = this.BMAX; 0 !== e && !(0 !== v[e]); e--) ;
            for (ut = e, f > e && (f = e), nt = 1 << o; o < e; o++, nt <<= 1) if (0 > (nt -= v[o])) {
                this.status = 2;
                this.m = f;
                return;
            }
            if (0 > (nt -= v[e])) this.status = 2, this.m = f; else {
                for (v[e] += nt, k[1] = o = 0, y = v, a = 1, c = 2; 0 < --e;) k[c++] = o += y[a++];
                y = n;
                e = a = 0;
                do 0 !== (o = y[a++]) && (s[k[o]++] = e); while (++e < t);
                for (t = k[ut], k[0] = e = 0, y = s, a = 0, s = -1, l = b[0] = 0, c = null, d = 0; w <= ut; w++) for (n = v[w]; 0 < n--;) {
                    for (; w > l + b[1 + s];) {
                        if (l += b[1 + s], s++, d = (d = ut - l) > f ? f : d, (p = 1 << (o = w - l)) > n + 1) for (p -= n + 1, c = w; ++o < d && !((p <<= 1) <= v[++c]);) p -= v[c];
                        for (l + o > ft && l < ft && (o = ft - l), d = 1 << o, b[1 + s] = o, c = Array(d), p = 0; p < d; p++) c[p] = new rt;
                        tt = null == tt ? this.root = new it : tt.next = new it;
                        tt.next = null;
                        tt.list = c;
                        g[s] = c;
                        0 < s && (k[s] = e, h.b = b[s], h.e = 16 + o, h.t = c, o = (e & (1 << l) - 1) >> l - b[s], g[s - 1][o].e = h.e, g[s - 1][o].b = h.b, g[s - 1][o].n = h.n, g[s - 1][o].t = h.t);
                    }
                    for (h.b = w - l, a >= t ? h.e = 99 : y[a] < i ? (h.e = 256 > y[a] ? 16 : 15, h.n = y[a++]) : (h.e = u[y[a] - i], h.n = r[y[a++] - i]), p = 1 << w - l, o = e >> l; o < d; o += p) c[o].e = h.e, c[o].b = h.b, c[o].n = h.n, c[o].t = h.t;
                    for (o = 1 << w - 1; 0 != (e & o); o >>= 1) e ^= o;
                    for (e ^= o; (e & (1 << l) - 1) !== k[s];) l -= b[s], s--;
                }
                this.m = b[1];
                this.status = 0 !== nt && 1 !== ut ? 1 : 0;
            }
        }
    }

    function i(n) {
        for (; a < n;) p |= (g.length === tt ? -1 : g[tt++]) << a, a += 8;
    }

    function r(n) {
        return p & pt[n];
    }

    function t(n) {
        p >>= n;
        a -= n;
    }

    function b(n, a, y) {
        var p, w, b;
        if (0 === y) return 0;
        for (b = 0; ;) {
            for (i(e), w = h.list[r(e)], p = w.e; 16 < p;) {
                if (99 === p) return -1;
                t(w.b);
                p -= 16;
                i(p);
                w = w.t[r(p)];
                p = w.e;
            }
            if (t(w.b), 16 === p) f &= c - 1, n[a + b++] = o[f++] = w.n; else {
                if (15 === p) break;
                for (i(p), u = w.n + r(p), t(p), i(l), w = nt.list[r(l)], p = w.e; 16 < p;) {
                    if (99 === p) return -1;
                    t(w.b);
                    p -= 16;
                    i(p);
                    w = w.t[r(p)];
                    p = w.e;
                }
                for (t(w.b), i(p), v = f - w.n - r(p), t(p); 0 < u && b < y;) u--, v &= c - 1, f &= c - 1, n[a + b++] = o[f++] = o[v++];
            }
            if (b === y) return y;
        }
        return s = -1, b;
    }

    function ct(n, u, f) {
        for (var o, p, w, k, a, v, c = Array(316), s = 0; s < c.length; s++) c[s] = 0;
        if (i(5), a = 257 + r(5), t(5), i(5), v = 1 + r(5), t(5), i(4), s = 4 + r(4), t(4), 286 < a || 30 < v) return -1;
        for (o = 0; o < s; o++) i(3), c[ht[o]] = r(3), t(3);
        for (; 19 > o; o++) c[ht[o]] = 0;
        if (e = 7, o = new y(c, 19, 19, null, null, e), 0 !== o.status) return -1;
        for (h = o.root, e = o.m, w = a + v, s = p = 0; s < w;) if (i(e), k = h.list[r(e)], o = k.b, t(o), o = k.n, 16 > o) c[s++] = p = o; else if (16 === o) {
            if (i(2), o = 3 + r(2), t(2), s + o > w) return -1;
            for (; 0 < o--;) c[s++] = p;
        } else {
            if (17 === o ? (i(3), o = 3 + r(3), t(3)) : (i(7), o = 11 + r(7), t(7)), s + o > w) return -1;
            for (; 0 < o--;) c[s++] = 0;
            p = 0;
        }
        if (e = vt, o = new y(c, a, 257, ft, et, e), 0 === e && (o.status = 1), 0 !== o.status) return -1;
        for (h = o.root, e = o.m, s = 0; s < v; s++) c[s] = c[s + a];
        return l = yt, o = new y(c, v, 0, ot, st, l), nt = o.root, l = o.m, 0 === l && 257 < a || 0 !== o.status ? -1 : b(n, u, f);
    }

    function lt(n, g, tt) {
        for (var lt, rt = 0; rt < tt && !(w && -1 === s);) {
            if (0 < u) {
                if (s !== at) for (; 0 < u && rt < tt;) u--, v &= c - 1, f &= c - 1, n[g + rt++] = o[f++] = o[v++]; else {
                    for (; 0 < u && rt < tt;) u--, f &= c - 1, i(8), n[g + rt++] = o[f++] = r(8), t(8);
                    0 === u && (s = -1);
                }
                if (rt === tt) break;
            }
            if (-1 === s) {
                if (w) break;
                i(1);
                0 !== r(1) && (w = !0);
                t(1);
                i(2);
                s = r(2);
                t(2);
                h = null;
                u = 0;
            }
            switch (s) {
                case 0:
                    lt = n;
                    var vt = g + rt, yt = tt - rt, ht = void 0, ht = a & 7;
                    if (t(ht), i(16), ht = r(16), t(16), i(16), ht !== (~p & 65535)) lt = -1; else {
                        for (t(16), u = ht, ht = 0; 0 < u && ht < yt;) u--, f &= c - 1, i(8), lt[vt + ht++] = o[f++] = r(8), t(8);
                        0 === u && (s = -1);
                        lt = ht;
                    }
                    break;
                case 1:
                    if (null != h) lt = b(n, g + rt, tt - rt); else n:{
                        if (lt = n, vt = g + rt, yt = tt - rt, null == k) {
                            for (var it = void 0, ht = Array(288), it = void 0, it = 0; 144 > it; it++) ht[it] = 8;
                            for (; 256 > it; it++) ht[it] = 9;
                            for (; 280 > it; it++) ht[it] = 7;
                            for (; 288 > it; it++) ht[it] = 8;
                            if (d = 7, it = new y(ht, 288, 257, ft, et, d), 0 !== it.status) {
                                alert('HufBuild error: ' + it.status);
                                lt = -1;
                                break n;
                            }
                            for (k = it.root, d = it.m, it = 0; 30 > it; it++) ht[it] = 5;
                            if (zip_fixed_bd = 5, it = new y(ht, 30, 0, ot, st, zip_fixed_bd), 1 < it.status) {
                                k = null;
                                alert('HufBuild error: ' + it.status);
                                lt = -1;
                                break n;
                            }
                            ut = it.root;
                            zip_fixed_bd = it.m;
                        }
                        h = k;
                        nt = ut;
                        e = d;
                        l = zip_fixed_bd;
                        lt = b(lt, vt, yt);
                    }
                    break;
                case 2:
                    lt = null != h ? b(n, g + rt, tt - rt) : ct(n, g + rt, tt - rt);
                    break;
                default:
                    lt = -1;
            }
            if (-1 === lt) return w ? 0 : -1;
            rt += lt;
        }
        return rt;
    }

    var c = 32768, at = 0, vt = 9, yt = 6, o, f, k = null, ut, d, p, a, s, w, u, v, h, nt, e, l, g, tt,
        pt = new Uint16Array([0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535]),
        ft = new Uint16Array([3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0]),
        et = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 99, 99]),
        ot = new Uint16Array([1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577]),
        st = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
        ht = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
    n.algorithms.inflate = function (t) {
        var i, e, r;
        for (null == o && (o = Array(2 * c)), a = p = f = 0, s = -1, w = !1, u = v = 0, h = null, g = n.utils.arrayBufferToBytes(t), tt = 0, i = new Uint8Array(1024), t = []; 0 < (e = lt(i, 0, i.length));) for (r = 0; r < e; ++r) t[t.length] = i[r];
        return g = null, new Uint8Array(t).buffer;
    };
}(jz);
jz.zlib = jz.zlib || {}, function (n, t) {
    t.zlib.compress = function (n, i) {
        var r, u, e, f;
        for (f = t.utils.arrayBufferToBytes(t.algorithms.deflate(n, i)), r = new Uint8Array(f.length + 6), r[0] = 120, r[1] = 1, u = 2, e = r.length - 4; u < e; ++u) r[u] = f[u - 2];
        return u = t.algorithms.adler32(r), r[r.length - 4] = u >> 24, r[r.length - 3] = (u & 16711680) >> 16, r[r.length - 2] = (u & 65280) >> 8, r[r.length - 1] = u & 255, r.buffer;
    };
    t.zlib.decompress = function (n, i) {
        var u, r;
        if (r = 0, n = t.utils.arrayBufferToBytes(n), r++, n[r++] & 32 && (t.utils.readUintBE(n, r), r += 4), u = t.utils.readUintBE(n, n.length - 4), r = t.algorithms.inflate(n.subarray(r, n.length - 4)), i && u !== t.algorithms.adler32(r)) throw'Error: differ from checksum';
        return r;
    };
    t.zlib.c = t.zlib.compress;
    t.zlib.d = t.zlib.decompress;
}(this, jz);
jz.gz = jz.gz || {}, function (n, t) {
    t.gz.compress = function (n, i, r) {
        function s(n, t) {
            u[t++] = n & 255;
            u[t++] = (n & 65280) >> 8;
            u[t++] = (n & 16711680) >> 16;
            u[t++] = n >> 24;
        }

        var u, f = 0;
        var o = 10, e = 0, h = Date.now(), r = r || {}, n = t.utils.arrayBufferToBytes(n),
            i = new Uint8Array(t.algorithms.deflate(n, i));
        if (r.fname && (o += r.fname.length + 1, f |= 8), r.fcomment && (o += r.fcomment.length + 1, f |= 16), u = new Uint8Array(i.length + o + 8), u[e++] = 31, u[e++] = 139, u[e++] = 8, u[e++] = f, s(h, e), e += 4, u[e++] = 4, u[e++] = 255, r.fname) {
            for (f = 0; f < r.fname.length; ++f) u[e++] = r.fname.charCodeAt(f);
            u[e++] = 0;
        }
        if (r.fcomment) {
            for (f = 0; f < r.fcomment.length; ++f) u[e++] = r.fcomment.charCodeAt(f);
            u[e++] = 0;
        }
        for (s(t.algorithms.crc32(n), u.length - 8), s(n.length % 4294967295, u.length - 4), f = o, n = u.length - 8; f < n; ++f) u[f] = i[f - o];
        return u.buffer;
    };
    t.gz.decompress = function (n, i) {
        var u = {}, f, r = 10, n = t.utils.arrayBufferToBytes(n);
        if (31 !== n[0] || 139 !== n[1]) throw'Error: invalid gzip file.';
        if (8 !== n[2]) throw'Error: not deflate.';
        if (f = n[3], u.mtime = t.utils.readUintLE(n, 4), f & 4 && (r += t.utils.readUshortLE(n, r) + 2), f & 8) {
            for (u.fname = ''; 0 !== n[r];) u.fname += String.fromCharCode(n[r++]);
            ++r;
        }
        if (f & 16) {
            for (u.fcomment = ''; 0 !== n[r];) u.fcomment += String.fromCharCode(n[r++]);
            ++r;
        }
        if (f & 2 && (r += 2), console.log(r), u.buffer = t.algorithms.inflate(n.subarray(r, n.length - 8)), i && (f = t.utils.readUintLE(n, n.length - 8), f !== t.algorithms.crc32(u.buffer))) throw'Error: deffer from checksum.';
        return u;
    };
    t.gz.c = t.gz.compress;
    t.gz.d = t.gz.decompress;
}(this, jz);
jz.zip = jz.zip || {}, function (n, t) {
    function e(n, f, e) {
        var o = new u;
        return o.append(r(t.zip.END_SIGNATURE)), o.append(i(0)), o.append(i(0)), o.append(i(n)), o.append(i(n)), o.append(r(f)), o.append(r(e)), o.append(i(0)), o.getBlob();
    }

    function f(n, t, i, r, u, f) {
        this.buffer = n;
        this.filename = t;
        this.date = i;
        this.offset = r;
        this.dir = u ? 16 : 0;
        this.defl = f ? 8 : 0;
        this._commonHeader = this._getCommonHeader();
        this._cache = {lf: null, cd: null};
    }

    function i(n) {
        return new Uint16Array([n]).buffer;
    }

    function r(n) {
        return new Uint32Array([n]).buffer;
    }

    var u = t.BlobBuilder;
    f.prototype = {
        _getCommonHeader: function () {
            var n = new u;
            return n.append(i(10)), n.append(i(0)), n.append(i(this.defl)), n.append(i(this.date.getHours() << 11 | this.date.getMinutes() << 5 | this.date.getSeconds() >> 1)), n.append(i(this.date.getFullYear() - 1980 << 9 | this.date.getMonth() + 1 << 5 | this.date.getDay())), n.append(r(t.algorithms.crc32(this.buffer))), n.append(r(this.buffer.byteLength)), n.append(r(this.buffer.byteLength)), n.append(i(this.filename.length)), n.append(i(0)), n.getBlob();
        }, getLocalFileHeader: function () {
            if (this._cache.lf) return this._cache.lf;
            var n = new u;
            return n.append(r(t.zip.LOCAL_FILE_SIGNATURE)), n.append(this._commonHeader), n.append(this.filename), this._cache.lf = n.getBlob();
        }, getCentralDirHeader: function () {
            if (this._cache.cd) return this._cache.cd;
            var n = new u;
            return n.append(r(t.zip.CENTRAL_DIR_SIGNATURE)), n.append(i(20)), n.append(this._commonHeader), n.append(i(0)), n.append(i(0)), n.append(i(0)), n.append(r(this.dir)), n.append(r(this.offset)), n.append(this.filename), this._cache.cd = n.getBlob();
        }, getAchiveLength: function () {
            return this.getLocalFileHeader().size + this.buffer.byteLength;
        }
    };
    t.zip.compress = function (n, i) {
        function h(n, u) {
            var a, e, v, p, y;
            if ('undefined' != typeof n) {
                if (n.children) a = u + n.name + ('/' === n.name.substr(-1) ? '' : '/'), e = new ArrayBuffer(0), v = !0; else if (n.url) e = t.utils.loadFileBuffer(n.url), a = u + (n.name || n.url.split('/').pop()); else if (n.str) e = t.utils.stringToArrayBuffer(n.str), a = u + n.name; else if (n.buffer) e = n.buffer, a = u + n.name; else throw'This type is not supported.';
                y = n.level || i;
                1 < y && 'undefined' == typeof n.children && (e = t.algorithms.deflate(e, y), p = !0);
                v = new f(e, a, l, o, v, p);
                r.append(v.getLocalFileHeader());
                r.append(e);
                s.append(v.getCentralDirHeader());
                o += v.getAchiveLength();
                c++;
                n.children && n.children.forEach(function (n) {
                    h(n, a);
                });
            }
        }

        var c = 0, o = 0, r = new u, s = new u, l = new Date, i = i || 1;
        return n.forEach(function (n) {
            h(n, '');
        }), r.append(s.getBlob()), r.append(e(c, s.getBlob().size, o)), r.getBlob('application/zip');
    };
    t.zip.c = t.zip.pack = t.zip.compress;
}(this, jz);
jz.zip = jz.zip || {}, function (n, t) {
    var u = t.BlobBuilder, r = t.utils.readUintLE, i = t.utils.readUshortLE;
    t.zip.LazyLoader = function (n, t, i, r, u) {
        this.buffer = n;
        this.files = t;
        this.folders = i;
        this.localFileHeaders = r;
        this.centralDirHeaders = u;
    };
    t.zip.LazyLoader.prototype = {
        getFileNames: function () {
            for (var t = [], n = 0, i = this.files.length; n < i; ++n) t.push(this.localFileHeaders[this.files[n]].filename);
            return t;
        }, getFileAsArrayBuffer: function (n) {
            for (var i = 0, r = this.localFileHeaders.length; i < r; ++i) if (n === this.localFileHeaders[i].filename) return offset = this.centralDirHeaders[i].headerpos + this.localFileHeaders[i].headersize, len = this.localFileHeaders[i].compsize, 0 === this.centralDirHeaders[i].comptype ? new Uint8Array(new Uint8Array(this.buffer, offset, len)).buffer : t.algorithms.inflate(new Uint8Array(this.buffer, offset, len));
            return null;
        }, getFileAsText: function (n, t, i) {
            var r = new FileReader;
            t.constructor === Function && (i = t, t = 'UTF-8');
            r.onload = function (n) {
                i.call(r, n.target.result, n);
            };
            r.readAsText(this.getFileAsBlob(n), t);
        }, getFileAsBinaryString: function (n, t) {
            var i = new FileReader;
            i.onload = function (n) {
                t.call(i, n.target.result, n);
            };
            i.readAsBinaryString(this.getFileAsBlob(n));
        }, getFileAsDataURL: function (n, t) {
            var i = new FileReader;
            i.onload = function (n) {
                t.call(i, n.target.result, n);
            };
            i.readAsDataURL(this.getFileAsBlob(n));
        }, getFileAsBlob: function (n, t) {
            var i = new u, t = t || 'application/octet-stream';
            return i.append(this.getFileAsArrayBuffer(n)), i.getBlob(t);
        }
    };
    n.FileReaderSync && function () {
        return {
            getFileAsTextSync: function (n) {
                return (new FileReaderSync).readAsText(this.getFileAsBlob(n), encoidng);
            }, getFileAsBinaryStringSync: function (n) {
                return (new FileReaderSync).readAsBinarySting(this.getFileAsBlob(n));
            }, getFileAsDataURLSync: function (n) {
                return (new FileReaderSync).readAsDataURL(this.getFileAsBlob(n));
            }
        };
    }.call(t.zip.LazyLoader.prototype);
    t.zip.decompress = function (n) {
        var e, u, f, o = [], s = [], h = [], c = [];
        for (f = 0, n = n.constructor === ArrayBuffer ? n : t.utils.loadFileBuffer(n), e = new Uint8Array(n); f < e.length;) if (u = r(e, f), u === t.zip.LOCAL_FILE_SIGNATURE) u = new Uint8Array(n, f), u = {
            signature: r(u, 0),
            needver: i(u, 4),
            option: i(u, 6),
            comptype: i(u, 8),
            filetime: i(u, 10),
            filedate: i(u, 12),
            crc32: r(u, 14),
            compsize: r(u, 18),
            uncompsize: r(u, 22),
            fnamelen: i(u, 26),
            extralen: i(u, 28),
            filename: t.utils.readString(u, 30, i(u, 26)),
            headersize: 30 + i(u, 26) + i(u, 28),
            allsize: 30 + r(u, 18) + i(u, 26) + i(u, 28)
        }, o.push(u), f += u.allsize; else if (u === t.zip.CENTRAL_DIR_SIGNATURE) u = new Uint8Array(n, f), u = {
            signature: r(u, 0),
            madever: i(u, 4),
            needver: i(u, 6),
            option: i(u, 8),
            comptype: i(u, 10),
            filetime: i(u, 12),
            filedate: i(u, 14),
            crc32: r(u, 16),
            compsize: r(u, 20),
            uncompsize: r(u, 24),
            fnamelen: i(u, 28),
            extralen: i(u, 30),
            commentlen: i(u, 32),
            disknum: i(u, 34),
            inattr: i(u, 36),
            outattr: r(u, 38),
            headerpos: r(u, 42),
            allsize: 46 + i(u, 28) + i(u, 30) + i(u, 32)
        }, s.push(u), f += u.allsize; else if (u === t.zip.END_SIGNATURE) break; else throw'invalid zip file.';
        for (f = 0, e = o.length; f < e; ++f) {
            if (o[f].crc32 !== s[f].crc32) throw'invalid zip file,';
            o[f].filename.split('/').pop() ? h.push(f) : c.push(f);
        }
        return new t.zip.LazyLoader(n, h, c, o, s);
    };
    t.zip.d = t.zip.unpack = t.zip.decompress;
}(this, jz);
mp4js = mp4js || {};
mp4js.version = '0.2', function () {
    var n = this;
    this.isType = function (n, t) {
        return null != n ? n.constructor == t : !1;
    };
    this.load = function (n, t) {
        var i = new XMLHttpRequest;
        i.open('GET', n);
        i.responseType = 'arraybuffer';
        i.onreadystatechange = function () {
            if (4 == i.readyState) if (2 == ~~(i.status / 100) || 0 === i.status) t.call(i, i.response); else throw'Error: ' + i.status;
        };
        i.send();
    };
    this.getUi16 = function (n, t) {
        return n[t] << 8 | n[t + 1];
    };
    this.getUi24 = function (n, t) {
        return n[t + 1] << 16 | n[t] << 8 | n[t + 1];
    };
    this.getUi32 = function (n, t) {
        return n[t] << 24 | n[t + 1] << 16 | n[t + 2] << 8 | n[t + 3];
    };
    this.getStr = function (n, t, i) {
        for (var r = [], u = 0; u < t; ++u) r[r.length] = n[i + u];
        return String.fromCharCode.apply(null, r);
    };
    this.putUi16 = function (n, t, i) {
        n[i + 1] = t & 255;
        n[i] = t >> 8;
    };
    this.putUi24 = function (n, t, i) {
        n[i + 2] = t & 255;
        n[i + 1] = t >> 8 & 255;
        n[i] = t >> 16;
    };
    this.putUi32 = function (n, t, i) {
        n[i + 3] = t & 255;
        n[i + 2] = t >> 8 & 255;
        n[i + 1] = t >> 16 & 255;
        n[i] = t >> 24;
    };
    this.putStr = function (n, t, i) {
        for (var r = 0, u = t.length; r < u; ++r) n[r + i] = t.charCodeAt(r);
    };
    this.concatByteArrays = function (t) {
        for (var t = n.isType(t, Array) ? t : Array.prototype.slice.call(arguments, 0), r = 0, f = 0, i = 0, u = t.length; i < u; ++i) r += t[i].length;
        for (r = new Uint8Array(r), i = 0; i < u; ++i) r.set(t[i], f), f += t[i].length;
        return r;
    };
}.call(function (n) {
    return n = n || {}, n.utils = n.utils || {}, n.utils;
}(this.mp4js), this);
mp4 = mp4 || {};
mp4.descr = mp4.descr || {}, function (n, t) {
    var i = this, f = t.putUi16, s = t.putUi24, e = t.putUi32, o = t.putStr, r = t.isType, u = t.concatByteArrays;
    this.createBaseDescriptor = function (n, t) {
        var i = new Uint8Array(n + 2);
        return i[0] = t, i[1] = n, i;
    };
    this.createESDescriptor = function (n, t, e, s, h, c, l) {
        var y = 'string' == typeof s ? 1 : 0, p = null != e ? 1 : 0, a = 3, v = 2,
            l = null == l ? [] : r(l, Array) ? l : [l], a = a + (p ? 2 : 0) + (y ? s.length + 1 : 0), a = a + h.length,
            a = a + c.length, l = u(l), a = a + l.length, a = i.createBaseDescriptor(a, 3);
        return f(a, n, v), v += 2, a[v++] = p << 7 | y << 6 | t, p && (f(a, e, v), v += 2), y && (a[v++] = s.length, o(a, s, v), v += s.length), a.set(h, v), v += h.length, a.set(c, v), v += c.length, a.set(l, v), a;
    };
    this.createDecodeConfigDescriptor = function (n, t, f, o, h, c, l) {
        var a, l = null == l ? [] : r(l, Array) ? l : [l];
        return a = u(l), l = i.createBaseDescriptor(a.length + 13, 4), l[2] = n, l[3] = t << 2 | f << 1 | 1, s(l, o, 4), e(l, h, 7), e(l, c, 11), l.set(a, 15), l;
    };
    this.createDecoderSpecificInfo = function (n) {
        var t = i.createBaseDescriptor(n.length, 5);
        return t.set(n, 2), t;
    };
    this.createSLConfigDescriptor = function (n) {
        var t = i.createBaseDescriptor(1, 6);
        return t[2] = n, t;
    };
    this.createInitialObjectDescriptor = function (n, t, e, s, h, c, l, a, v, y) {
        var b = 'string' == typeof e ? 1 : 0, p = 2, w = 4, v = null == v ? [] : r(v, Array) ? subDescr : [subDescr],
            y = null == y ? [] : r(y, Array) ? extDescr : [extDescr], p = p + (b ? e.length + 1 : 5), y = u(y),
            p = p + y.length;
        return b ? (p = i.createBaseDescriptor(p, 16), p[w++] = e.length, o(p, e, w)) : (e = u(v), p += e.length, p = i.createBaseDescriptor(p, 16), p[w++] = s, p[w++] = h, p[w++] = c, p[w++] = l, p[w++] = a, p.set(e, w)), w += e.length, f(p, n << 6 | b << 5 | t << 4 | 15, 2), p.set(y, w), p;
    };
}.call(function (n) {
    return n = n || {}, n.descr = n.descr || {}, n.descr;
}(this.mp4js), this, this.mp4js.utils), function (n, t) {
    var r = this, u = t.putUi16, i = t.putUi32, f = t.putStr, e = t.concatByteArrays, o = t.isType;
    this.createBox = function (n, t) {
        var r = new Uint8Array(n);
        return i(r, n, 0), f(r, t, 4), r;
    };
    this.createFullBox = function (n, t, i, f) {
        return n = r.createBox(n, t), u(n, i, 8), u(n, f, 10), n;
    };
    this.createMp4aBox = function (n, t, i) {
        var f = r.createBox(36 + i.length, 'mp4a');
        return u(f, n, 14), u(f, 2, 24), u(f, 16, 26), u(f, t, 32), f.set(i, 36), f;
    };
    this.createEsdsBox = function (n) {
        var t = r.createFullBox(12 + n.length, 'esds', 0, 0);
        return t.set(n, 12), t;
    };
    this.createTkhdBox = function (n, t, f, e, o) {
        var s = r.createFullBox(92, 'tkhd', 0, 1);
        return i(s, n, 12), i(s, t, 16), i(s, f, 20), i(s, e, 28), u(s, o ? 0 : 256, 44), i(s, 65536, 48), i(s, 65536, 64), i(s, 1073741824, 80), i(s, o ? 20971520 : 0, 84), i(s, o ? 15728640 : 0, 88), s;
    };
    this.createMdhdBox = function (n, t, f, e) {
        var o = r.createFullBox(32, 'mdhd', 0, 0);
        return i(o, n, 12), i(o, t, 16), i(o, f, 20), i(o, e, 24), u(o, 21956, 28), o;
    };
    this.createHdlrBox = function (n, t) {
        var i = r.createFullBox(32 + t.length + 1, 'hdlr', 0, 0);
        return f(i, n, 16), f(i, t, 32), i;
    };
    this.concatBoxes = function (n, t) {
        var t = Array.prototype.slice.call(arguments, 1), n = arguments[0], i, u;
        return u = e(t), i = r.createBox(u.length + 8, n), i.set(u, 8), i;
    };
    this.createUrlBox = function (n, t) {
        var i = 'string' == typeof n ? n.length + 1 : 0,
            u = r.createFullBox(12 + i, 'url ', 0, 'undefined' == typeof t ? 1 : t);
        return i && f(u, n, 12), u;
    };
    this.createUrnBox = function (n, t, i) {
        return createUrlBox(n + '\x00' + t, i);
    };
    this.createDrefBox = function (n) {
        var n = Array.prototype.slice.call(arguments, 0), t, u;
        return u = e(n), t = r.createFullBox(u.length + 16, 'dref', 0, 0), i(t, 12, n.length), t.set(u, 16), t;
    };
    this.createStszBox = function (n, t) {
        var f = r.createFullBox(20 + 4 * t.length, 'stsz', 0, 0), u, e;
        if (i(f, n, 12), i(f, t.length, 16), 0 === n) for (u = 0, e = t.length; u < e; ++u) i(f, t[u], 4 * u + 20);
        return f;
    };
    this.createMvhdBox = function (n, t, f, e, o) {
        var s = r.createFullBox(108, 'mvhd', 0, 0);
        return i(s, n, 12), i(s, t, 16), i(s, f, 20), i(s, e, 24), i(s, 65536, 28), u(s, 256, 32), i(s, 65536, 44), i(s, 65536, 60), i(s, 1073741824, 76), i(s, o, 104), s;
    };
    this.createIodsBox = function (n) {
        var t = r.createFullBox(n.length + 12, 'iods', 0, 0);
        return t.set(n, 12), t;
    };
    this.createDinfBox = function (n) {
        for (var n = Array.prototype.slice.call(arguments, 0), u = 16, o = 16, e, t = 0, f = n.length; t < f; ++t) u += n[t].length;
        for (e = r.createFullBox(u, 'dref', 0, 0), i(e, f, 12), t = 0; t < f; ++t) e.set(n[t], o), o += n[t].length;
        return u = r.createBox(u + 8, 'dinf'), u.set(e, 8), u;
    };
    this.createStsdBox = function (n) {
        var n = Array.prototype.slice.call(arguments, 0), t, u;
        return u = e(n), t = r.createFullBox(u.length + 16, 'stsd', 0, 0), i(t, n.length, 12), t.set(u, 16), t;
    };
    this.createSttsBox = function (n) {
        var u = r.createFullBox(16 + 8 * n.length, 'stts', 0, 0), f = 16, t, e;
        for (i(u, n.length, 12), t = 0, e = n.length; t < e; ++t) i(u, n[t].count, f), i(u, n[t].duration, f + 4), f += 8;
        return u;
    };
    this.createStscBox = function (n) {
        var n = o(n, Array) ? n : [n], e = n.length, f = r.createFullBox(16 + 12 * e, 'stsc', 0, 0), t, u = 16;
        for (i(f, e, 12), t = 0; t < e; ++t) i(f, n[t].firstChunk, u), u += 4, i(f, n[t].samplesPerChunk, u), u += 4, i(f, n[t].samplesDescriptionIndex, u), u += 4;
        return f;
    };
    this.createStcoBox = function (n) {
        var u = n.length, f = r.createFullBox(16 + 4 * u, 'stco', 0, 0), t;
        for (i(f, u, 12), t = 0; t < u; ++t) i(f, n[t], 4 * t + 16);
        return f;
    };
    this.createFreeBox = function (n) {
        var t = r.createBox(8 + n.length + 1, 'free');
        return f(t, n, 8), t;
    };
    this.createFtypBox = function (n) {
        var i = Array.prototype.slice.call(arguments, 0), u = r.createBox(4 * i.length + 16, 'ftyp'), e = 16, t, o;
        for (f(u, n, 8), t = 0, o = i.length; t < o; ++t) f(u, i[t], e), e += 4;
        return u;
    };
}.call(function (n) {
    return n = n || {}, n.box = n.box || {}, n.box;
}(this.mp4js), this, this.mp4js.utils), function (n) {
    function t(n, t, u) {
        for (var e, o = {size: u}, h = t + u, s, t = t + 8; t < h;) {
            if (u = i(n, t), e = f(n, 4, t + 4), s = boxes[e]) o[e] && !r(o[e], Array) ? (o[e] = [o[e]], o[e].push(s(n, t, u))) : r(o[e], Array) ? o[e].push(s(n, t, u)) : o[e] = s(n, t, u); else break;
            t += u;
        }
        return o;
    }

    var e = n.MozBlobBuilder || n.WebKitBlobBuilder || n.MSBlobBuilder || n.BlobBuilder, u = this.utils.getUi16,
        i = this.utils.getUi32, o = this.utils.putUi16, f = this.utils.getStr, r = this.utils.isType,
        s = this.utils.concatByteArrays;
    mp4self = this;
    boxes = {
        ID32: t, albm: function () {
        }, auth: function () {
        }, bpcc: function () {
        }, buff: function () {
        }, bxml: t, ccid: function () {
        }, cdef: function () {
        }, clsf: function () {
        }, cmap: function () {
        }, co64: function () {
        }, colr: function () {
        }, cprt: function () {
        }, crhd: function () {
        }, cslg: function () {
        }, ctts: function (n, t, r) {
            for (var r = {
                size: r,
                body: []
            }, f = i(n, t += 12), u = 0; u < f; ++u) r.body.push({
                compositionOffset: i(n, t += 4),
                sampleCount: i(n, t += 4)
            });
            return r;
        }, cvru: function () {
        }, dcfD: function () {
        }, dinf: t, dref: t, dscp: function () {
        }, dsgd: t, dstg: t, edts: t, elst: function () {
        }, feci: function () {
        }, fecr: function () {
        }, fiin: function () {
        }, fire: function () {
        }, fpar: function () {
        }, free: function () {
        }, frma: t, ftyp: function () {
        }, gitn: function () {
        }, gnre: function () {
        }, grpi: function () {
        }, hdlr: function (n, t, i) {
            return {size: i, type: f(n, 4, t + 16)};
        }, hmhd: function () {
        }, hpix: function () {
        }, icnu: function () {
        }, idat: function () {
        }, ihdr: function () {
        }, iinf: function () {
        }, iloc: function () {
        }, imif: t, infu: function () {
        }, iods: t, iphd: function () {
        }, ipmc: t, ipro: function () {
        }, iref: function () {
        }, 'jp  ': function () {
        }, jp2c: function () {
        }, jp2h: function () {
        }, jp2i: function () {
        }, kywd: function () {
        }, loci: function () {
        }, lrcu: function () {
        }, m7hd: function () {
        }, mdat: function (n, t, i) {
            return {offset: t, size: i, dataSize: i - 8};
        }, mdhd: function (n, t, r) {
            return {
                size: r,
                creationTime: i(n, t + 12),
                modificationTime: i(n, t + 16),
                timeScale: i(n, t + 20),
                duration: i(n, t + 24),
                languageCode: i(n, t + 28)
            };
        }, mdia: t, mdri: function () {
        }, meco: t, mehd: t, mere: function () {
        }, meta: t, mfhd: function () {
        }, mfra: function () {
        }, mfro: function () {
        }, minf: t, mjhd: function () {
        }, moof: function () {
        }, moov: t, mvcg: function () {
        }, mvci: function () {
        }, mvex: t, mvhd: function () {
        }, mvra: function () {
        }, nmhd: function () {
        }, ochd: function () {
        }, odaf: function () {
        }, odda: function () {
        }, odhd: function () {
        }, odhe: function () {
        }, odrb: function () {
        }, odrm: t, odtt: function () {
        }, ohdr: function () {
        }, padb: function () {
        }, paen: function () {
        }, pclr: function () {
        }, pdin: function () {
        }, perf: function () {
        }, pitm: function () {
        }, 'res ': function () {
        }, resc: function () {
        }, resd: function () {
        }, rtng: function () {
        }, sbgp: t, schi: t, schm: t, sdep: function () {
        }, sdhd: function () {
        }, sdtp: t, sdvp: t, segr: function () {
        }, sgpd: t, sidx: t, sinf: t, skip: function () {
        }, smhd: function () {
        }, srmb: function () {
        }, srmc: t, srpp: function () {
        }, stbl: t, stco: function (n, t, r) {
            for (var r = {size: r, body: []}, f = i(n, t += 12), u = 0; u < f; ++u) r.body.push(i(n, t += 4));
            return r;
        }, stdp: function () {
        }, stsc: function (n, t, r) {
            for (var r = {
                size: r,
                body: []
            }, f = i(n, t += 12), u = 0; u < f; ++u) r.body.push({
                firstChunk: i(n, t += 4),
                samplesPerChunk: i(n, t += 4),
                sampleDescriptionIndex: i(n, t += 4)
            });
            return r;
        }, stsd: function (n, i, r) {
            return t(n, i + 8, r - 8);
        }, stsh: function () {
        }, stss: function () {
        }, stts: function (n, t, r) {
            return {size: r, entryCount: i(n, t + 12), sampleCount: i(n, t + 16), sampleDelta: i(n, t + 20)};
        }, styp: t, stsz: function (n, t, r) {
            for (var r = {size: r, body: []}, f = i(n, t += 16), u = 0; u < f; ++u) r.body.push(i(n, t += 4));
            return r;
        }, stz2: function () {
        }, subs: function () {
        }, swtc: function () {
        }, tfad: t, tfhd: function () {
        }, tfma: t, tfra: function () {
        }, tibr: function () {
        }, tiri: function () {
        }, titl: function () {
        }, tkhd: function () {
        }, traf: function () {
        }, trak: t, tref: t, trex: function () {
        }, trgr: function () {
        }, trun: function () {
        }, tsel: function () {
        }, udta: t, uinf: function () {
        }, UITS: function () {
        }, ulst: function () {
        }, 'url ': function () {
        }, vmhd: function () {
        }, vwdi: function () {
        }, 'xml ': function () {
        }, yrrc: function () {
        }, mp4a: function (n, t) {
            return {
                dataReferenceIndex: i(n, t += 12),
                channels: u(n, t += 12),
                bitPerSample: u(n, t += 2),
                sampleRate: i(n, t += 4),
                esds: {
                    objectTypeIndication: n[t += 25],
                    bufferSizeDB: u(n, t += 3),
                    maxBitrate: i(n, t += 2),
                    avgBitrate: i(n, t + 4)
                }
            };
        }
    };
    SAMPLERATE_TABLE = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3];
    this.Mp4 = function (n) {
        this.bytes = r(n, ArrayBuffer) ? new Uint8Array(n) : n;
        this.cache = {};
    };
    this.Mp4.prototype = {
        parse: function () {
            return this.cache.tree ? this.cache.tree : this.cache.tree = t(this.bytes, -8, this.bytes.length);
        }, extractAACAsArrayBuffer: function () {
            var n = this.parse().moov.trak, u, e, f, a, i, s, v, y, w, b, h, o, c, l = 0, p = 0,
                t = new Uint8Array(new ArrayBuffer(7));
            if (r(n, Array)) n.forEach(function (n) {
                'soun' === n.mdia.hdlr.type && (u = n);
            }); else if ('soun' === n.mdia.hdlr.type) u = n; else throw'This file does not have audio files.';
            for (n = u.mdia.minf.stbl.stsd.mp4a, e = u.mdia.minf.stbl.stsc.body, f = u.mdia.minf.stbl.stsz.body, a = u.mdia.minf.stbl.stco.body, c = new Uint8Array(7 * f.length + f.reduce(function (n, t) {
                return n + t;
            })), t[0] = 255, t[1] = 249, t[2] = 64 | SAMPLERATE_TABLE.indexOf(n.sampleRate) << 2 | n.channels >> 2, t[6] = 252, i = 0, o = 0, y = e.length; i < y; ++i) for (s = e[i].firstChunk - 1, w = i + 1 < y ? e[i + 1].firstChunk - 1 : a.length; s < w; ++s) for (p = a[s], v = 0, b = e[i].samplesPerChunk; v < b; ++v, ++o) h = f[o] + 7, t[3] = n.channels << 6 | h >> 11, t[4] = h >> 3, t[5] = h << 5 | 31, c.set(t, l), l += 7, c.set(this.bytes.subarray(p, p += f[o]), l), l += f[o];
            return c.buffer;
        }, extractAACAsBlob: function () {
            var n = new e;
            return n.append(this.extractAACAsArrayBuffer()), n.getBlob('audio/aac');
        }
    };
    this.aacToM4a = function (n) {
        function d(n) {
            return (h[n + 3] & 3) << 11 | h[n + 4] << 3 | h[n + 5] >> 5;
        }

        for (var h = new Uint8Array(n), t = 0, n = 0, c = [], g = [], r = Date.now(), e, f, l, a, v, y, p, w, b, k, u = SAMPLERATE_TABLE[(h[2] & 60) >> 2], i = (h[2] & 1) << 2 | h[3] >> 6; t < h.length;) g[n] = t, c[n++] = d(t) - 7, t += d(t);
        for (t = n, f = mp4self.descr.createInitialObjectDescriptor(1, 0, null, 255, 255, 41, 255, 255), e = new Uint8Array(2), o(e, 4096 | SAMPLERATE_TABLE.indexOf(u) << 7 | i << 3, 0), i = mp4self.descr.createDecoderSpecificInfo(e), e = mp4self.descr.createDecodeConfigDescriptor(64, 5, 0, 0, 0, 0, [i]), i = mp4self.descr.createSLConfigDescriptor(2), i = mp4self.descr.createESDescriptor(0, 0, null, null, e, i, []), i = mp4self.box.createEsdsBox(i), e = mp4self.box.createMp4aBox(1, u, i), i = mp4self.box.createFtypBox('M4A ', 'mp42', 'isom', '\x00\x00\x00\x00'), l = mp4self.box.createSttsBox([{
            count: n,
            duration: 1024
        }]), a = mp4self.box.createStscBox({
            firstChunk: 1,
            samplesPerChunk: t,
            samplesDescriptionIndex: 1
        }), v = mp4self.box.createStszBox(0, c), y = mp4self.box.createStsdBox(e), p = mp4self.box.createDinfBox(mp4self.box.createUrlBox(null, 1)), w = mp4self.box.createBox(16, 'smhd'), b = mp4self.box.createMdhdBox(r, r, u, 1024 * n), k = mp4self.box.createHdlrBox('soun', 'mp4.js Audio Handler'), e = mp4self.box.createTkhdBox(r, r, 1, ~~(614400 * n / u)), f = mp4self.box.createIodsBox(f), u = mp4self.box.createMvhdBox(r, r, 600, ~~(614400 * n / u), 2), r = c.reduce(function (n, t) {
            return n + t;
        }), dataStart = i.length + l.length + a.length + v.length + y.length + p.length + w.length + b.length + k.length + e.length + f.length + u.length, dataStart += 48, dataStart += 4 * ~~(c.length / t) + 16, t = mp4self.box.createStcoBox([dataStart]), t = mp4self.box.concatBoxes('stbl', y, l, a, v, t), t = mp4self.box.concatBoxes('minf', w, p, t), t = mp4self.box.concatBoxes('mdia', b, k, t), t = mp4self.box.concatBoxes('trak', e, t), moov = mp4self.box.concatBoxes('moov', u, f, t), t = mp4self.box.createBox(r + 8, 'mdat'), r = 0, u = 8, f = 0; f < n; ++f) r = g[f], t.set(h.subarray(r + 7, r + 7 + c[f]), u), u += c[f];
        return n = mp4self.box.createFreeBox('Produced with mp4.js ' + mp4self.version), s(i, moov, t, n).buffer;
    };
}.call(this.mp4js, this);
Flv = function () {
    function e(n) {
        this.buffer = n;
        this.bytes = new Uint8Array(n);
        this.cache = {};
    }

    var i = 8, o = 3, s = 10,
        h = ['.wav', '.wav', '.mp3', '.wav', '.?', '.?', '.?', '.wav', '.wav', '.reserved', '.aac', '.spx', '.mp3', '.?'],
        c = [5512, 11025, 22050, 44100], f, n;
    SOUND_SIZE_TABLE = [8, 16];
    SOUND_TYPE_TABLE = [1, 2];
    VIDEO_FRAME_TYPE_KEY_FRAME = 1;
    VIDEO_FRAME_TYPE_INTER_FRAME = 2;
    VIDEO_FRAME_TYPE_DISPOSABLE_INTER_FRAME = 3;
    VIDEO_FRAME_TYPE_GENERATED_KEY_FRAME = 4;
    VIDEO_FRAME_TYPE_VIDEO_INFO = 5;
    VIDEO_CODEC_ID_JPEG = 1;
    VIDEO_CODEC_ID_SORENSON_H263 = 2;
    VIDEO_CODEC_ID_SCREEN_VIDEO = 3;
    VIDEO_CODEC_ID_ON2_VP6 = 4;
    VIDEO_CODEC_ID_ON2_VP6_WITH_ALPHA_CHANNEL = 5;
    VIDEO_CODEC_ID_SCREEN_VIDEO_VERSION2 = 6;
    VIDEO_CODEC_ID_AVC = 7;
    f = function (n, t) {
        return n != null ? n.constructor == t : !1;
    };
    n = function (n) {
        for (var n = f(n, Array) ? n : Array.prototype.slice.call(arguments, 0), u = 0, e = 0, r, t = 0, i = n.length; t < i; ++t) u += n[t].length;
        for (r = new Uint8Array(u), t = 0; t < i; ++t) r.set(n[t], e), e += n[t].length;
        return r;
    };
    e.prototype = {
        parse: function () {
            var t, n, i;
            if (this.cache.parse) return this.cache.parse;
            for (t = {}, n = 0, t.header = {}, t.header.signature = this.str(n, 3), n += 3, t.header.version = this.ui8(n), n++, t.header.flags = this.ui8(n), n++, t.header.offset = this.ui32(n), n += 4, n += 4, t.tags = []; n < this.bytes.length;) i = {}, i.type = this.ui8(n), n++, i.bodyLength = this.ui24(n), n += 3, i.timestamp = this.ui24(n), n += 3, i.timestampExtended = this.ui8(n), n++, i.streamId = this.ui24(this), n += 3, n += i.bodyLength, i.previousTagSize = this.ui32(n), n += 4, t.tags.push(i);
            return this.cache.parse = t, t;
        }, _extractAudio: function () {
            for (var r = this.parse(), u = 13, f = [], e = this.getAudioInfo(), t = 0, s = r.tags.length; t < s; ++t) u += 11, r.tags[t].type === i && f.push(this.bytes.subarray(u + 1, u + r.tags[t].bodyLength)), u += r.tags[t].bodyLength + 4;
            return e.soundFormat === o ? this.wave(n(f), e) : {type: h[e.soundFormat], buffer: n(f).buffer};
        }, wave: function (i, f) {
            var e = new Uint8Array(44), s = SOUND_TYPE_TABLE[f.soundType], h = c[f.soundRate],
                o = SOUND_SIZE_TABLE[f.soundSize];
            return u(e, 'RIFF', 0), t(e, i.length + e.length - 8, 4), u(e, 'WAVE', 8), u(e, 'fmt ', 12), t(e, o, 16), r(e, 1, 20), r(e, s, 22), t(e, h, 24), t(e, h * s * o / 8, 28), r(e, s * o / 8, 32), r(e, o, 34), u(e, 'data', 36), t(e, i.length, 40), {
                type: '.wav',
                buffer: n(e, i).buffer
            };
        }, extractAAC: function () {
            var f = this.parse(), e = 13, s = [], o = this.getAACInfo(), t = new Uint8Array(7), r, u, h;
            for (t[0] = 255, t[1] = 249, t[2] = 64 | o.sampleRate << 2 | o.channels >> 2, t[6] = 252, u = 0, h = f.tags.length; u < h; ++u) e += 11, f.tags[u].type === i && this.bytes[e + 1] === 1 && (r = new Uint8Array(f.tags[u].bodyLength - -5), t[3] = o.channels << 6 | r.length >> 11, t[4] = r.length >> 3, t[5] = r.length << 5 | 31, r.set(t, 0), r.set(this.bytes.subarray(e + 2, e + f.tags[u].bodyLength), 7), s.push(r)), e += f.tags[u].bodyLength + 4;
            return {type: '.aac', buffer: n(s).buffer};
        }, getAudioInfo: function () {
            for (var u = this.parse(), t = 13, r = 0, n; ;) {
                if (t += 11, u.tags[r].type === i) return n = this.bytes[t], {
                    soundFormat: n >> 4,
                    soundRate: n >> 2 & 3,
                    soundSize: n >> 1 & 1,
                    soundType: n & 1
                };
                t += u.tags[r].bodyLength + 4;
                r++;
            }
        }, getAACInfo: function () {
            for (var r = this.parse(), n = 13, t = 0, u; ;) {
                if (n += 11, r.tags[t].type === i && this.bytes[n + 1] === 0) return u = this.bytes[n], {
                    type: (this.ui8(n + 2) >> 3) - 1,
                    sampleRate: this.ui16(n + 2) >> 7 & 15,
                    channels: this.ui16(n + 2) >> 3 & 15
                };
                n += r.tags[t].bodyLength + 4;
                t++;
            }
        }, extractAudio: function () {
            var n = this.getAudioInfo();
            return n.soundFormat === s ? this.extractAAC() : this._extractAudio();
        }, ui8: function (n) {
            return this.bytes[n];
        }, ui16: function (n) {
            return this.bytes[n] << 8 | this.bytes[n + 1];
        }, ui24: function (n) {
            return this.bytes[n] << 16 | this.bytes[n + 1] << 8 | this.bytes[n + 2];
        }, ui32: function (n) {
            return new Uint32Array(new Uint8Array([this.bytes[n + 3], this.bytes[n + 2], this.bytes[n + 1], this.bytes[n]]).buffer)[0];
        }, str: function (n, t) {
            for (var i = [], r = n, u = n + t; r < u; ++r) i[i.length] = this.bytes[r];
            return String.fromCharCode.apply(null, i);
        }
    };
    var r = function (n, t, i) {
        n[i] = t & 255;
        n[i + 1] = t >> 8;
    }, l = function (n, t, i) {
        n[i] = t & 255;
        n[i + 1] = t >> 8 & 255;
        n[i + 2] = t >> 16;
    }, t = function (n, t, i) {
        n[i] = t & 255;
        n[i + 1] = t >> 8 & 255;
        n[i + 2] = t >> 16 & 255;
        n[i + 3] = t >> 24;
    }, u = function (n, t, i) {
        for (var r = 0, u = t.length; r < u; ++r) n[r + i] = t.charCodeAt(r);
    };
    return e;
}(this);
newArray = function (n) {
    return new Array(n).toString().split(',');
};
getUint16BE = function (n, t) {
    return new Uint16Array(new Uint8Array([n[t + 1], n[t]]).buffer)[0];
};
getUint16LE = function (n, t) {
    return new Uint16Array(new Uint8Array([n[t], n[t + 1]]).buffer)[0];
};
getUint24BE = function (n, t) {
    return new Uint32Array(new Uint8Array([n[t + 2], n[t + 1], n[t], 0]).buffer)[0];
};
getUint24LE = function (n, t) {
    return new Uint32Array(new Uint8Array([n[t], n[t + 1], n[t + 2], 0]).buffer)[0];
};
getUint32BE = function (n, t) {
    return new Uint32Array(new Uint8Array([n[t + 3], n[t + 2], n[t + 1], n[t]]).buffer)[0];
};
getUint32LE = function (n, t) {
    return new Uint32Array(new Uint8Array([n[t], n[t + 1], n[t + 2], n[t + 3]]).buffer)[0];
};
getString = function (n, t, i) {
    return String.fromCharCode.apply(null, newArray(i).map(function () {
        return n[t++];
    }));
};
putUint16BE = function (n) {
    return new Uint8Array([n >> 8 & 255, n & 255]);
};
putUint16LE = function (n) {
    return new Uint8Array([n & 255, n >> 8 & 255]);
};
putUint24BE = function (n) {
    return new Uint8Array([n >> 16 & 255, n >> 8 & 255, n & 255]);
};
putUint24LE = function (n) {
    return new Uint8Array([n & 255, n >> 8 & 255, n >> 16 & 255]);
};
putUint32BE = function (n) {
    return new Uint8Array([n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, n & 255]);
};
putUint32LE = function (n) {
    return new Uint8Array([n & 255, n >> 8 & 255, n >> 16 & 255, n >> 24 & 255]);
};
putString = function (n) {
    return new Uint8Array(n.split('').map(function (n) {
        return n.charCodeAt();
    }));
};
getBox = function (n, t, i) {
    var u, r, f, e;
    for (f = {offset: t, size: i}, e = t + i, t += 8; t < e;) {
        r = {size: getUint32BE(n, t), type: getString(n, t + 4, 4)};
        switch (r.type) {
            case'moov':
            case'trak':
            case'mdia':
            case'minf':
            case'stbl':
                u = getBox(n, t, r.size);
                break;
            case'mvhd':
            case'tkhd':
                u = {offset: t, size: r.size};
                break;
            case'hdlr':
                u = getString(n, t + 16, 4);
                break;
            case'stsz':
                u = newArray(getUint32BE(n, t + 16)).map(function (i, r) {
                    return getUint32BE(n, t + 20 + 4 * r);
                });
                break;
            case'stsc':
                u = newArray(getUint32BE(n, t + 12)).map(function (i, r) {
                    return {offset: getUint32BE(n, t + 16 + 12 * r) - 1, size: getUint32BE(n, t + 20 + 12 * r)};
                });
                break;
            case'stco':
                u = {
                    offset: t, size: r.size, body: newArray(getUint32BE(n, t + 12)).map(function (i, r) {
                        return getUint32BE(n, t + 16 + 4 * r);
                    })
                };
                break;
            case'co64':
                n[t + 4] = 115;
                n[t + 5] = 116;
                n[t + 6] = 99;
                n[t + 7] = 111;
                r.type = 'stco';
                u = {
                    offset: t, size: r.size, body: newArray(getUint32BE(n, t + 12)).map(function (i, r) {
                        return getUint32BE(n, t + 20 + 8 * r);
                    })
                };
                break;
            default:
                u = null;
        }
        u && (f[r.type] && !Array.isArray(f[r.type]) ? (f[r.type] = [f[r.type]], f[r.type].push(u)) : Array.isArray(f[r.type]) ? f[r.type].push(u) : f[r.type] = u);
        t += r.size;
    }
    return f;
};
mp4 = function (n) {
    var o, r, e, u, l, h, a, s, c, f, i, t;
    return u = new Uint8Array(n), t = getBox(u, -8, u.length), i = {}, Array.isArray(t.moov.trak) ? t.moov.trak.forEach(function (n) {
        i[n.mdia.hdlr] = n;
    }) : i[t.moov.trak.mdia.hdlr] = t.moov.trak, f = i.soun.mdia.minf.stbl, c = [], r = 0, l = 0, e = [40 + t.moov.mvhd.size + i.soun.size + 8], f.stsc.push({offset: f.stco.body.length}), f.stsc.reduce(function (n, t) {
        for (var u, o, i = n.offset; i < t.offset; i++) {
            for (s = f.stco.body[i], o = 0; o < n.size; o++) u = f.stsz[l++], c.push({
                offset: s,
                size: u
            }), r += u, s += u;
            i < f.stco.body.length - 1 && e.push(s - f.stco.body[i] + e[e.length - 1]);
        }
        return t;
    }), u.set(putUint32BE(2), t.moov.mvhd.offset + 104), u.set(putUint32BE(1), i.soun.tkhd.offset + 20), e.reduce(function (n, t) {
        return h = putUint32BE(t), u.set(h, n), n + h.length;
    }, f.stco.offset + 16), a = [new Uint8Array([0, 0, 0, 32, 102, 116, 121, 112, 77, 52, 65, 32, 0, 0, 0, 0, 77, 52, 65, 32, 109, 112, 52, 50, 105, 115, 111, 109, 0, 0, 0, 0]), putUint32BE(t.moov.mvhd.size + i.soun.size + 8), putString('moov'), u.subarray(t.moov.mvhd.offset, t.moov.mvhd.offset + t.moov.mvhd.size), u.subarray(i.soun.offset, i.soun.offset + i.soun.size), putUint32BE(r + 8), putString('mdat')], o = new Uint8Array(40 + t.moov.mvhd.size + i.soun.size + 8 + r), r = 0, a.forEach(function (n) {
        o.set(n, r);
        r += n.length;
    }), c.forEach(function (n) {
        o.set(u.subarray(n.offset, n.offset + n.size), r);
        r += n.size;
    }), o;
};
swf = function (n) {
    var e, o, r, c, i, l, u, t, s, f, h, a;
    for (r = new Uint8Array(n), c = getUint32LE(r, 4) - 8, u = getString(r, 0, 3) === 'CWS' ? new Uint8Array(jz.zlib.decompress(r.subarray(8))) : r.subarray(8), f = u[0] >> 3, l = f * 4 % 8 == 0 ? Math.floor(f / 2) : Math.floor(f / 2) + 1, t = l + 5, s = [], o = 0; t < c;) h = getUint16LE(u, t), a = h >> 6, i = h & 63, t += 2, i === 63 && (i = getUint32LE(u, t), t += 4), a === 19 && (s.push({
        offset: t + 4,
        size: i - 4
    }), o += i - 4), t += i;
    return e = new Uint8Array(o), s.reduce(function (n, t) {
        return e.set(u.subarray(t.offset, t.offset + t.size), n), n + t.size;
    }, 0), e;
};
addEventListener('message', function (n) {
    var f, r, e, s, t, i, u, o;
    r = n.data.buffer;
    e = n.data.file;
    i = e.name.substring(0, e.name.lastIndexOf('.'));
    f = new Uint8Array(r);
    o = getString(f, 0, 3);
    try {
        o === 'FLV' ? (s = new Flv(r), t = s.extractAudio(), t.type === '.aac' ? u = {
            file: new Uint8Array(mp4js.aacToM4a(t.buffer)),
            name: i + '.m4a'
        } : t.type === '.mp3' ? u = {
            file: new Uint8Array(t.buffer),
            name: i + '.mp3'
        } : t.type === '.wav' && (u = {
            file: new Uint8Array(t.buffer),
            name: i + '.wav'
        })) : u = /[CF]WS/.test(o) ? {file: swf(r), name: i + '.mp3'} : getString(f, 4, 4) === 'ftyp' ? {
            file: mp4(r),
            name: i + '.m4a'
        } : null;
        postMessage(u);
    } catch (e) {
        postMessage(false);
    }
}, !1);