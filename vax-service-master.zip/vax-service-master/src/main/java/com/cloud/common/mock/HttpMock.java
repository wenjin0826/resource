package com.cloud.common.mock;

import java.lang.annotation.*;

/**
 * HTTP模拟注解
 *
 * @author fengwenjin
 */
@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface HttpMock {
}
