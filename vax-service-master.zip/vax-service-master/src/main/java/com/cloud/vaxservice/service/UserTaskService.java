package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.UserTaskQueryParamDTO;
import com.cloud.vaxservice.entity.UserTask;

/**
 * 用户任务服务接口
 *
 * @author feng
 * @since 2021-11-28
 */
public interface UserTaskService extends IService<UserTask> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<UserTask> query(UserTaskQueryParamDTO paramDTO);

    /**
     * 根据taskId查询
     *
     * @param taskId
     * @return
     */
    UserTask getByTaskId(String taskId);

    /**
     * 根据用户ID删除
     *
     * @param userId
     */
    void deleteByUserId(Long userId);
}