package com.cloud.vaxservice.browser;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.cloud.vaxservice.provider.ZmProvider;
import com.sun.javafx.application.PlatformImpl;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import lombok.extern.slf4j.Slf4j;
import netscape.javascript.JSObject;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * 迷你浏览器
 *
 * @author feng
 * @since 2023/12/09
 */
@Slf4j
@Component
public class WenkuBrowser extends Application {
    @Autowired
    private ZmProvider zmProvider;

    private static LinkedBlockingQueue<WebEngine> engineQueue = new LinkedBlockingQueue();
    private static Map<String, InvokeFuture> futureMap = new ConcurrentHashMap<>();
    private static boolean isRunning;
    private static WenkuBrowser instance;

    public static WenkuBrowser getInstance() {
        return instance;
    }

    @PostConstruct
    @Override
    public void init() {
        if (isRunning) {
            return;
        }
        isRunning = true;
        instance = this;
        new Thread(() -> launch()).start();
    }

    @Override
    public void start(Stage stage) {
        log.info(WenkuBrowser.class.getSimpleName() + " started");
        if (engineQueue.isEmpty()) {
            buildVideoEngine();
        }
    }

    private void buildVideoEngine() {
        for (int i = 0; i < 10; i++) {
            WebView webView = new WebView();
            WebEngine engine = webView.getEngine();
            engine.getLoadWorker().stateProperty().addListener(
                    (ObservableValue<? extends Worker.State> observable, Worker.State oldState, Worker.State newState) -> {
                        if (newState == Worker.State.SUCCEEDED) {
                            InvokeFuture future = futureMap.get(engine.toString());
                            String redirectUrl = future.getRequest().getRedirectUrl();
                            if (StringUtils.isNotEmpty(redirectUrl)) {
                                future.getRequest().setRedirectUrl(null);
                                engine.executeScript("location.href='" + redirectUrl + "';");
                                return;
                            }
                            executeCoreScript(engine);
                        }
                    }
            );
            engineQueue.add(engine);
        }
    }

    private void executeCoreScript(WebEngine engine) {
        JSObject window = (JSObject) engine.executeScript("window");
        window.setMember("bridge", new JavaScriptBridge(futureMap.get(engine.toString())));
        engine.executeScript("" +
                    "var intrlCount = 0;" +
                    "var checkIntrl = setInterval(function() {" +
                    "var readerContainer = document.getElementById('reader-container');" +
                    "if(readerContainer != null && readerContainer.innerHTML.indexOf('pageNo') > 0) {" +
                        "clearInterval(checkIntrl);" +
                        "var docHTML = readerContainer.innerHTML;" +
                        "var pageInfo = window.pageData != undefined ? JSON.stringify(window.pageData) : '';" +
                        "window.bridge.callback(docHTML, pageInfo);" +
                        "return;" +
                    "}" +
                    "if (++intrlCount > 30) {clearInterval(checkIntrl);}" +
                "}, 200)");
    }

    private String parseDocument(HttpResponse httpResponse) {
        try {
            String docHTML;
            Document document = Jsoup.parse(httpResponse.docHTML);

            // 图片形式的处理
            if (StringUtils.isNotEmpty(httpResponse.pageInfo) && JSON.parseObject(httpResponse.pageInfo).getJSONObject("readerInfo").getString("wapRenderType").equals("retype")) {
                Elements imgs = document.select(".pageNo div img");
                Element baseImg = imgs.get(0);
                String imgSrc = baseImg.attr("src");
                imgSrc = imgSrc.replace("&amp;", "&");

                String imgWidth = baseImg.attr("width");
                String imgHeight = baseImg.attr("height");
                String imgBaseUrl = imgSrc.substring(0, imgSrc.indexOf("?pn="));
                String imgQueryStr = imgSrc.substring(imgSrc.indexOf("&"), imgSrc.indexOf("&png="));

                JSONArray imgParams = JSON.parseObject(httpResponse.pageInfo).getJSONObject("readerInfo").getJSONArray("bcsParam");
                int imgTotal = imgParams.size();
                int pages = imgTotal / 2;
                StringBuilder documentBuilder = new StringBuilder();
                for (int i = 0; i < pages; i++) {
                    int pageNo = i + 1;
                    int end = pageNo * 2;
                    int start = end - 1;
                    String startImgUrl = null;
                    String endImgUrl = null;
                    if (start <= imgTotal) {
                        startImgUrl = imgBaseUrl + "?pn=" + start + imgQueryStr + imgParams.getJSONObject(start - 1).getString("zoom");
                    }
                    if (end <= imgTotal) {
                        endImgUrl = imgBaseUrl + "?pn=" + end + imgQueryStr + imgParams.getJSONObject(end - 1).getString("zoom");
                    }

                    StringBuilder pageBuilder = new StringBuilder();
                    pageBuilder.append("<div data-pn='" + pageNo + "' class='pageNo' style='position: relative'>");
                    if (startImgUrl != null) {
                        pageBuilder.append("<div><img src='" + startImgUrl + "' width='" + imgWidth + "' height='" + imgHeight + "'></div>");
                    }
                    if (endImgUrl != null) {
                        pageBuilder.append("<div><img src='" + endImgUrl + "' width='" + imgWidth + "' height='" + imgHeight + "'></div>");
                    }
                    pageBuilder.append("<div class='pager'>第 " + pageNo + " 页</div>");
                    pageBuilder.append("</div>");
                    pageBuilder.append("<div class='biz-wrap biz-wrap-" + pageNo + "'></div>");
                    documentBuilder.append(pageBuilder);
                }
                docHTML = documentBuilder.toString();

            } else {
                // 文本形式的处理，删除分页旁边的图标
                Elements elements = document.select(".pager");
                for (Element ele : elements) {
                    ele.nextElementSibling().remove();
                }
                docHTML = document.body().html();
            }
            return "<div id='reader-container' class='reader-container'>" + docHTML + "</div>";
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    public String load(HttpRequest request) throws Exception {
//        ZmProxyDTO proxy = zmProvider.getProxy();
//        if (proxy == null) {
//            return null;
//        }
//        System.setProperty("http.proxyHost", proxy.getIp());
//        System.setProperty("http.proxyPort", proxy.getPort() + "");
//        System.setProperty("https.proxyHost", proxy.getIp());
//        System.setProperty("https.proxyPort", proxy.getPort() + "");

        log.info("loadUrl=" + request.getLoadUrl());

        WebEngine engine = engineQueue.take();
        InvokeFuture<HttpResponse> invokeFuture = new InvokeFuture(30000, request);
        futureMap.put(engine.toString(), invokeFuture);

        PlatformImpl.runAndWait(() -> {
            engine.setUserAgent(request.getUserAgent());
            engine.load(request.getLoadUrl());
        });

        HttpResponse httpResponse = invokeFuture.get();
        engineQueue.add(engine);

        if (httpResponse != null) {
            return parseDocument(httpResponse);
        }

        return null;
    }
}

