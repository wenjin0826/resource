package com.cloud.common.util;

import com.cloud.common.context.AppContext;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * json工具类
 *
 * @author fengwenjin
 */
@Slf4j
public class JsonUtils {

    private static ObjectMapper objectMapper;

    public static String toJSONString(Object value) {
        if (value != null) {
            try {
                return getObjectMapper().writeValueAsString(value);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    public static <T> T parseObject(String json, Class<T> clazz) {
        if (!StringUtils.isEmpty(json)) {
            try {
                return getObjectMapper().readValue(json, clazz);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    public static <T> T parseObject(String json, Type type) {
        if (!StringUtils.isEmpty(json)) {
            try {
                return getObjectMapper().readValue(json, getObjectMapper().getTypeFactory().constructType(type));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    public static <T> List<T> parseArray(String json, Class<T> clazz) {
        if (!StringUtils.isEmpty(json)) {
            try {
                JavaType javaType = getObjectMapper().getTypeFactory().constructParametricType(List.class, clazz);
                return getObjectMapper().readValue(json, javaType);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    private static ObjectMapper getObjectMapper() {
        if (objectMapper != null) {
            return objectMapper;
        }
        // 优先从上下文获取
        objectMapper = AppContext.getBean(ObjectMapper.class);
        if (objectMapper == null) {
            objectMapper = new ObjectMapper();
            objectMapper.setLocale(Locale.SIMPLIFIED_CHINESE);
            objectMapper.setTimeZone(TimeZone.getTimeZone("GMT+8"));
            objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            objectMapper.setDefaultPropertyInclusion(JsonInclude.Include.ALWAYS);
            objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.configure(JsonReadFeature.ALLOW_UNESCAPED_CONTROL_CHARS.mappedFeature(), true);
            objectMapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
        }
        return objectMapper;
    }

}
