package com.cloud.vaxservice.constant;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.exception.AppException;
import lombok.Getter;

/**
 * 错误枚举
 *
 * @author feng
 * @since 2021-09-02
 */
public enum ErrorEnum {
    PROCESSING(102, "正在处理中"),
    USER_NOT_AUTH(1000, "用户未授权"),
    PASSWORD_ERROR(1001, "密码错误"),
    USER_DISABLE(1002, "账号已禁用"),
    USER_NOTEXIST(1003, "账号不存在"),
    USERNAME_EXIST(1004, "用户名已存在"),
    LOGIN_FAILURE(1005, "登录失败"),
    NAME_EXIST(1006, "名称已存在"),
    VALID_CODE_ERROR(1007, "验证码错误"),
    SEND_SMS_FAILURE(1008, "发送短信失败"),
    TODAY_FREE_LIMITED(1009, "今日免费次数已用完"),
    EXTRACT_RUNNING(1010, "提取正在处理中"),
    PHONE_NUMBER_ERROR(1011, "手机号码错误"),
    WECHAT_CODE_ERROR(1012, "微信code错误"),
    USER_SCORE_NOT_ENOUGH(1013, "用户积分不足");

    @Getter
    private int code;

    @Getter
    private String message;

    public <T> ResultInfo<T> result() {
        return ResultInfo.failure().setCode(code).setMessage(message);
    }

    public AppException exception() {
        return new AppException(code, message);
    }

    ErrorEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
