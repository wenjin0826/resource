package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 配音获取参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class SpeechGetParamDTO {
    @NotEmpty(message = "任务ID不能为空")
    private String taskId;
}