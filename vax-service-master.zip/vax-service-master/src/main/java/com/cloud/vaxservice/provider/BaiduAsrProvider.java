package com.cloud.vaxservice.provider;

import com.cloud.common.exception.AppException;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.provider.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 百度AI服务
 *
 * @author fengwenjin
 * @since 2021/9/2
 */
@Slf4j
@Component
public class BaiduAsrProvider {
    private static final String API_URL = "https://aip.baidubce.com";

    @Value("${baidu.clientId}")
    private String clientId;

    @Value("${baidu.clientSecret}")
    private String clientSecret;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Autowired
    private RestTemplate restTemplate;

    public String createTranscribeTask(BaiduCreateTranscribeParamDTO paramDTO) {
        String accessToken = getAccessToken();
        if (StringUtils.isEmpty(accessToken)) {
            throw new AppException("access token is null");
        }
        String url = API_URL + "/rpc/2.0/aasr/v1/create?access_token=" + accessToken;
        String result = execute(url, paramDTO);
        BaiduCreateTranscribeResultDTO resultDTO = JsonUtils.parseObject(result, BaiduCreateTranscribeResultDTO.class);
        if (resultDTO != null && StringUtils.isNotEmpty(resultDTO.getTaskId())) {
            return resultDTO.getTaskId();
        }
        return null;
    }

    public List<BaiduTranscribeResultDTO> queryTranscribeTasks(List<String> taskIds) {
        try {
            String accessToken = getAccessToken();
            if (StringUtils.isEmpty(accessToken)) {
                throw new AppException("access token is null");
            }
            Map<String, List> paramsMap = new HashMap<>();
            paramsMap.put("task_ids", taskIds);
            String url = API_URL + "/rpc/2.0/aasr/v1/query?access_token=" + accessToken;
            String result = execute(url, paramsMap);
            BaiduQueryTranscribeResultDTO resultDTO = JsonUtils.parseObject(result, BaiduQueryTranscribeResultDTO.class);
            if (resultDTO == null || StringUtils.isEmpty(resultDTO.getLogId())) {
                return null;
            }
            if (CollectionUtils.isNotEmpty(resultDTO.getResultList())) {
                return resultDTO.getResultList();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    private String getAccessToken() {
        String key = "BaiduAccessToken";
        String accessToken = (String) redisTemplate.opsForValue().get(key);
        if (StringUtils.isEmpty(accessToken)) {
            String apiPath = API_URL + "/oauth/2.0/token?grant_type=client_credentials&client_id=" + clientId + "&client_secret=" + clientSecret;
            String result = execute(apiPath, null);
            BaiduGetAccessTokenResultDTO resultDTO = JsonUtils.parseObject(result, BaiduGetAccessTokenResultDTO.class);
            if (resultDTO != null && StringUtils.isNotEmpty(resultDTO.getAccessToken())) {
                accessToken = resultDTO.getAccessToken();
                Integer timeoutSeconds = resultDTO.getExpiresIn() - 60;
                redisTemplate.opsForValue().set(key, accessToken, timeoutSeconds, TimeUnit.SECONDS);
            }
        }
        return accessToken;
    }

    private String execute(String url, Object params) {
        log.info("request apiPath >>> {} params >>> {}", url, JsonUtils.toJSONString(params));
        String result = restTemplate.postForObject(url, params, String.class);
        log.info("result >>> {}", result);
        return result;
    }
}
