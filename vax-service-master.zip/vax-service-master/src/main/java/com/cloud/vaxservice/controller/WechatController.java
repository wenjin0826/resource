package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.limit.Limit;
import com.cloud.common.util.IDUtils;
import com.cloud.common.util.RSAUtils;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.config.WechatConfig;
import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.RSAKeyEnum;
import com.cloud.vaxservice.dto.UserSessionDTO;
import com.cloud.vaxservice.dto.WechatLoginParamDTO;
import com.cloud.vaxservice.dto.WechatUserInfoDTO;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.support.SessionHelper;
import com.cloud.vaxservice.support.WechatHelper;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * 微信URL接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class WechatController {
    @Autowired
    private UserService userService;

    @Autowired
    private WechatHelper wechatHelper;

    @Autowired
    private SessionHelper sessionHelper;

    @Autowired
    private WechatConfig wechatConfig;

    @Autowired
    private VaxConfig vaxConfig;

    /**
     * 微信登录
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/wechat/login")
    @Limit(limitCount = 10, durationSeconds = 300)
    public ResultInfo<UserSessionDTO> wechatLogin(@Valid @RequestBody WechatLoginParamDTO paramDTO) throws Exception {
        String code = RSAUtils.decryptByPrivateKey(RSAKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getCode());
        if (StringUtils.isEmpty(code)) {
            log.warn("wechat code={} invalid", paramDTO.getCode());
            return ResultInfo.badRequest();
        }
        // 查询微信用户信息
        WechatUserInfoDTO wechatUserInfo = wechatHelper.getUserInfoForApp(code, wechatConfig.getAppId(), wechatConfig.getAppSecret());
        String headimgUrl = wechatUserInfo.getHeadimgUrl();
        headimgUrl = StringUtils.isEmpty(headimgUrl) ? vaxConfig.getAvatarUrl() : headimgUrl;

        User user = userService.getByWxOpenId(wechatUserInfo.getOpenId());
        // 创建用户
        if (user == null) {
            user = new User();
            user.setId(IDUtils.nextId());
            user.setWxOpenId(wechatUserInfo.getOpenId());
            user.setNickName(wechatUserInfo.getNickName());
            user.setHeadimgUrl(headimgUrl);
            user.setSecret(RandomStringUtils.randomAlphanumeric(16));
            user.setStatus(Constants.OK);
            user.setCreateTime(new Date());
            userService.save(user);
        } else {
            user.setWxOpenId(wechatUserInfo.getOpenId());
            user.setNickName(wechatUserInfo.getNickName());
            user.setHeadimgUrl(headimgUrl);
            user.setSecret(RandomStringUtils.randomAlphanumeric(16));
            user.setUpdateTime(new Date());
            userService.updateById(user);
        }
        UserSessionDTO sessionDTO = sessionHelper.create(user.getId(), user.getNickName(), user.getSecret(), AppEnum.APP_WEB.name());
        sessionDTO.setHeadimgUrl(headimgUrl);
        return ResultInfo.success().setData(sessionDTO);
    }
}