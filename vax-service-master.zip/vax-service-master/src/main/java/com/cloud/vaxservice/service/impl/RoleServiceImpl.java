package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.RoleDao;
import com.cloud.vaxservice.dto.RoleQueryParamDTO;
import com.cloud.vaxservice.entity.Role;
import com.cloud.vaxservice.service.RoleService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class RoleServiceImpl extends ServiceImpl<RoleDao, Role> implements RoleService {
    @Override
    public boolean checkNameExist(String name, Integer ignoreId) {
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq(Role.NAME, name);
        if (ignoreId != null) {
            wrapper.ne(Role.ID, ignoreId);
        }
        if (CollectionUtils.isEmpty(list(wrapper))) {
            return false;
        }
        return true;
    }

    @Override
    public Role getByName(String name) {
        QueryWrapper query = new QueryWrapper();
        query.eq(Role.NAME, name);
        return getOne(query);
    }

    @Override
    public PageInfo<Role> query(RoleQueryParamDTO paramDTO) {
        QueryWrapper query = new QueryWrapper();
        if (StringUtils.isNotEmpty(paramDTO.getName())) {
            query.like(Role.NAME, paramDTO.getName());
        }
        query.orderByDesc(Role.ID);
        IPage page =  page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), query);
        return new PageInfo(page);
    }
}
