package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 用户任务对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class UserTaskDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 任务ID
     */
    private String taskId;

    /**
     * 任务类型
     */
    private Integer taskType;

    /**
     * 任务状态
     */
    private Integer taskStatus;

    /**
     * 任务标题
     */
    private String taskTitle;

    /**
     * 任务结果
     */
    private String taskResult;

    /**
     * 支付积分
     */
    private Integer payScore;

    /**
     * 创建人ID
     */
    private Long createUser;

    /**
     * 更新人ID
     */
    private Long updateUser;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
