package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.config.ShareConfig;
import com.cloud.vaxservice.dto.UserTaskInsertParamDTO;
import com.cloud.vaxservice.dto.UserTaskQueryParamDTO;
import com.cloud.vaxservice.entity.UserTask;
import com.cloud.vaxservice.service.UserTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;

/**
 * 用户任务接口
 *
 * @author feng
 * @since 2021-11-28
 */
@Slf4j
@Controller
public class UserTaskController {
    @Autowired
    private UserTaskService userTaskService;

    @Autowired
    private ShareConfig shareConfig;

    /**
     * 根据任务ID获取查看链接
     *
     * @param taskId 任务ID
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/userTask/getViewUrl")
    public ResultInfo<String> getViewUrl(String taskId) {
        String viewUrl = shareConfig.getViewDomains().get(0);
        viewUrl = viewUrl + RequestContext.getRequest().getContextPath() + "/userTask/view/" + taskId;
        return ResultInfo.success().setData(viewUrl);
    }

    /**
     * 根据任务ID查看详情
     *
     * @param taskId 任务ID
     * @return String 响应结果
     */
    @GetMapping("/userTask/view/{taskId}")
    public String view(@PathVariable("taskId") String taskId, Model model) {
        UserTask userTask = userTaskService.getByTaskId(taskId);
        String result = userTask != null ? userTask.getTaskResult() : "";
        model.addAttribute("result", result);
        return "task";
    }

    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/userTask/query")
    public ResultInfo<PageInfo<UserTask>> query(@Valid @RequestBody UserTaskQueryParamDTO paramDTO) {
        paramDTO.setUserId(SessionContext.getUserId());
        PageInfo<UserTask> pageInfo = userTaskService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }

    /**
     * 新增
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/userTask/insert")
    public ResultInfo<String> insert(@Valid @RequestBody UserTaskInsertParamDTO paramDTO) {
        UserTask userTask = ObjectUtils.copy(paramDTO, UserTask.class);
        userTask.setCreateUser(SessionContext.getUserId());
        userTask.setCreateTime(new Date());
        userTaskService.save(userTask);
        return ResultInfo.success();
    }

    /**
     * 删除
     *
     * @param id
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/userTask/delete")
    public ResultInfo<String> delete(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        userTaskService.removeById(id);
        return ResultInfo.success();
    }
}