package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 支付单对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class PaymentDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 应用
     */
    private Integer app;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 订单号
     */
    private String orderNo;

    /**
     * 交易号
     */
    private String tradeNo;

    /**
     * 交易类型：1表示扫码支付，2表示JSAPI支付，3表示APP支付
     */
    private Integer tradeType;

    /**
     * 支付渠道：1表示微信，2表示支付宝
     */
    private Integer payChannel;

    /**
     * 支付金额（单位为分）
     */
    private Integer payMoney;

    /**
     * 支付标题
     */
    private String payTitle;

    /**
     * 支付状态：0表示未支付，1表示支付成功，2表示支付失败
     */
    private Integer payStatus;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
