package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/**
 * 充值参数
 *
 * @author feng
 * @since 2024/02/06
 */
@Data
public class RechargeParamDTO {
    @NotNull(message = "金额不能为空")
    private Integer money;

    @NotNull(message = "支付渠道不能为空")
    private Integer payChannel;

    @NotNull(message = "交易类型不能为空")
    private Integer tradeType;

    @NotEmpty(message = "描述不能为空")
    private String description;
}
