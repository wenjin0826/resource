package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.dao.ArticleDao;
import com.cloud.vaxservice.dto.ArticleQueryParamDTO;
import com.cloud.vaxservice.entity.Article;
import com.cloud.vaxservice.service.ArticleService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;

/**
 * 文章服务实现类
 *
 * @author feng
 * @since 2021-09-24
 */
@Slf4j
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleDao, Article> implements ArticleService {
    @Override
    public PageInfo<Article> query(ArticleQueryParamDTO paramDTO) {
        QueryWrapper<Article> wrapper = new QueryWrapper();
        if (StringUtils.isNotEmpty(paramDTO.getTitle())) {
            wrapper.like(Article.TITLE, paramDTO.getTitle());
        }
        if (paramDTO.getType() != null) {
            wrapper.eq(Article.TYPE, paramDTO.getType());
        }
        if (paramDTO.getStatus() != null) {
            wrapper.eq(Article.STATUS, paramDTO.getStatus());
        }
        wrapper.orderByDesc(Article.TOP);
        wrapper.orderByDesc(Article.PUBLISH_TIME);
        wrapper.orderByDesc(Article.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Article getTodayLatest() {
        LocalDate now = LocalDate.now();
        Date beginTime = DateTimeUtils.asDate(now);
        Date endTime = DateTimeUtils.asDate(now.plusDays(1));
        QueryWrapper<Article> wrapper = new QueryWrapper();
        wrapper.eq(Article.STATUS, Constants.OK);
        wrapper.ge(Article.PUBLISH_TIME, beginTime);
        wrapper.lt(Article.PUBLISH_TIME, endTime);
        wrapper.orderByDesc(Article.ID);
        return getOne(wrapper, false);
    }
}