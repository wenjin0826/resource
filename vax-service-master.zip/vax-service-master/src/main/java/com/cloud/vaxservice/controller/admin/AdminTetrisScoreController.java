package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.dto.TetrisScoreDTO;
import com.cloud.vaxservice.dto.TetrisScoreQueryParamDTO;
import com.cloud.vaxservice.entity.TetrisScore;
import com.cloud.vaxservice.service.TetrisScoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * 俄罗斯方块分数接口
 *
 * @author feng
 * @since 2022-09-25
 */
@Slf4j
@RestController
public class AdminTetrisScoreController {
    @Autowired
    private TetrisScoreService tetrisScoreService;

    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/tetrisScore/query")
    public ResultInfo<PageInfo<TetrisScoreDTO>> query(@Valid @RequestBody TetrisScoreQueryParamDTO paramDTO) {
        PageInfo<TetrisScore> pageInfo = tetrisScoreService.query(paramDTO);
        List<TetrisScoreDTO> list = ObjectUtils.copy(pageInfo.getRows(), TetrisScoreDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }
}