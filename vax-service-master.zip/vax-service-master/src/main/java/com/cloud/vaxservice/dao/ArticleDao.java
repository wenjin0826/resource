package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Article;

/**
 * 文章数据访问
 *
 * @author feng
 * @since 2021-09-24
 */
public interface ArticleDao extends BaseMapper<Article> {
}