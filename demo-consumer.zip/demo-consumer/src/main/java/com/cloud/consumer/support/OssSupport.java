package com.cloud.consumer.support;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.common.auth.CredentialsProvider;
import com.aliyun.oss.common.auth.DefaultCredentialProvider;
import com.aliyun.oss.model.DeleteObjectsRequest;
import com.cloud.common.sentinel.SentinelResource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.io.InputStream;
import java.util.List;

@Component
@SentinelResource
public class OssSupport {

    @Value("${oss.endpoint}")
    private String endpoint;

    @Value("${oss.accessKeyId}")
    private String accessKeyId;

    @Value("${oss.accessKeySecret}")
    private String accessKeySecret;

    @Value("${oss.bucketName}")
    private String bucketName;

    private OSSClient ossClient;

    @PostConstruct
    public void init() {
        CredentialsProvider credentialsProvider = new DefaultCredentialProvider(accessKeyId, accessKeySecret);
        ossClient = new OSSClient(endpoint, credentialsProvider, null);
    }

    public void putObject(String filePathName, InputStream input) {
        ossClient.putObject(bucketName, filePathName, input);
    }

    public void deleteObject(String filePathName) {
        ossClient.deleteObject(bucketName, filePathName);
    }

    public void deleteObjects(List<String> filePathNameList) {
        if (CollectionUtils.isEmpty(filePathNameList)) {
            return;
        }
        DeleteObjectsRequest request = new DeleteObjectsRequest(bucketName).withKeys(filePathNameList);
        ossClient.deleteObjects(request);
    }

    public String getUrl() {
        return "https://" + bucketName + "." + endpoint + "/";
    }

}
