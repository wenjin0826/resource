package com.cloud.consumer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.consumer.entity.User;

/**
 * <p>
 * 用户 服务类
 * </p>
 *
 * @author fengwenjin
 * @since 2019-02-16
 */
public interface UserService extends IService<User> {

}
