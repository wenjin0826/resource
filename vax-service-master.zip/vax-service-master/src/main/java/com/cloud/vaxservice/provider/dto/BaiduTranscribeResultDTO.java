package com.cloud.vaxservice.provider.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 转录结果
 *
 * @author feng
 * @since 2021/9/2
 */
@Data
public class BaiduTranscribeResultDTO {
    @JsonProperty("task_id")
    private String taskId;

    @JsonProperty("task_status")
    private String taskStatus;

    @JsonProperty("task_result")
    private TaskResult taskResult;

    @Data
    public static class TaskResult {
        @JsonProperty("result")
        private List<String> result;

        @JsonProperty("audio_duration")
        private Long audioDuration;

        @JsonProperty("err_msg")
        private String errMsg;
    }
}
