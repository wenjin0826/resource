package com.cloud.vaxservice.controller.admin;

import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.dto.RoleDTO;
import com.cloud.vaxservice.dto.RoleInsertParamDTO;
import com.cloud.vaxservice.dto.RoleQueryParamDTO;
import com.cloud.vaxservice.dto.RoleUpdateParamDTO;
import com.cloud.vaxservice.entity.Role;
import com.cloud.vaxservice.service.RoleService;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;

/**
 * 角色接口
 */
@Slf4j
@RestController
public class RoleAdminController {

    @Autowired
    private RoleService roleService;

    /**
     * 分页查询角色
     *
     * @param paramDTO 参数对象
     * @return ResultInfo
     */
    @PostMapping("/admin/role/query")
    public ResultInfo<PageInfo<RoleDTO>> queryRole(@Valid @RequestBody RoleQueryParamDTO paramDTO) {
        PageInfo pageInfo = roleService.query(paramDTO);
        List<RoleDTO> list = ObjectUtils.copy(pageInfo.getRows(), RoleDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 添加角色
     *
     * @param paramDTO
     * @return
     */
    @PostMapping("/admin/role/insert")
    public ResultInfo insertRole(@Valid @RequestBody RoleInsertParamDTO paramDTO) {
        if (roleService.checkNameExist(paramDTO.getName(), null)) {
            throw ErrorEnum.NAME_EXIST.exception();
        }
        Role role = ObjectUtils.copy(paramDTO, Role.class);
        roleService.save(role);
        return ResultInfo.success();
    }

    /**
     * 更新角色
     *
     * @param paramDTO 参数对象
     * @return
     */
    @PostMapping("/admin/role/update")
    public ResultInfo updateRole(@Valid @RequestBody RoleUpdateParamDTO paramDTO) {
        if (roleService.checkNameExist(paramDTO.getName(), paramDTO.getId())) {
            throw ErrorEnum.NAME_EXIST.exception();
        }
        Role role = ObjectUtils.copy(paramDTO, Role.class);
        roleService.updateById(role);
        return ResultInfo.success();
    }

    /**
     * 删除角色
     *
     * @param ids
     * @return
     */
    @PostMapping("/admin/role/delete")
    public ResultInfo deleteRole(@RequestBody List<Integer> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ResultInfo.badRequest();
        }
        roleService.removeByIds(ids);
        return ResultInfo.success();
    }
}
