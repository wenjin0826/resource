package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.constant.*;
import com.cloud.vaxservice.dto.RechargeDTO;
import com.cloud.vaxservice.dto.WxAppPayReqDTO;
import com.cloud.vaxservice.dto.YgosPayNotifyDTO;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.pay.AliPayAdapter;
import com.cloud.vaxservice.pay.WxappPayAdapter;
import com.cloud.vaxservice.service.PaymentService;
import com.cloud.vaxservice.service.UserService;
import com.egzosn.pay.common.bean.PayOutMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.util.Date;

/**
 * 支付接口
 */
@Slf4j
@RestController
public class PayController {
    @Autowired
    private UserService userService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private WxappPayAdapter wxpayAdapter;

    @Autowired
    private AliPayAdapter aliPayAdapter;

    /**
     * 微信支付充值
     *
     * @param money 金额
     * @return ResultInfo<RechargeDTO>
     */
    @PostMapping("/wxpay/recharge")
        public ResultInfo<RechargeDTO> recharge(Integer money) {
        if (money == null) {
            return ResultInfo.badRequest();
        }

        User user = userService.getById(SessionContext.getUserId());
        Payment payment = createPayment(money, user, PayChannelEnum.WECHAT_PAY, TradeTypeEnum.APP);

        String wxpayReqStr = wxpayAdapter.orderInfo(payment.getTradeType(), payment.getPayTitle(), payment.getPayMoney(), payment.getOrderNo(), user.getWxOpenId());

        RechargeDTO rechargeDTO = new RechargeDTO();
        rechargeDTO.setPaymentId(payment.getId());
        rechargeDTO.setWxAppPayReq(JsonUtils.parseObject(wxpayReqStr, WxAppPayReqDTO.class));
        return ResultInfo.success().setData(rechargeDTO);
    }

    private Payment createPayment(Integer money, User user, PayChannelEnum payChannel, TradeTypeEnum tradeType) {
        Payment payment = new Payment();
        payment.setApp(user.getApp());
        payment.setUserId(user.getId());
        payment.setOrderNo(DateTimeUtils.timeSequence());
        payment.setTradeType(tradeType.getCode());
        payment.setPayChannel(payChannel.getCode());
        payment.setPayStatus(PayStatusEnum.UNDO.getCode());
        payment.setPayMoney(money);
        payment.setPayTitle(payChannel.getDescription());
        paymentService.save(payment);
        return payment;
    }

    /**
     * 支付宝充值
     *
     * @param money 金额
     * @return ResultInfo<RechargeDTO>
     */
    @PostMapping("/alipay/recharge")
    public ResultInfo<RechargeDTO> alipayRecharge(Integer money, Integer clientType, HttpServletRequest request) {
        if (money == null) {
            return ResultInfo.badRequest();
        }

        String appVersion = request.getHeader("AppVersion");
        log.info("appVersion={}", appVersion);
        if (StringUtils.isNotEmpty(appVersion)) {
            int version = Integer.parseInt(appVersion.replace("VaxApp-", ""));
            if (version < 153) {
                return ResultInfo.failure().setMessage("请按升级提示，更新到最新版本");
            }
        }
        TradeTypeEnum tradeType = TradeTypeEnum.APP;
        if (PayClientTypeEnum.of(clientType) == PayClientTypeEnum.H5) {
            tradeType = TradeTypeEnum.H5;
        }
        User user = userService.getById(SessionContext.getUserId());
        Payment payment = createPayment(money, user, PayChannelEnum.ALI_PAY, tradeType);

        String aliPayData;
        if (tradeType == TradeTypeEnum.APP) {
            aliPayData = aliPayAdapter.appPay(payment.getOrderNo(), money, "提取文字");
        } else if (tradeType == TradeTypeEnum.H5){
            aliPayData = aliPayAdapter.h5Pay(payment.getOrderNo(), money, "提取文字");
        } else {
            return ResultInfo.badRequest();
        }
        RechargeDTO rechargeDTO = new RechargeDTO();
        rechargeDTO.setPaymentId(payment.getId());
        rechargeDTO.setAliPayData(aliPayData);
        return ResultInfo.success().setData(rechargeDTO);
    }

    /**
     * 获取充值状态
     *
     * @param paymentId
     * @return
     */
    @PostMapping("/pay/getStatus")
    public ResultInfo<Integer> getStatus(Integer paymentId) {
        if (paymentId == null) {
            return ResultInfo.badRequest();
        }
        Integer status = paymentService.getStatus(paymentId);
        return ResultInfo.success().setData(status);
    }

    /**
     * 微信支付回调通知
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/pay/wxNotify")
    public void wxPayNotify(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PayOutMessage payOutMessage = wxpayAdapter.payBack(request.getParameterMap(), request.getInputStream());
        if (payOutMessage != null) {
            Writer writer = response.getWriter();
            writer.write(payOutMessage.toMessage());
            writer.flush();
        }
    }

    /**
     * 支付宝回调通知
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/pay/alipayNotify")
    public void alipayNotify(HttpServletRequest request, HttpServletResponse response) throws IOException {
        YgosPayNotifyDTO notifyDTO = new YgosPayNotifyDTO();
        notifyDTO.setCode(request.getParameter("code"));
        notifyDTO.setMchId(request.getParameter("mchId"));
        notifyDTO.setOutTradeNo(request.getParameter("outTradeNo"));
        notifyDTO.setOrderNo(request.getParameter("orderNo"));
        notifyDTO.setPayNo(request.getParameter("payNo"));
        log.info("alipayNotify >>> {}", JsonUtils.toJSONString(notifyDTO));

        Writer writer = response.getWriter();
        final String failure = "FAILURE";
        String orderNo = notifyDTO.getOutTradeNo();
        if (StringUtils.isEmpty(orderNo)) {
            writer.write(failure);
            writer.flush();
            return;
        }

        String lockKey = "Lock:Payment:" + orderNo;
        if (!RemoteLock.lock(lockKey, 0)) {
            writer.write(failure);
            writer.flush();
            return;
        }

        try {
            Payment payment = paymentService.getByOrderNo(orderNo);
            if (payment == null || payment.getPayStatus() != PayStatusEnum.UNDO.getCode()) {
                writer.write(failure);
                writer.flush();
                return;
            }
            payment.setTradeNo(notifyDTO.getPayNo());
            payment.setUpdateTime(new Date());
            if (notifyDTO.getCode().equals(String.valueOf(Constants.OK))) {
                payment.setPayStatus(PayStatusEnum.PAID.getCode());
                paymentService.handlePaid(payment);
            } else {
                payment.setPayStatus(PayStatusEnum.PAID_FAIL.getCode());
                paymentService.updateById(payment);
            }
            writer.write("SUCCESS");
            writer.flush();
            return;
        } catch (Exception e) {
            log.error("alipay notify handle error", e);
        } finally {
            RemoteLock.unlock(lockKey);
        }
        writer.write(failure);
        writer.flush();
        return;
    }
}
