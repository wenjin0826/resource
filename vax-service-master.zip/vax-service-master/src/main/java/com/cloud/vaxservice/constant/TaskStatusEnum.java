package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum TaskStatusEnum {
    // 处理中
    RUNNING("Running"),
    // 处理成功
    SUCCESS("Success"),
    // 处理失败
    FAILURE("Failure");

    @Getter
    private String status;

    TaskStatusEnum(String status) {
        this.status = status;
    }

    public static TaskStatusEnum of(String status) {
        for (TaskStatusEnum taskStatusEnum : values()) {
            if (taskStatusEnum.status.equals(status)) {
                return taskStatusEnum;
            }
        }
        return null;
    }
}
