package com.cloud.vaxservice.dto;

import com.cloud.common.validator.EnumCheck;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 转录任务新增参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class TranscribeCreateParamDTO {
    private String taskTitle;

    @NotEmpty(message = "语言环境不能为空")
    @EnumCheck(values = "ZH_CN,EN_US")
    private String locale;

    @NotEmpty(message = "文件格式不能为空")
    private String format;

    @NotEmpty(message = "音频文件地址不能为空")
    private String audioUrl;

    private Integer audioSeconds;
}