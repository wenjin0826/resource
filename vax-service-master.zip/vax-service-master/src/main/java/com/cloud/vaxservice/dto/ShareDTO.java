package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 分享对象
 *
 * @author feng
 * @since 2022/06/11
 */
@Data
public class ShareDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 渠道 0未知 1表示微信
     */
    private Integer channel;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 文章ID
     */
    private Integer articleId;

    /**
     * 阅读数
     */
    private Integer viewCount;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建时间
     */
    private Date updateTime;

}