package com.cloud.consumer.job;

import com.cloud.consumer.es.IndexProduct;
import com.cloud.consumer.es.support.ElasticsearchSupport;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.JobHandler;
import com.xxl.job.core.log.XxlJobLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.Date;

@Slf4j
@Component
@JobHandler(value="IndexCreateJob")
public class IndexCreateJob extends IJobHandler implements ApplicationRunner {

    @Autowired
    private ElasticsearchSupport elasticsearchSupport;

    @Override
    public ReturnT<String> execute(String param) {
        log.info("param={}", param);
        try {
            createIndex();
            return ReturnT.SUCCESS;
        } catch (Exception e) {
            log.error("execute error", e);
            XxlJobLogger.log(e);
            return ReturnT.FAIL;
        }
    }

    @Override
    public void run(ApplicationArguments args) {
        createIndex();
    }

    private void createIndex() {
        String indexDate = elasticsearchSupport.indexYear(new Date());
        elasticsearchSupport.createIndex(IndexProduct.class, indexDate);
    }
}
