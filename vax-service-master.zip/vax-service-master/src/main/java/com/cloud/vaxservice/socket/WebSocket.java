package com.cloud.vaxservice.socket;

import com.cloud.common.util.TokenUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.handler.AbstractWebSocketHandler;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@EnableWebSocket
public class WebSocket implements WebSocketConfigurer {
    private static final String USER_ID = "userId";
    private static Map<String, WebSocketSession> sessionMap = new HashMap<>();

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(new DefaultWebSocketHandler(), "/websocket").setAllowedOrigins("*"); // 允许所有来源
    }

    public void publish(String message) {
        sessionMap.values().forEach(session -> {
            try {
                session.sendMessage(new TextMessage(message));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        });
    }

    class DefaultWebSocketHandler extends AbstractWebSocketHandler {

        private String getToken(String queryStr) {
            String[] params = queryStr.split("&");
            for (String param : params) {
                String[] keyValue = param.split("=");
                if ("token".equals(keyValue[0])) {
                    return keyValue[1];
                }
            }
            return null;
        }

        @Override
        public void afterConnectionEstablished(WebSocketSession session) throws Exception {
            URI uri = session.getUri();
            String queryStr = uri.getQuery();
            if (queryStr != null) {
                String token = getToken(queryStr);
                log.info("token >>> " + token);
                TokenUtils.AppUser appUser = TokenUtils.parse(token);
                if (appUser != null) {
                    session.getAttributes().put(USER_ID, appUser.getUserId());
                    sessionMap.put(appUser.getUserId(), session);
                    return;
                }
            }
            session.close();
        }

        @Override
        public void handleTextMessage(WebSocketSession session, TextMessage message) {
            Object userId = session.getAttributes().get(USER_ID);
            log.info("websocket receive userId={}, message >>> {}", userId, message.getPayload());
        }
    }
}
