package com.cloud.common.support;

import com.cloud.common.context.RequestContext;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

/**
 * 身份证脱敏序列化
 *
 * @author fengwenjin
 */
public class JsonIdCardSerializer extends JsonSerializer {
    @Override
    public void serialize(Object value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        if (RequestContext.isMaskData() && value != null && value instanceof String) {
            String valueStr = value.toString();
            if (valueStr.length() > 10) {
                String idCard = valueStr.substring(0, 6) + "********" + valueStr.substring(valueStr.length() - 4);
                gen.writeString(idCard);
                return;
            }
        }
        gen.writeObject(value);
    }
}
