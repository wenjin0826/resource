package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.TetrisScoreDao;
import com.cloud.vaxservice.dto.TetrisScoreQueryParamDTO;
import com.cloud.vaxservice.entity.TetrisScore;
import com.cloud.vaxservice.service.TetrisScoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 俄罗斯方块分数服务实现类
 *
 * @author feng
 * @since 2022/09/20
 */
@Slf4j
@Service
public class TetrisScoreServiceImpl extends ServiceImpl<TetrisScoreDao, TetrisScore> implements TetrisScoreService {

    @Override
    public PageInfo<TetrisScore> query(TetrisScoreQueryParamDTO paramDTO) {
        QueryWrapper<TetrisScore> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.likeLeft(TetrisScore.USER_ID, paramDTO.getUserId());
        }
        wrapper.orderByDesc(TetrisScore.GAME_SCORE);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public List<TetrisScore> queryTop(int topSize) {
        QueryWrapper<TetrisScore> wrapper = new QueryWrapper<>();
        wrapper.orderByDesc(TetrisScore.GAME_SCORE);
        wrapper.last("limit " + topSize);
        return list(wrapper);
    }

    @Override
    public TetrisScore getByUserId(Long userId) {
        QueryWrapper<TetrisScore> wrapper = new QueryWrapper<>();
        wrapper.eq(TetrisScore.USER_ID, userId);
        return getOne(wrapper, false);
    }
}
