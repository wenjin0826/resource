package com.cloud.vaxservice.okx.dto;

import lombok.Data;

import java.util.List;

/**
 * 蜡烛K线结果
 *
 * @author feng
 * @since 2024/03/08
 */
@Data
public class CandleResultDTO {
    private String code;
    private String msg;
    private List<CandleDataDTO> data;
}
