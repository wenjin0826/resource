package com.cloud.vaxservice.browser;

/**
 * 功能描述
 *
 * @author feng
 * @since 2024/01/13
 */
public class JavaScriptBridge {
    private InvokeFuture invokeFuture;

    public JavaScriptBridge(InvokeFuture invokeFuture) {
        this.invokeFuture = invokeFuture;
    }

    public void callback(String docHTML, String pageInfo) {
        invokeFuture.setResult(new HttpResponse(docHTML, pageInfo));
    }
}
