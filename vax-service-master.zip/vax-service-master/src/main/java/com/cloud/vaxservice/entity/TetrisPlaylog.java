package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 俄罗斯方块游戏日志实体类
 *
 * @author feng
 * @since 2022/10/05
 */
@Data
@TableName("t_tetris_playlog")
public class TetrisPlaylog implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 用户IP
     */
    @TableField("user_ip")
    private String userIp;

    /**
     * 游戏分数
     */
    @TableField("game_score")
    private Integer gameScore;

    /**
     * 游戏级别
     */
    @TableField("game_level")
    private Integer gameLevel;

    /**
     * 游戏速度
     */
    @TableField("game_speed")
    private Integer gameSpeed;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String USER_IP = "user_ip";
    public static final String GAME_SCORE = "game_score";
    public static final String GAME_LEVEL = "game_level";
    public static final String GAME_SPEED = "game_speed";
    public static final String CREATE_TIME = "create_time";
}
