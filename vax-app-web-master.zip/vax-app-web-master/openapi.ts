const { generateService } = require("@umijs/openapi");

generateService({
    requestLibPath: "import request from '@/commons/request'",
    schemaPath: "http://localhost:8000/vax-service/v3/api-docs/default",
    serversPath: "./src",
});