package com.cloud.vaxservice.provider;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.config.ZmProxyConfig;
import com.cloud.vaxservice.provider.dto.ZmProxyDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

/**
 * 功能描述
 *
 * @author feng
 * @since 2023/12/16
 */
@Slf4j
@Component
public class ZmProvider {
    @Autowired
    private ZmProxyConfig zmProxyConfig;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private ZmProxyDTO proxyDTO;

    public synchronized ZmProxyDTO getProxy() {
        if (proxyDTO != null && validTime(proxyDTO)) {
            return proxyDTO;
        }

        try {
            final String cacheKey = "ZmProxy";
            String proxyData = (String) redisTemplate.opsForValue().get(cacheKey);
            proxyDTO = proxyData != null ? JsonUtils.parseObject(proxyData, ZmProxyDTO.class) : null;
            if (proxyDTO != null && validTime(proxyDTO)) {
                return proxyDTO;
            }
            log.info("request ZmProxy apiUrl >>> {}", zmProxyConfig.getApiUrl());
            String result = restTemplate.getForObject(zmProxyConfig.getApiUrl(), String.class);
            log.info("result >>> {}", result);

            JSONObject jsonObject = JSON.parseObject(result);
            if (jsonObject.getBoolean("success")) {
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                if (!jsonArray.isEmpty()) {
                    String proxyStr = jsonArray.getJSONObject(0).toString();
                    proxyDTO = JsonUtils.parseObject(proxyStr, ZmProxyDTO.class);
                    redisTemplate.opsForValue().set(cacheKey, JsonUtils.toJSONString(proxyDTO));
                }
            }
            return proxyDTO;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    private boolean validTime(ZmProxyDTO proxyDTO) {
        Date date = DateTimeUtils.fromDateTimeString(proxyDTO.getExpireTime());
        if (date.after(new Date(System.currentTimeMillis() + 60000))) {
            return true;
        }
        return false;
    }
}
