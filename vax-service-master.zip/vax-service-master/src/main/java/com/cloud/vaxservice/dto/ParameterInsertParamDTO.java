package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotEmpty;

/**
 * 参数新增参数
 *
 * @author feng
 * @since 2024/03/14
 */
@Data
public class ParameterInsertParamDTO {
    /**
     * 参数key
     */
    @NotEmpty(message = "参数key不能为空")
    private String paramKey;

    /**
     * 参数值
     */
    @NotEmpty(message = "参数值不能为空")
    private String paramValue;

}
