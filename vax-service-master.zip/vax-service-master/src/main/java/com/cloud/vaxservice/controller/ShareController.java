package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.vaxservice.support.ShareHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 分享接口
 *
 * @author feng
 * @since 2022/06/11
 */
@Slf4j
@Controller
public class ShareController {
    @Autowired
    private ShareHelper shareHelper;

    @RequestMapping("/share/open/{idCode}")
    public String openShare(@PathVariable("idCode") String idCode) {
        return "share";
    }

    @RequestMapping("/share/view/{idCode}")
    public String viewShare(@PathVariable("idCode") String idCode, Model model) {
        Integer articleId = shareHelper.decode(idCode);
        model.addAttribute("articleId", articleId);
        return "article";
    }

    @ResponseBody
    @PostMapping("/share/getViewUrl")
    public ResultInfo<String> getShareViewUrl(String idCode) {
        if (StringUtils.isEmpty(idCode)) {
            return ResultInfo.badRequest();
        }
        String viewUrl = shareHelper.getViewUrl(idCode);
        return ResultInfo.success().setData(viewUrl);
    }
}