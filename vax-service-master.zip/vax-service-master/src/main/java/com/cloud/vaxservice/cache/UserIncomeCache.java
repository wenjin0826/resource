package com.cloud.vaxservice.cache;

import com.cloud.vaxservice.dto.IncomeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class UserIncomeCache {
    private static final String INCOME_KEY_PREFIX = "UserIncome:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public IncomeDTO getIncome(Long userId) {
        return (IncomeDTO) redisTemplate.opsForValue().get(INCOME_KEY_PREFIX + userId);
    }

    public void saveIncome(Long userId, IncomeDTO incomeDTO) {
        redisTemplate.opsForValue().set(INCOME_KEY_PREFIX + userId, incomeDTO, 5, TimeUnit.MINUTES);
    }
}
