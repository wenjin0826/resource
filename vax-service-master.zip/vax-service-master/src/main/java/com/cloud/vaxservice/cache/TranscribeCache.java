package com.cloud.vaxservice.cache;

import com.cloud.vaxservice.entity.Transcribe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class TranscribeCache {

    private static final String STRING_KEY_PREFIX = "Transcribe:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public Transcribe get(String taskId) {
        String key = STRING_KEY_PREFIX + taskId;
        return (Transcribe) redisTemplate.opsForValue().get(key);
    }

    public void save(Transcribe transcribe) {
        if (transcribe != null) {
            String key = STRING_KEY_PREFIX + transcribe.getTaskId();
            redisTemplate.opsForValue().set(key, transcribe, 5, TimeUnit.MINUTES);
        }
    }
}
