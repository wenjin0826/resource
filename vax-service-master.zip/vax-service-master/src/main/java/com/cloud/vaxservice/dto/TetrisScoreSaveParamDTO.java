package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 俄罗斯方块分数保存参数
 *
 * @author feng
 * @since 2022/09/20
 */
@Data
public class TetrisScoreSaveParamDTO {
    /**
     * 票据
     */
    private String ticket;

    /**
     * 游戏分数
     */
    private Integer gameScore;
}
