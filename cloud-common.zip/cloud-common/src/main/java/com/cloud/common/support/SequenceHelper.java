package com.cloud.common.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class SequenceHelper {

    private static final String KEY_PREFIX = "Sequence:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 初始化序列
     *
     * @param key
     * @param value
     */
    public void init(String key, long value) {
        redisTemplate.delete(KEY_PREFIX + key);
        redisTemplate.opsForValue().increment(KEY_PREFIX + key, value);
    }

    /**
     * 获取自增序列
     *
     * @return long
     */
    public long increment(String key) {
        return redisTemplate.opsForValue().increment(KEY_PREFIX + key);
    }

}