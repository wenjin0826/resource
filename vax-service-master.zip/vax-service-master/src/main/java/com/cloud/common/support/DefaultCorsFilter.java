package com.cloud.common.support;

import org.springframework.http.HttpHeaders;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 跨域拦截器
 *
 * @author fengwenjin
 */
public class DefaultCorsFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        if (!isWebSocketFirstRequest(request)) {
            response.setHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, "*");
            response.setHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_METHODS, "*");
            response.setHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_HEADERS, "*");
            response.setHeader(HttpHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");
            response.setHeader(HttpHeaders.ACCESS_CONTROL_MAX_AGE, "18000");
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    private boolean isWebSocketFirstRequest(HttpServletRequest request) {
        if (request.getRequestURI().endsWith("/websocket/info")) {
            return true;
        }
        return false;
    }
}
