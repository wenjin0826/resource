package com.cloud.vaxservice.controller.admin;

import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.dto.TetrisRewardDTO;
import com.cloud.vaxservice.dto.TetrisRewardQueryParamDTO;
import com.cloud.vaxservice.entity.TetrisReward;
import com.cloud.vaxservice.service.TetrisRewardService;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * 俄罗斯方块奖励接口
 *
 * @author feng
 * @since 2022-09-25
 */
@Slf4j
@RestController
public class AdminTetrisRewardController {
    @Autowired
    private TetrisRewardService tetrisRewardService;

    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/tetrisReward/query")
    public ResultInfo<PageInfo<TetrisRewardDTO>> query(@Valid @RequestBody TetrisRewardQueryParamDTO paramDTO) {
        PageInfo<TetrisReward> pageInfo = tetrisRewardService.query(paramDTO);
        List<TetrisRewardDTO> list = ObjectUtils.copy(pageInfo.getRows(), TetrisRewardDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 根据条件分页查询
     *
     * @param id 编号ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/tetrisReward/confirmPaid")
    public ResultInfo<String> confirmPaid(Long id) {
        TetrisReward tetrisReward = tetrisRewardService.getById(id);
        if (tetrisReward != null) {
            tetrisReward.setPaid(Constants.OK);
            tetrisRewardService.updateById(tetrisReward);
        }
        return ResultInfo.success();
    }
}