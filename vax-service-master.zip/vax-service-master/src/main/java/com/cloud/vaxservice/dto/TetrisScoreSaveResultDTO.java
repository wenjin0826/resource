package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 俄罗斯方块分数保存结果
 *
 * @author feng
 * @since 2022/09/20
 */
@Data
public class TetrisScoreSaveResultDTO {
    /**
     * 激励广告点击是否启用
     */
    private boolean inspireClickEnable;

    /**
     * 中奖级别
     */
    private Integer rewardLevel;

    /**
     * 中奖级别描述
     */
    private String rewardLevelDesc;

    /**
     * 分数描述
     */
    private String scoreDesc;
}
