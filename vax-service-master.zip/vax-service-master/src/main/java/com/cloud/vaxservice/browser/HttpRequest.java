package com.cloud.vaxservice.browser;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能描述
 *
 * @author feng
 * @since 2024/01/13
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HttpRequest {
    String loadUrl;
    String redirectUrl;
    String userAgent;
}

