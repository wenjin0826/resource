package com.cloud.consumer.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.consumer.dao.UserDao;
import com.cloud.consumer.entity.User;
import com.cloud.consumer.provider.MessageProvider;
import com.cloud.consumer.service.UserService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;

/**
 * <p>
 * 用户 服务实现类
 * </p>
 *
 * @author fengwenjin
 * @since 2019-02-16
 */
@Setter
@Service
public class UserServiceImpl extends ServiceImpl<UserDao, User> implements UserService {

    @Autowired
    private MessageProvider messageProvider;

    @Override
    public User getById(Serializable id) {
        return super.getById(id);
    }

}
