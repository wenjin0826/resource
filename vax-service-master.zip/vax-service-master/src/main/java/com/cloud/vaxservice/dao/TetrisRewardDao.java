package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.TetrisReward;

/**
 * 俄罗斯方块中奖数据访问
 *
 * @author feng
 * @since 2022/09/23
 */
public interface TetrisRewardDao extends BaseMapper<TetrisReward> {
}
