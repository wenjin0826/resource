package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Invite;

/**
 * 邀请数据访问
 *
 * @author feng
 * @since 2022/09/24
 */
public interface InviteDao extends BaseMapper<Invite> {
}
