package com.cloud.vaxservice.support;

import com.cloud.common.bean.SessionInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.support.SessionCache;
import com.cloud.common.util.AESUtils;
import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.vaxservice.dto.UserExtraInfo;
import com.cloud.vaxservice.dto.UserSessionDTO;
import com.cloud.vaxservice.entity.User;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author fengwenjin
 * @since 2021/11/21
 */
@Component
public class SessionHelper {
    @Autowired
    private SessionCache sessionCache;

    public UserSessionDTO createUserSession(User user, AppEnum appEnum) throws Exception {
        // 创建会话
        SessionInfo sessionInfo = new SessionInfo();
        sessionInfo.setSecret(user.getSecret());
        sessionInfo.setAppName(appEnum.name());
        sessionInfo.setUserId(user.getId().longValue());
        sessionInfo.setNickName(user.getNickName());

        UserExtraInfo userExtraInfo = new UserExtraInfo();
        userExtraInfo.setPhone(user.getPhone());
        userExtraInfo.setWxOpenId(user.getWxOpenId());
        sessionInfo.setExtraInfo(userExtraInfo);
        String accessToken = sessionCache.save(sessionInfo, 24 * 3600);
        String refreshToken = AESUtils.encrypt(user.getSecret(), DigestUtils.md5Hex(accessToken));

        // 返回结果
        UserSessionDTO sessionDTO = new UserSessionDTO();
        sessionDTO.setAccessToken(accessToken);
        sessionDTO.setRefreshToken(refreshToken);
        sessionDTO.setUserId(user.getId());
        sessionDTO.setSecret(user.getSecret());
        sessionDTO.setScore(user.getScore());
        sessionDTO.setNickName(user.getNickName());
        sessionDTO.setHeadimgUrl(user.getHeadimgUrl());
        return sessionDTO;
    }

    public String decrypt(String refreshToken, String accessToken) throws Exception {
        return AESUtils.decrypt(refreshToken, DigestUtils.md5Hex(accessToken));
    }

    public void logout() {
        SessionInfo sessionInfo = SessionContext.get();
        if (sessionInfo != null) {
            sessionCache.remove(sessionInfo.getAppName(), sessionInfo.getUserId());
        }
    }
}
