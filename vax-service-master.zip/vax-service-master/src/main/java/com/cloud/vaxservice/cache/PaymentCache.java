package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class PaymentCache {

    private static final String STRING_PAYMENT_STATUS_KEY_PREFIX = "PaymentStatus:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public Integer getStatus(Integer paymentId) {
        return (Integer) redisTemplate.opsForValue().get(STRING_PAYMENT_STATUS_KEY_PREFIX + paymentId);
    }

    public void saveStatus(Integer paymentId, Integer status) {
        redisTemplate.opsForValue().set(STRING_PAYMENT_STATUS_KEY_PREFIX + paymentId, status, 300, TimeUnit.SECONDS);
    }

}
