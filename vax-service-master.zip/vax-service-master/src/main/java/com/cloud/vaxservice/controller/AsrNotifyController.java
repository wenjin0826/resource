package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.dto.AsrTencentNotifyParamDTO;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.provider.TencentAsrProvider;
import com.cloud.vaxservice.service.TranscribeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * ASR通知接口
 *
 * @author feng
 * @since 2021-12-31
 */
@Slf4j
@RestController
public class AsrNotifyController {
    @Autowired
    private TencentAsrProvider tencentAsrProvider;

    @Autowired
    private TranscribeService transcribeService;

    /**
     * 根据任务ID获取数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/asr/tencentNotify")
    public ResultInfo<String> tencentNotify(AsrTencentNotifyParamDTO paramDTO) {
        log.info("asr tencentNotify >>> code={} taskId={}", paramDTO.getCode(), paramDTO.getRequestId());
        if (paramDTO.getRequestId() == null || paramDTO.getCode() == null) {
            return ResultInfo.badRequest();
        }
        try {
            Transcribe transcribe = transcribeService.getByTaskId(paramDTO.getRequestId().toString());
            if (transcribe == null) {
                return ResultInfo.badRequest();
            }
            if (transcribe.getTaskStatus().equals(TaskStatusEnum.RUNNING.getStatus())) {
                if (paramDTO.getCode().equals(0)) {
                    // 成功
                    String taskResult = tencentAsrProvider.getTaskResult(paramDTO.getText(), transcribe.getLanguage());
                    transcribe.setTaskResult(taskResult);
                    transcribe.setAudioDuration(paramDTO.getAudioTime().longValue());
                    transcribeService.updateResult(TaskStatusEnum.SUCCESS, transcribe);
                } else {
                    // 失败
                    transcribeService.updateResult(TaskStatusEnum.FAILURE, transcribe);
                    log.warn("asr tencentNotify failure >>> {}", paramDTO);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ResultInfo.success().setCode(0).setMessage("success");
    }
}
