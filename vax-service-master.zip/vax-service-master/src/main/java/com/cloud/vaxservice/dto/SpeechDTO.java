package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 转录结果
 *
 * @author feng
 * @since 2021/9/2
 */
@Data
public class SpeechDTO {
    private String taskId;
    private String taskStatus;
    private Integer audioUrl;
    private Date updateTime;
}
