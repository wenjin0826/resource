package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 用户扩展信息
 *
 * @author feng
 * @since 2022/09/19
 */
@Data
public class UserExtraInfo {
    /**
     * 手机号
     */
    private String phone;

    /**
     * 微信Openid
     */
    private String wxOpenId;
}
