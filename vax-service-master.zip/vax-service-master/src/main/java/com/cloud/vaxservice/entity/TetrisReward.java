package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 俄罗斯方块中奖实体类
 *
 * @author feng
 * @since 2022/10/02
 */
@Data
@TableName("t_tetris_reward")
public class TetrisReward implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 用户昵称
     */
    @TableField("nick_name")
    private String nickName;

    /**
     * 游戏分数
     */
    @TableField("game_score")
    private Integer gameScore;

    /**
     * 奖励级别
     */
    @TableField("reward_level")
    private Integer rewardLevel;

    /**
     * 是否付款：0未支付 1已支付
     */
    @TableField("paid")
    private Integer paid;

    /**
     * 备注描述
     */
    @TableField("description")
    private String description;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;


    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String NICK_NAME = "nick_name";
    public static final String GAME_SCORE = "game_score";
    public static final String REWARD_LEVEL = "reward_level";
    public static final String PAID = "paid";
    public static final String DESCRIPTION = "description";
    public static final String CREATE_TIME = "create_time";
}
