package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.dto.ArticleDTO;
import com.cloud.vaxservice.dto.ArticleInsertParamDTO;
import com.cloud.vaxservice.dto.ArticleQueryParamDTO;
import com.cloud.vaxservice.dto.ArticleUpdateParamDTO;
import com.cloud.vaxservice.entity.Article;
import com.cloud.vaxservice.service.ArticleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.Date;
import java.util.List;

/**
 * 文章接口
 *
 * @author feng
 * @since 2021-09-24
 */
@Slf4j
@RestController
public class ArticleAdminController {
    @Autowired
    private ArticleService articleService;

    /**
     * 根据主键ID获取数据
     *
     * @param id 主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/article/get")
    public ResultInfo<ArticleDTO> getArticle(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        Article article = articleService.getById(id);
        return ResultInfo.success().setData(ObjectUtils.copy(article, ArticleDTO.class));
    }
    
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/article/query")
    public ResultInfo<PageInfo<ArticleDTO>> queryArticle(@Valid @RequestBody ArticleQueryParamDTO paramDTO) {
        PageInfo<Article> pageInfo = articleService.query(paramDTO);
        List<ArticleDTO> list = ObjectUtils.copy(pageInfo.getRows(), ArticleDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 新增数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/article/insert")
    public ResultInfo insertArticle(@Valid @RequestBody ArticleInsertParamDTO paramDTO) {
        Article article = ObjectUtils.copy(paramDTO, Article.class);
        article.setStatus(Constants.OK);
        articleService.save(article);
        return ResultInfo.success();
    }

    /**
     * 更新数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/article/update")
    public ResultInfo updateArticle(@Valid @RequestBody ArticleUpdateParamDTO paramDTO) {
        Article article = ObjectUtils.copy(paramDTO, Article.class);
        article.setUpdateTime(new Date());
        articleService.updateById(article);
        return ResultInfo.success();
    }
    
    /**
     * 根据主键ID批量删除
     *
     * @param ids 批量主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/article/delete")
    public ResultInfo deleteArticle(@RequestBody List<Integer> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ResultInfo.badRequest();
        }
        articleService.removeByIds(ids);
        return ResultInfo.success();
    }
}