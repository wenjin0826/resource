package com.cloud.consumer.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.consumer.dto.WechatSignDTO;
import com.cloud.consumer.support.WechatSupport;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/wechat")
public class WechatController {

    @Autowired
    private WechatSupport wechatSupport;

    @GetMapping("/getSignature")
    public ResultInfo<WechatSignDTO> get(String url) {
        return ResultInfo.success().setData(wechatSupport.getSignature(url));
    }
}
