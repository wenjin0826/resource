package com.cloud.common.limit;

import lombok.Data;

/**
 * 限制信息
 *
 * @author fengwenjin
 */
@Data
public class LimitInfo {
    private int count;
    private long beginTime;
}
