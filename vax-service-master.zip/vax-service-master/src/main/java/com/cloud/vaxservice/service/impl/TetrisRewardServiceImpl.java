package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.TetrisRewardDao;
import com.cloud.vaxservice.dto.TetrisRewardQueryParamDTO;
import com.cloud.vaxservice.entity.TetrisReward;
import com.cloud.vaxservice.service.TetrisRewardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 俄罗斯方块中奖服务实现类
 *
 * @author feng
 * @since 2022/09/23
 */
@Slf4j
@Service
public class TetrisRewardServiceImpl extends ServiceImpl<TetrisRewardDao, TetrisReward> implements TetrisRewardService {
    @Override
    public PageInfo<TetrisReward> query(TetrisRewardQueryParamDTO paramDTO) {
        QueryWrapper<TetrisReward> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(TetrisReward.USER_ID, paramDTO.getUserId());
        }
        wrapper.orderByDesc(TetrisReward.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }
}
