package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.vaxservice.dto.UserQueryParamDTO;
import com.cloud.vaxservice.entity.User;
import com.cloud.common.bean.PageInfo;

/**
 * 用户服务接口
 *
 * @author feng
 * @since 2021-09-02
 */
public interface UserService extends IService<User> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<User> query(UserQueryParamDTO paramDTO);

    /**
     * 根据手机号查询
     *
     * @param phone
     * @return User
     */
    User getByPhone(String phone);

    /**
     * 根据微信Openid查询
     *
     * @param wxOpenId
     * @return User
     */
    User getByWxOpenId(String wxOpenId);
}