package com.cloud.consumer.util;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.List;

public class BeanInfoUtils {

    public static String[] getNullProperties(Object bean) {
        BeanWrapper beanWrapper = new BeanWrapperImpl(bean);
        PropertyDescriptor[] descriptors = beanWrapper.getPropertyDescriptors();
        List<String> list = new ArrayList<>();
        for (PropertyDescriptor descriptor : descriptors) {
            String name = descriptor.getName();
            if (beanWrapper.getPropertyValue(name) == null) {
                list.add(name);
            }
        }
        String[] result = new String[list.size()];
        return list.toArray(result);
    }
}
