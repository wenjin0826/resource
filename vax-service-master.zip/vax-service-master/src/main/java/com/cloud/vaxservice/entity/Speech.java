package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 转录实体类
 *
 * @author feng
 * @since 2021-12-31
 */
@Data
@TableName("t_speech")
public class Speech implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 语言
     */
    @TableField("locale")
    private String locale;

    /**
     * 提供商
     */
    @TableField("provider")
    private String provider;

    /**
     * 任务ID
     */
    @TableField("task_id")
    private String taskId;

    /**
     * 任务状态
     */
    @TableField("task_status")
    private String taskStatus;

    /**
     * 任务文本
     */
    @TableField("task_text")
    private String taskText;

    /**
     * 音频地址
     */
    @TableField("audio_url")
    private String audioUrl;

    /**
     * 支付积分
     */
    @TableField("pay_score")
    private Integer payScore;

    /**
     * 创建人ID
     */
    @TableField("create_user")
    private Long createUser;

    /**
     * 更新人ID
     */
    @TableField("update_user")
    private Long updateUser;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String LOCALE = "locale";
    public static final String PROVIDER = "provider";
    public static final String TASK_ID = "task_id";
    public static final String TASK_STATUS = "task_status";
    public static final String TASK_TEXT = "task_text";
    public static final String AUDIO_URL = "audio_url";
    public static final String PAY_SCORE = "pay_score";
    public static final String CREATE_USER = "create_user";
    public static final String UPDATE_USER = "update_user";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}