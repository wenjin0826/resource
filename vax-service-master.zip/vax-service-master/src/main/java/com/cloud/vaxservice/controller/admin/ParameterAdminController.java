package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.dto.ParameterDTO;
import com.cloud.vaxservice.dto.ParameterInsertParamDTO;
import com.cloud.vaxservice.dto.ParameterQueryParamDTO;
import com.cloud.vaxservice.dto.ParameterUpdateParamDTO;
import com.cloud.vaxservice.entity.Parameter;
import com.cloud.vaxservice.service.ParameterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;

/**
 * 参数接口
 *
 * @author feng
 * @since 2024/03/14
 */
@Slf4j
@RestController
public class ParameterAdminController {
    @Autowired
    private ParameterService parameterService;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 根据主键ID获取
     *
     * @param id 主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/parameter/get")
    public ResultInfo<ParameterDTO> getParameter(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        Parameter parameter = parameterService.getById(id);
        return ResultInfo.success().setData(ObjectUtils.copy(parameter, ParameterDTO.class));
    }
    
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/parameter/query")
    public ResultInfo<PageInfo<ParameterDTO>> queryParameter(@Valid @RequestBody ParameterQueryParamDTO paramDTO) {
        PageInfo<Parameter> pageInfo = parameterService.query(paramDTO);
        List<ParameterDTO> list = ObjectUtils.copy(pageInfo.getRows(), ParameterDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 新增
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/parameter/insert")
    public ResultInfo<String> insertParameter(@Valid @RequestBody ParameterInsertParamDTO paramDTO) {
        Parameter parameter = ObjectUtils.copy(paramDTO, Parameter.class);
        parameterService.save(parameter);
        return ResultInfo.success();
    }

    /**
     * 更新
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/parameter/update")
    public ResultInfo<String> updateParameter(@Valid @RequestBody ParameterUpdateParamDTO paramDTO) {
        Parameter parameter = ObjectUtils.copy(paramDTO, Parameter.class);
        parameterService.updateById(parameter);
        return ResultInfo.success();
    }
    
    /**
     * 根据主键ID批量删除
     *
     * @param ids 批量主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/parameter/delete")
    public ResultInfo<String> deleteParameter(@RequestBody List<Integer> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ResultInfo.badRequest();
        }
        parameterService.removeByIds(ids);
        return ResultInfo.success();
    }

    /**
     * 加载参数到缓存
     *
     * @param id 主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/parameter/loadToCache")
    public ResultInfo<String> loadParameterToCache(Integer id) {
        Parameter parameter = parameterService.getById(id);
        if (parameter == null) {
            return ResultInfo.badRequest();
        }
        redisTemplate.opsForValue().set(parameter.getParamKey(), parameter.getParamValue());
        return ResultInfo.success();
    }
}
