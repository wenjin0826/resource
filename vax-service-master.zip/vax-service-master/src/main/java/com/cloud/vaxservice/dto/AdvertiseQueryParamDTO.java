package com.cloud.vaxservice.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;
import jakarta.validation.constraints.NotNull;

/**
 * 广告查询参数
 *
 * @author feng
 * @since 2022/06/13
 */
@Data
public class AdvertiseQueryParamDTO {
    /**
     * 标题
     */
    private String title;

    /**
     * 页码（1~100之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 100, message = "页码（1~100之间）")
    private Integer pageNo;

    /**
     * 分页大小（1~100之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 1, max = 100, message = "分页大小（1~100之间）")
    private Integer pageSize;
}