package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/10/02
 */
@Data
public class GenQrcodeParamDTO {
    @NotEmpty(message = "text不能为空")
    private String text;

    @NotNull(message = "width不能为空")
    private Integer width;

    @NotNull(message = "height不能为空")
    private Integer height;
}
