package com.cloud.vaxservice.okx;

import com.cloud.vaxservice.entity.Parameter;
import com.cloud.vaxservice.okx.dto.CandleDataDTO;
import com.cloud.vaxservice.service.ParameterService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.ta4j.core.Bar;
import org.ta4j.core.BaseBarSeries;
import org.ta4j.core.BaseBarSeriesBuilder;
import org.ta4j.core.indicators.AbstractIndicator;
import org.ta4j.core.indicators.EMAIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.num.Num;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * OKXMonitor
 */
@Slf4j
@Component
public class OkxMonitor {
    @Autowired
    private ParameterService parameterService;

    @Autowired
    private JavaMailSender mailSender;

    private final LinkedHashMap<String, String> sendInstMap = new LinkedHashMap<>();
    private final Map<String, Long> sendTimeMap = new HashMap<>();
    private final long SEND_TIMEOUT = 600000;

    @Scheduled(fixedDelay = 20000)
    public void handle() {
        try {
            Parameter parameter = parameterService.getByKey("OkxInstIds");
            if (parameter == null) {
                return;
            }
            String[] instIds = parameter.getParamValue().split(",");
            for (String instId : instIds) {
                instId = instId.trim();
                Long sendTime = sendTimeMap.get(instId);
                if (sendTime != null && sendTime + SEND_TIMEOUT > System.currentTimeMillis()) {
                    continue;
                }
                List<CandleDataDTO> maxCandles = OkxApiSdk.getCandleList(instId, "15m", 45);
                Thread.sleep(1000);
                List<CandleDataDTO> minCandles = OkxApiSdk.getCandleList(instId, "5m", 45);
                if (CollectionUtils.isEmpty(maxCandles) || CollectionUtils.isEmpty(minCandles)) {
                    Thread.sleep(3000);
                    handle();
                    return;
                }
                analyzeMACD(instId, maxCandles, minCandles);
            }
            if (!sendInstMap.isEmpty()) {
                sendEmail();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public void sendEmail() {
        long curTime = System.currentTimeMillis();
        List<String> list = new LinkedList<>();
        sendInstMap.forEach((key, value) -> {
            Long sendTime = sendTimeMap.get(key);
            if (sendTime == null || sendTime + SEND_TIMEOUT < curTime) {
                sendTimeMap.put(key, curTime);
                list.add("【" + key + value + "】");
            }
        });
        sendInstMap.clear();

        if (!list.isEmpty()) {
            log.info("OkxMonitor sendEmail");
            String allNotice = StringUtils.join(list, "\r\n");
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom("37811570@qq.com");
            mailMessage.setTo("547236627@qq.com");
            mailMessage.setSubject("通知提醒");
            mailMessage.setText(allNotice);
            mailSender.send(mailMessage);
        }
    }

    private void analyzeMACD(String instId, List<CandleDataDTO> maxCandles, List<CandleDataDTO> minCandles) {
        BaseBarSeries minSeries = createBarSeries(minCandles, 5);
        if (!nearEndTime(minSeries.getLastBar().getEndTime())) {
            return;
        }

        BaseBarSeries maxSeries = createBarSeries(maxCandles, 15);
        ClosePriceIndicator closePriceIndicator = new ClosePriceIndicator(maxSeries);
        EMAIndicator shortEMA = new EMAIndicator(closePriceIndicator, 6);
        EMAIndicator longEMA = new EMAIndicator(closePriceIndicator, 13);

        // 计算DIF
        AbstractIndicator<Num> difIndicator = new AbstractIndicator<>(maxSeries) {
            @Override
            public Num getValue(int index) {
                return shortEMA.getValue(index).minus(longEMA.getValue(index));
            }

            @Override
            public int getUnstableBars() {
                return 0;
            }
        };

        // 计算DEA
        EMAIndicator deaIndicator = new EMAIndicator(difIndicator, 5);

        // 计算MACD柱值
        AbstractIndicator<Num> barIndicator = new AbstractIndicator<>(maxSeries) {
            @Override
            public Num getValue(int index) {
                // MACD = (DIF - DEA) * 2
                return difIndicator.getValue(index)
                        .minus(deaIndicator.getValue(index))
                        .multipliedBy(maxSeries.numOf(2));
            }

            @Override
            public int getUnstableBars() {
                return 0;
            }
        };

        // 当前K线
        double openPrice = maxSeries.getLastBar().getOpenPrice().doubleValue();
        double closePrice = maxSeries.getLastBar().getClosePrice().doubleValue();

        // 快慢线和柱体
        int endIndex = maxSeries.getEndIndex();
        double dif = difIndicator.getValue(endIndex).doubleValue();
        double dea = deaIndicator.getValue(endIndex).doubleValue();
        double macd = barIndicator.getValue(endIndex).doubleValue();
        log.info("instId={}, dif={}, dea={}, macd={}", instId, dif, dea, macd);

        // 价格上涨并且零轴上方金叉，macd柱为正
        if (dif > 0 && macd > 0 && closePrice > openPrice && (upBreaking(minSeries) || lowestUp(minSeries))) {
            sendInstMap.put(instId, "(↑)");
            return;
        }

        // 价格下跌并且零轴下方死叉，macd柱为负
        if (dif < 0 && macd < 0 && closePrice < openPrice && (downBreaking(minSeries) || highestDown(minSeries))) {
            sendInstMap.put(instId, "(↓)");
        }
    }

    private BaseBarSeries createBarSeries(List<CandleDataDTO> list, int periodMinute) {
        BaseBarSeries series = new BaseBarSeriesBuilder().withName("series-" + periodMinute).build();
        for (int i = list.size() - 1; i >= 0; i--) {
            CandleDataDTO candleDataDTO = list.get(i);
            // 将开始时间转换为结束时间 (加上一个周期)
            ZonedDateTime startTime = Instant.ofEpochMilli(Long.parseLong(candleDataDTO.getTs())).atZone(ZoneId.systemDefault());
            ZonedDateTime endTime = startTime.plusMinutes(periodMinute);
            series.addBar(
                    endTime,
                    Double.parseDouble(candleDataDTO.getOpen()),
                    Double.parseDouble(candleDataDTO.getHigh()),
                    Double.parseDouble(candleDataDTO.getLow()),
                    Double.parseDouble(candleDataDTO.getClose()),
                    Double.parseDouble(candleDataDTO.getVol()));
        }
        return series;
    }

    private double priceFloatPercent(Bar bar) {
        double openPrice = bar.getOpenPrice().doubleValue();
        double closePrice = bar.getClosePrice().doubleValue();

        // 计算浮动百分比
        return (closePrice - openPrice) / openPrice * 100;
    }

    // 当前K线是否涨破阻力位
    private boolean upBreaking(BaseBarSeries series) {
        // 获取当前价和前一个价
        int endIndex = series.getEndIndex();
        double currentPrice = series.getBar(endIndex).getClosePrice().doubleValue();
        double previousPrice = series.getBar(endIndex - 1).getClosePrice().doubleValue();
        if (currentPrice < previousPrice) {
            return false;
        }

        // 记录下跌K线的最高价格
        TreeMap<Double, Double> priceMap = new TreeMap<>();
        for (int i = 0; i < endIndex; i++) {
            Bar bar = series.getBar(i);
            double closePrice = bar.getClosePrice().doubleValue();
            double openPrice = bar.getOpenPrice().doubleValue();
            double highPrice = bar.getHighPrice().doubleValue();

            if (previousPrice > highPrice || closePrice > openPrice) {
                continue;
            }

            priceMap.put(highPrice, highPrice);
        }

        if (priceMap.isEmpty()) {
            return true;
        }

        // 判断是否涨破
        Double highPrice = priceMap.lastEntry().getValue();
        return currentPrice > highPrice;
    }

    // 当前K线是否跌破支撑位
    private boolean downBreaking(BaseBarSeries series) {
        // 获取当前价和前一个价
        int endIndex = series.getEndIndex();
        double currentPrice = series.getBar(endIndex).getClosePrice().doubleValue();
        double previousPrice = series.getBar(endIndex - 1).getClosePrice().doubleValue();
        if (currentPrice > previousPrice) {
            return false;
        }

        // 记录上涨K线的最低价格
        TreeMap<Double, Double> priceMap = new TreeMap<>();
        for (int i = 0; i < endIndex; i++) {
            Bar bar = series.getBar(i);
            double closePrice = bar.getClosePrice().doubleValue();
            double openPrice = bar.getOpenPrice().doubleValue();
            double lowPrice = bar.getLowPrice().doubleValue();

            if (previousPrice < lowPrice || closePrice < openPrice) {
                continue;
            }

            priceMap.put(lowPrice, lowPrice);
        }

        if (priceMap.isEmpty()) {
            return true;
        }

        // 判断是否跌破
        Double lowPrice = priceMap.firstEntry().getValue();
        return currentPrice < lowPrice;
    }

    private boolean nearEndTime(ZonedDateTime endTime) {
        // 获取当前时间
        ZonedDateTime now = ZonedDateTime.now();

        // 计算当前时间距离结束时间还有多少毫秒
        long remainingMillis = java.time.Duration.between(now, endTime).toMillis();

        // 判断是否在最后50秒内
        return remainingMillis > 0 && remainingMillis < 50000;
    }

    private boolean lowestUp(BaseBarSeries series) {
        // 是否最后连续3根K上涨
        boolean k3Up = true;
        for (int i = series.getEndIndex() - 2; i <= series.getEndIndex(); i++) {
            Bar bar = series.getBar(i);
            double closePrice = bar.getClosePrice().doubleValue();
            double openPrice = bar.getOpenPrice().doubleValue();
            if (closePrice < openPrice) {
                k3Up = false;
                break;
            }
        }
        if (!k3Up) {
            return false;
        }

        TreeMap<Double, Double> priceTreeMap = new TreeMap<>();
        int endIndex = series.getEndIndex();
        int beginIndex = 0;
        for (int i = beginIndex; i < endIndex; i++) {
            double lowPrice = series.getBar(i).getLowPrice().doubleValue();
            priceTreeMap.put(lowPrice, lowPrice);
        }

        double lowPrice = priceTreeMap.firstEntry().getValue();
        double currentPrice = series.getLastBar().getClosePrice().doubleValue();
        double priceDiff = (currentPrice - lowPrice) / lowPrice * 100;
        return priceDiff < 0.6;
    }

    private boolean highestDown(BaseBarSeries series) {
        // 是否最后连续3根K下跌
        boolean k3Down = true;
        for (int i = series.getEndIndex() - 2; i <= series.getEndIndex(); i++) {
            Bar bar = series.getBar(i);
            double closePrice = bar.getClosePrice().doubleValue();
            double openPrice = bar.getOpenPrice().doubleValue();
            if (closePrice > openPrice) {
                k3Down = false;
                break;
            }
        }
        if (!k3Down) {
            return false;
        }

        TreeMap<Double, Double> priceTreeMap = new TreeMap<>();
        int endIndex = series.getEndIndex();
        int beginIndex = 0;
        for (int i = beginIndex; i < endIndex; i++) {
            double highPrice = series.getBar(i).getHighPrice().doubleValue();
            priceTreeMap.put(highPrice, highPrice);
        }

        double highPrice = priceTreeMap.lastEntry().getValue();
        double currentPrice = series.getLastBar().getClosePrice().doubleValue();
        double priceDiff = (highPrice - currentPrice) / currentPrice * 100;
        return priceDiff < 0.6;
    }
}
