package com.cloud.common.exception;

import lombok.Data;

/**
 * 应用异常，用于业务逻辑处理失败时抛出
 *
 * @author fengwenjin
 */
@Data
public class AppException extends RuntimeException {

    private int code;

    public AppException(String message) {
        super(message);
    }

    public AppException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
