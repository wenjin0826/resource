declare namespace API {
  type AliyunOssCredentialDTO = {
    credentials?: CredentialsDTO;
    endpoint?: string;
    bucket?: string;
    region?: string;
    url?: string;
  };

  type AppUserDTO = {
    id?: number;
    email?: string;
    phone?: string;
    secret?: string;
    nickName?: string;
    avatarUrl?: string;
    vip?: number;
    score?: number;
    status?: number;
    createTime?: string;
    updateTime?: string;
  };

  type CredentialsDTO = {
    accessKeyId?: string;
    accessKeySecret?: string;
    securityToken?: string;
    durationSeconds?: number;
  };

  type deleteTranscribeParams = {
    id: number;
  };

  type EmailLoginParamDTO = {
    email: string;
    verifyCode: string;
    inviterId?: number;
  };

  type getStatusParams = {
    paymentId: number;
  };

  type getTranscribeViewUrlParams = {
    taskId: string;
  };

  type PageInfoTranscribe = {
    total?: number;
    count?: number;
    current?: number;
    size?: number;
    rows?: Transcribe[];
  };

  type RechargeDTO = {
    paymentId?: number;
    aliPayData?: string;
    wxPayData?: string;
    paypalUrl?: string;
  };

  type RechargeParamDTO = {
    money: number;
    payChannel: number;
    tradeType: number;
    description: string;
    app?: number;
  };

  type ResultInfoAliyunOssCredentialDTO = {
    code?: number;
    message?: string;
    data?: AliyunOssCredentialDTO;
  };

  type ResultInfoAppUserDTO = {
    code?: number;
    message?: string;
    data?: AppUserDTO;
  };

  type ResultInfoInteger = {
    code?: number;
    message?: string;
    data?: number;
  };

  type ResultInfoPageInfoTranscribe = {
    code?: number;
    message?: string;
    data?: PageInfoTranscribe;
  };

  type ResultInfoRechargeDTO = {
    code?: number;
    message?: string;
    data?: RechargeDTO;
  };

  type ResultInfoString = {
    code?: number;
    message?: string;
    data?: string;
  };

  type ResultInfoTranscribeCreateResultDTO = {
    code?: number;
    message?: string;
    data?: TranscribeCreateResultDTO;
  };

  type ResultInfoUserSessionDTO = {
    code?: number;
    message?: string;
    data?: UserSessionDTO;
  };

  type SecretLoginParamDTO = {
    userId: number;
    secret: string;
  };

  type sendVerifyCodeParams = {
    email: string;
  };

  type statusParams = {
    paymentId: number;
  };

  type Transcribe = {
    id?: number;
    locale?: string;
    provider?: string;
    taskId?: string;
    taskStatus?: string;
    taskResult?: string;
    audioUrl?: string;
    audioDuration?: number;
    payScore?: number;
    createUser?: number;
    updateUser?: number;
    createTime?: string;
    updateTime?: string;
  };

  type TranscribeCreateParamDTO = {
    taskTitle?: string;
    language: string;
    format: string;
    audioUrl: string;
    audioSeconds?: number;
  };

  type TranscribeCreateResultDTO = {
    taskId?: string;
    freeLimited?: boolean;
    payMoney?: number;
    payTip?: string;
  };

  type TranscribeQueryParamDTO = {
    userId?: number;
    pageNo: number;
    pageSize: number;
  };

  type UserSessionDTO = {
    userId?: number;
    nickName?: string;
    headimgUrl?: string;
    accessToken?: string;
  };
}
