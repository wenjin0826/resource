package com.cloud.vaxservice.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * 文章新增参数
 *
 * @author feng
 * @since 2021-09-24
 */
@Data
public class ArticleInsertParamDTO {
    /**
     * 置顶
     */
    @NotNull(message = "置顶不能为空")
    private Integer top;

    /**
     * 分类
     */
    @NotNull(message = "分类不能为空")
    private Integer type;

    /**
     * 标题
     */
    @NotEmpty(message = "标题不能为空")
    private String title;

    /**
     * 内容
     */
    @NotEmpty(message = "内容不能为空")
    private String content;

    /**
     * 图片地址
     */
    @NotEmpty(message = "图片地址不能为空")
    private String imgUrl;

    /**
     * 分享地址：多个逗号分隔
     */
    private String shareUrl;

    /**
     * 打开地址
     */
    private String openUrl;

    /**
     * 打开Appid
     */
    private String openAppid;

    /**
     * 发布日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date publishTime;
}