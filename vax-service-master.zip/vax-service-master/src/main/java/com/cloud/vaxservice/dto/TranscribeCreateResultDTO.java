package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 转录任务创建结果
 *
 * @author feng
 * @since 2021-12-05
 */
@Data
public class TranscribeCreateResultDTO {
    private String taskId;
    private Boolean freeLimited;
    private Integer payMoney;
    private String payTip;
}