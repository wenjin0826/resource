package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 玩游戏日志保存参数
 *
 * @author feng
 * @since 2022/09/24
 */
@Data
public class TetrisPlaylogSaveParamDTO {
    /**
     * 分数
     */
    private Integer score;

    /**
     * 级别
     */
    private Integer level;

    /**
     * 速度
     */
    private Integer speed;
}
