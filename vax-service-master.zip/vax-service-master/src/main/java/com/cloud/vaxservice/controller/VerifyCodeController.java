package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.limit.Limit;
import com.cloud.vaxservice.cache.VerifyCodeCache;
import com.cloud.vaxservice.provider.TencentEmailProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 验证码接口
 *
 * @author fengwenjin
 * @since 2021/10/7
 */
@Slf4j
@RestController
public class VerifyCodeController {
    @Autowired
    private VerifyCodeCache verifyCodeCache;

    @Autowired
    private TencentEmailProvider emailProvider;

    /**
     * 发送验证码
     *
     * @param email
     * @return ResultInfo
     */
    @PostMapping("/verifyCode/sendEmail")
    @Limit(limitCount = 10, durationSeconds = 1800)
    public ResultInfo<String> sendVerifyCode(String email) {
        String verifyCode = RandomStringUtils.randomNumeric(6);
        verifyCodeCache.saveCode(email, verifyCode);
        emailProvider.sendVerifyCode("Verify Code", email, verifyCode);
        return ResultInfo.success();
    }
}
