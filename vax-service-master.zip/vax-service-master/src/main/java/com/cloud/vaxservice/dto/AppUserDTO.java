package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * APP用户对象
 *
 * @author makejava
 * @since 2024/11/16
 */
@Data
public class AppUserDTO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 密钥
     */
    private String secret;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 头像地址
     */
    private String avatarUrl;

    /**
     * vip用户
     */
    private Integer vip;

    /**
     * 积分
     */
    private Integer score;

    /**
     * 状态：1表示可用 0表示不可用
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
