package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.TetrisScoreQueryParamDTO;
import com.cloud.vaxservice.entity.TetrisScore;

import java.util.List;

/**
 * 俄罗斯方块分数服务接口
 *
 * @author feng
 * @since 2022/09/20
 */
public interface TetrisScoreService extends IService<TetrisScore> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<TetrisScore> query(TetrisScoreQueryParamDTO paramDTO);

    List<TetrisScore> queryTop(int topSize);

    TetrisScore getByUserId(Long userId);
}
