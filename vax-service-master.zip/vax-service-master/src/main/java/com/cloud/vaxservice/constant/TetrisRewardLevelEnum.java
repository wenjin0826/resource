package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum TetrisRewardLevelEnum {

    LEVEL_1(1, 20000, "一等奖"),
    LEVEL_2(2, 15000, "二等奖"),
    LEVEL_3(3, 10000, "三等奖"),
    LEVEL_0(0, 0, "未中奖");

    @Getter
    private int level;

    @Getter
    private int score;

    @Getter
    private String description;

    TetrisRewardLevelEnum(int level, int score, String description) {
        this.level = level;
        this.score = score;
        this.description = description;
    }

    public static TetrisRewardLevelEnum levelOf(int level) {
        for (TetrisRewardLevelEnum levelEnum : values()) {
            if (level == levelEnum.level) {
                return levelEnum;
            }
        }
        return null;
    }

    public static TetrisRewardLevelEnum scoreOf(int score) {
        for (TetrisRewardLevelEnum levelEnum : values()) {
            if (score >= levelEnum.score) {
                return levelEnum;
            }
        }
        return null;
    }

}
