package com.cloud.vaxservice.browser;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 功能描述
 *
 * @author feng
 * @since 2024/01/13
 */
@Data
@AllArgsConstructor
public class HttpResponse {
    String docHTML;
    String pageInfo;
}

