// @ts-ignore
/* eslint-disable */
import request from "@/commons/request";

/** 此处后端没有提供注释 GET /paypal/notify */
export async function paypalNotify(options?: { [key: string]: any }) {
  return request<any>("/paypal/notify", {
    method: "GET",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 PUT /paypal/notify */
export async function paypalNotify3(options?: { [key: string]: any }) {
  return request<any>("/paypal/notify", {
    method: "PUT",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /paypal/notify */
export async function paypalNotify2(options?: { [key: string]: any }) {
  return request<any>("/paypal/notify", {
    method: "POST",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 DELETE /paypal/notify */
export async function paypalNotify5(options?: { [key: string]: any }) {
  return request<any>("/paypal/notify", {
    method: "DELETE",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 PATCH /paypal/notify */
export async function paypalNotify4(options?: { [key: string]: any }) {
  return request<any>("/paypal/notify", {
    method: "PATCH",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /paypal/recharge */
export async function recharge(
  body: API.RechargeParamDTO,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoRechargeDTO>("/paypal/recharge", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /paypal/status */
export async function getStatus(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getStatusParams,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoInteger>("/paypal/status", {
    method: "POST",
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
