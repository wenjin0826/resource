package com.cloud.consumer.controller;

import com.alibaba.excel.EasyExcel;
import com.cloud.consumer.bean.StudentInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
@RequestMapping("/export")
public class ExportController {

    @RequestMapping("/student")
    public void exportStudent(HttpServletResponse response) throws IOException {
        response.setContentType("application/msexcel; charset=UTF-8");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=student.xlsx");

        List<StudentInfo> list = new ArrayList<>();
        EasyExcel.write(response.getOutputStream(), StudentInfo.class).sheet().doWrite(list);
    }

}
