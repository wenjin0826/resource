package com.cloud.vaxservice.job;

import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.entity.UserIncome;
import com.cloud.vaxservice.service.UserIncomeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 要求收入
 *
 * @author feng
 * @since 2022/09/25
 */
@Slf4j
@Component
public class IncomeSumJob {

    @Autowired
    private UserIncomeService userIncomeService;

    //@Scheduled(cron = "0 0 1 * * ?")
    public void sum() {
        String lockKey = "UserIncome:SumJobLock";
        if (!RemoteLock.lock(lockKey, 0)) {
            return;
        }
        log.info("invite income sum job begin");
        try {
            // 昨天日期
            LocalDate localDate = LocalDate.now().minusDays(1);
            Date date = DateTimeUtils.asDate(localDate);
            // 根据日期查询
            List<UserIncome> userIncomeList = userIncomeService.list(null, false, date);
            // 根据用户分组汇总
            Map<Long, List<UserIncome>> inviterMap = userIncomeList.stream().collect(Collectors.groupingBy(UserIncome::getUserId));
            Map<Long, Integer> sumMap = new HashMap<>();
            inviterMap.keySet().forEach(userId -> {
                Integer moneySum = 0;
                List<UserIncome> incomeList = inviterMap.get(userId);
                for (UserIncome income : incomeList) {
                    moneySum += income.getIncomeMoney();
                }
                sumMap.put(userId, moneySum);
            });
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }
}
