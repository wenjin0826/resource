package com.cloud.vaxservice.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.adapter.PayPalAdapter;
import com.cloud.vaxservice.constant.PayChannelEnum;
import com.cloud.vaxservice.constant.PayStatusEnum;
import com.cloud.vaxservice.constant.TradeTypeEnum;
import com.cloud.vaxservice.dto.RechargeDTO;
import com.cloud.vaxservice.dto.RechargeParamDTO;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.PaymentService;
import com.cloud.vaxservice.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.stream.Collectors;

/**
 * Paypal支付接口
 */
@Slf4j
@RestController
public class PaypalController {
    @Autowired
    private UserService userService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private PayPalAdapter paypalAdapter;

    /**
     * 支付充值
     *
     * @param paramDTO 参数
     * @return ResultInfo<RechargeDTO>
     */
    @PostMapping("/paypal/recharge")
    public ResultInfo<RechargeDTO> recharge(@Valid @RequestBody RechargeParamDTO paramDTO) {
        // 检查参数
        TradeTypeEnum tradeType = TradeTypeEnum.of(paramDTO.getTradeType());
        PayChannelEnum payChannel = PayChannelEnum.of(paramDTO.getPayChannel());
        if (paramDTO.getMoney().equals(0) || tradeType == null || payChannel == null) {
            return ResultInfo.badRequest();
        }

        // 创建支付单
        User user = userService.getById(SessionContext.getUserId());
        Payment payment = new Payment();
        payment.setUserId(user.getId());
        payment.setOrderNo(DateTimeUtils.timeSequence());
        payment.setTradeType(tradeType.getCode());
        payment.setPayChannel(payChannel.getCode());
        payment.setPayStatus(PayStatusEnum.UNDO.getCode());
        payment.setPayMoney(paramDTO.getMoney());
        payment.setPayTitle(payChannel.getDescription());
        paymentService.save(payment);

        String paypalUrl = paypalAdapter.h5Pay(payment.getOrderNo(), new BigDecimal(1), "AIAI To You", "Subscribe VIP");

        RechargeDTO rechargeDTO = new RechargeDTO();
        rechargeDTO.setPaymentId(payment.getId());
        rechargeDTO.setPaypalUrl(paypalUrl);
        return ResultInfo.success().setData(rechargeDTO);
    }

    /**
     * 获取充值状态
     *
     * @param paymentId
     * @return
     */
    @PostMapping("/paypal/status")
    public ResultInfo<Integer> getStatus(Integer paymentId) {
        if (paymentId == null) {
            return ResultInfo.badRequest();
        }
        Integer status = paymentService.getStatus(paymentId);
        return ResultInfo.success().setData(status);
    }

    /**
     * 回调通知
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/paypal/notify")
    public void paypalNotify(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 获取 PayPal 回调数据
        String body = request.getReader().lines().collect(Collectors.joining());
        log.info("Paypal notify data >>> {}", body);
        JSONObject jsonObject = JSON.parseObject(body);

        // 检查事件类型
        String eventType = jsonObject.getString("event_type");
        if (!"CHECKOUT.ORDER.APPROVED".equals(eventType)) {
            response.setStatus(HttpStatus.OK.value());
            response.getWriter().write("SUCCESS");
            return;
        }

        // 获取订单信息
        JSONObject resource = jsonObject.getJSONObject("resource");
        String tradeNo = resource.getString("id");

        // 加锁防止重复处理
        String lockKey = "Lock:PaypalPayment:" + tradeNo;
        if (!RemoteLock.lock(lockKey, 0)) {
            response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
            response.getWriter().write("FAILURE");
            return;
        }

        try {
            // 获取付款单号
            String orderNo = resource.getJSONArray("purchase_units").getJSONObject(0).getString("custom_id");
            // 查询付款
            Payment payment = paymentService.getByOrderNo(orderNo);
            if (payment == null && payment.getPayStatus() != PayStatusEnum.UNDO.getCode()) {
                response.setStatus(HttpStatus.BAD_REQUEST.value());
                response.getWriter().write("FAILURE");
                return;
            }

            // 调用 PayPal Capture 接口确认收款
            String captureId = paypalAdapter.ordersCapture(tradeNo);
            log.info("Paypal ordersCapture captureId={}", captureId);
            if (captureId == null) {
                response.setStatus(HttpStatus.BAD_REQUEST.value());
                response.getWriter().write("FAILURE");
                return;
            }

            // 更新支付状态
            payment.setTradeNo(tradeNo);
            payment.setUpdateTime(new Date());
            payment.setPayStatus(PayStatusEnum.PAID.getCode());
            paymentService.handlePaid(payment);

            response.setStatus(HttpStatus.OK.value());
            response.getWriter().write("SUCCESS");
        } catch (Exception e) {
            log.error("Paypal notify error", e);
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.getWriter().write("FAILURE");
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }
}
