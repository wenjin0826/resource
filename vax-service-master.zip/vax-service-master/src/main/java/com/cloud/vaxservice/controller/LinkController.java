package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.vaxservice.dto.LinkParseParamDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;

/**
 * 链接接口
 */
@Slf4j
@Controller
public class LinkController {

    /**
     * 链接提取视频
     *
     * @return ResultInfo
     */
    @ResponseBody
    @PostMapping("/link/parseVideoUrl")
    public ResultInfo<String> extractVideo(@Valid @RequestBody LinkParseParamDTO paramDTO) {
        String linkText = paramDTO.getLinkText().trim();
        if (!linkText.contains("http")) {
            return ResultInfo.failure().setMessage("请输入链接地址");
        }
        String url = linkText.substring(linkText.indexOf("http")).trim();
        if (url.contains(" ")) {
            url = url.substring(0, url.indexOf(" "));
        }
        String result = null;
        if (result == null) {
            return ResultInfo.failure().setMessage("暂时无法解析，请稍后再试");
        }
        return ResultInfo.success().setData(result);
    }
}
