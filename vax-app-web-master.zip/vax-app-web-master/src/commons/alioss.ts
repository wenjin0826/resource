"use client";
import {getFileCredential} from "@/api/fileController";
import {SUCCESS_CODE} from "@/commons/global";
import OSS, {PutObjectResult} from "ali-oss";

const OSS_INSTANCE = {
    oss: null,
    tokenTime: 0
};

async function getOssConfig(): Promise<OSS.Options> {
    let ossConfig: any;
    try {
        // @ts-ignore
        const res: API.ResultInfoAliyunOssCredentialDTO_ = await getFileCredential();
        if (res.code == SUCCESS_CODE) {
            // @ts-ignore
            const data: API.AliyunOssCredentialDTO = res.data;
            ossConfig = {
                region: 'oss-' + data.region,
                bucket: data.bucket,
                accessKeyId: data.credentials?.accessKeyId,
                accessKeySecret: data.credentials?.accessKeySecret,
                stsToken: data.credentials?.securityToken
            }
        }
    } catch (error:any) {
        console.error(error);
    }

    return new Promise(function (resolve, reject) {
        resolve(ossConfig);
    })
}

async function getOss(): Promise<OSS> {
    let oss: any;
    let time: number = new Date().getTime();
    if (OSS_INSTANCE.oss == null || time > OSS_INSTANCE.tokenTime + 300000) {
        let ossConfig = await getOssConfig();
        if (ossConfig != null) {
            oss = new OSS(ossConfig);
            OSS_INSTANCE.oss = oss;
            OSS_INSTANCE.tokenTime = time;
        }
    } else {
        oss = OSS_INSTANCE.oss;
    }

    if (oss == null) {
        console.log("OSS init failed");
    }

    return new Promise(function (resolve, reject) {
        resolve(oss);
    });
}

export async function uploadFile(uploadPath: string, file: File, mime: string): Promise<string> {
    let resultUrl = "";
    let oss = await getOss();
    if (oss != null) {
        const options = {
            // 获取分片上传进度、断点和返回值。
            progress: (p: any, cpt: any, res: any) => {
                console.log(p);
            },
            // 设置并发上传的分片数量。
            parallel: 5,
            // 设置分片大小。默认值为1MB，最小值为100KB。
            partSize: 1024 * 1024 * 10,
            mime: mime,
            timeout: 300000
        };
        let result: PutObjectResult = await oss.put(uploadPath, file, options);
        if (result.res.status == SUCCESS_CODE) {
            resultUrl = result.url;
        }
    }
    return new Promise(function (resolve, reject) {
        resolve(resultUrl);
    })
}
