package com.cloud.vaxservice.provider.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能描述
 *
 * @author feng
 * @since 2023/12/16
 */
@Data
@NoArgsConstructor
public class ZmProxyDTO {
    private String ip;
    private int port;
    private String city;
    private String isp;

    @JsonProperty("expire_time")
    private String expireTime;
}
