package com.cloud.vaxservice.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 参数更新参数
 *
 * @author feng
 * @since 2024/03/14
 */
@Data
public class ParameterUpdateParamDTO {
    /**
     * 主键
     */
    @NotNull(message = "主键不能为空")
    private Integer id;

    /**
     * 参数key
     */
    @NotEmpty(message = "参数key不能为空")
    private String paramKey;

    /**
     * 参数值
     */
    @NotEmpty(message = "参数值不能为空")
    private String paramValue;

}
