package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.UserTaskDao;
import com.cloud.vaxservice.dto.UserTaskQueryParamDTO;
import com.cloud.vaxservice.entity.UserTask;
import com.cloud.vaxservice.service.UserTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 用户任务服务实现类
 *
 * @author feng
 * @since 2021-11-28
 */
@Slf4j
@Service
public class UserTaskServiceImpl extends ServiceImpl<UserTaskDao, UserTask> implements UserTaskService {
    @Override
    public boolean save(UserTask userTask) {
        if (userTask.getTaskTitle() != null && userTask.getTaskTitle().length() > 60) {
            userTask.setTaskTitle(userTask.getTaskTitle().substring(0, 55) + "...");
        }
        return super.save(userTask);
    }

    @Override
    public PageInfo<UserTask> query(UserTaskQueryParamDTO paramDTO) {
        QueryWrapper<UserTask> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(UserTask.CREATE_USER, paramDTO.getUserId());
        }
        if (paramDTO.getTaskType() != null) {
            wrapper.eq(UserTask.TASK_TYPE, paramDTO.getTaskType());
        }
        wrapper.orderByDesc(UserTask.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public UserTask getByTaskId(String taskId) {
        QueryWrapper<UserTask> wrapper = new QueryWrapper<>();
        wrapper.eq(UserTask.TASK_ID, taskId);
        return getOne(wrapper, false);
    }

    @Override
    public void deleteByUserId(Long userId) {
        QueryWrapper<UserTask> wrapper = new QueryWrapper<>();
        wrapper.eq(UserTask.CREATE_USER, userId);
        remove(wrapper);
    }
}