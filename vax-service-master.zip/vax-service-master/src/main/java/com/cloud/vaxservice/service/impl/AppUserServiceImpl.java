package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.AppUserDao;
import com.cloud.vaxservice.dto.AppUserQueryParamDTO;
import com.cloud.vaxservice.entity.AppUser;
import com.cloud.vaxservice.service.AppUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * APP用户服务实现类
 *
 * @author makejava
 * @since 2024/11/16
 */
@Slf4j
@Service
public class AppUserServiceImpl extends ServiceImpl<AppUserDao, AppUser> implements AppUserService {
    @Override
    public PageInfo<AppUser> query(AppUserQueryParamDTO paramDTO) {
        QueryWrapper<AppUser> wrapper = new QueryWrapper();
        if (paramDTO.getId() != null) {
            wrapper.eq(AppUser.ID, paramDTO.getId());
        }
        if (paramDTO.getEmail() != null) {
            wrapper.eq(AppUser.EMAIL, paramDTO.getEmail());
        }
        wrapper.orderByDesc(AppUser.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public AppUser getByEmail(String email) {
        QueryWrapper<AppUser> wrapper = new QueryWrapper();
        wrapper.eq(AppUser.EMAIL, email);
        return getOne(wrapper, false);
    }
}
