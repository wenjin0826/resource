package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotNull;

/**
 * 用户更新参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class UserUpdateParamDTO {
    /**
     * ID
     */
    @NotNull(message = "ID不能为空")
    private Long id;

    /**
     * VIP用户
     */
    private Integer vip;

    /**
     * 积分
     */
    private Integer score;

    /**
     * 状态
     */
    private Integer status;
}