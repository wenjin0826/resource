package com.cloud.common.validator;

import com.cloud.common.util.DateTimeUtils;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

/**
 * 日期时间格式校验注解
 *
 * @author fengwenjin
 */
@Documented
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(DateTimeCheck.List.class)
@Constraint(validatedBy = {DateTimeValidator.class})
public @interface DateTimeCheck {
    String message() default "{*.validation.constraint.DateTimeCheck.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String format() default DateTimeUtils.DATE_TIME_FORMAT;

    @Documented
    @Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
        DateTimeCheck[] value();
    }
}
