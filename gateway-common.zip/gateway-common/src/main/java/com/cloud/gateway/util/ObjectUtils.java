package com.cloud.gateway.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.TargetSource;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;

import java.lang.reflect.Field;

/**
 * 对象工具类
 */
@Slf4j
public class ObjectUtils {

    /**
     * 动态设置对象私有属性值
     *
     * @param instance
     * @param name
     * @param value
     * @throws Exception
     */
    public static void set(Object instance, String name, Object value) throws Exception {
        try {
            if (AopUtils.isAopProxy(instance)) {
                TargetSource targetSource = ((Advised) instance).getTargetSource();
                instance = targetSource.getTarget();
            }
            Field field = instance.getClass().getDeclaredField(name);
            if (field != null) {
                field.setAccessible(true);
                field.set(instance, value);
            }
        } catch (Exception e) {
            log.error("object set property error", e);
        }
    }

}
