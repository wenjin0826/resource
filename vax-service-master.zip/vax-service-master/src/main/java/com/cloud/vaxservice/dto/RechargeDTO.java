package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 充值DTO
 */
@Data
public class RechargeDTO {
    /**
     * 支付单号
     */
    private Integer paymentId;

    /**
     * 支付宝支付数据
     */
    private String aliPayData;

    /**
     * 微信支付数据
     */
    private String wxPayData;

    /**
     * Paypal支付地址
     */
    private String paypalUrl;
}
