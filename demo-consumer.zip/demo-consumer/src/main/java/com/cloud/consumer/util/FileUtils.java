package com.cloud.consumer.util;

import java.io.File;
import java.util.UUID;

public class FileUtils {

    public static String getTempFilePath() {
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        return System.getProperty("java.io.tmpdir") + File.separator + uuid;
    }

}
