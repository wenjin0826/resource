package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.IDUtils;
import com.cloud.common.util.ObjectUtils;
import com.cloud.common.util.RSAUtils;
import com.cloud.vaxservice.cache.VerifyCodeCache;
import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.constant.RSAWeAppKeyEnum;
import com.cloud.vaxservice.dto.AppUserDTO;
import com.cloud.vaxservice.dto.EmailLoginParamDTO;
import com.cloud.vaxservice.dto.SecretLoginParamDTO;
import com.cloud.vaxservice.dto.UserSessionDTO;
import com.cloud.vaxservice.entity.AppUser;
import com.cloud.vaxservice.entity.Invite;
import com.cloud.vaxservice.service.AppUserService;
import com.cloud.vaxservice.service.InviteService;
import com.cloud.vaxservice.support.SessionHelper;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * APP用户接口
 *
 * @author makejava
 * @since 2024/11/16
 */
@Slf4j
@RestController
public class AppUserController {
    @Autowired
    private AppUserService userService;

    @Autowired
    private InviteService inviteService;

    @Autowired
    private VerifyCodeCache verifyCodeCache;

    @Autowired
    private SessionHelper sessionHelper;

    /**
     * 获取用户信息
     *
     * @return ResultInfo
     */
    @PostMapping("/appuser/getUserInfo")
    public ResultInfo<AppUserDTO> getUserInfo() {
        AppUser appUser = userService.getById(SessionContext.getUserId());
        return ResultInfo.success().setData(ObjectUtils.copy(appUser, AppUserDTO.class));
    }

    /**
     * 退出登录
     *
     * @return
     */
    @PostMapping("/appuser/logout")
    public ResultInfo<String> userLogout() {
        sessionHelper.remove(SessionContext.get());
        return ResultInfo.success();
    }

    /**
     * 密钥登录
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/appuser/secretLogin")
    public ResultInfo<UserSessionDTO> secretLogin(@Valid @RequestBody SecretLoginParamDTO paramDTO) throws Exception {
        Long userId = paramDTO.getUserId();
        String secret = paramDTO.getSecret();
        if (userId == null || StringUtils.isEmpty(secret)) {
            return ResultInfo.badRequest();
        }
        AppUser user = userService.getById(userId);
        if (user == null) {
            log.warn("login failure user not exist, requestIP=" + RequestContext.getRequestIP());
            return ResultInfo.failure();
        }
        if (user.getStatus() == Constants.NO) {
            log.warn("login failure user disable, userId=" + userId);
            throw ErrorEnum.USER_DISABLE.exception();
        }

        secret = RSAUtils.decryptByPrivateKey(RSAWeAppKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getSecret());
        if (!user.getSecret().equals(secret)) {
            log.warn("login failure secret error, userId=" + userId);
            throw ErrorEnum.LOGIN_FAILURE.exception();
        }

        UserSessionDTO sessionDTO = sessionHelper.create(user.getId(), user.getNickName(), user.getSecret(), AppEnum.APP_WEB.name());
        return ResultInfo.success().setData(sessionDTO);
    }

    /**
     * 邮箱登录
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/appuser/emailLogin")
    @Limit(limitCount = 10, durationSeconds = 1800)
    public ResultInfo<UserSessionDTO> emailLogin(@Valid @RequestBody EmailLoginParamDTO paramDTO) throws Exception {
        String cacheCode = verifyCodeCache.getCode(paramDTO.getEmail());
        if (!paramDTO.getVerifyCode().equals(cacheCode)) {
            throw ErrorEnum.VERIFY_CODE_ERROR.exception();
        }

        String email = paramDTO.getEmail();
        String lockKey = "Lock:AppUserLogin:" + email;
        boolean locked = RemoteLock.lock(lockKey, 0);
        if (!locked) {
            return ResultInfo.manyRequest();
        }
        try {
            // 获取用户
            AppUser user = userService.getByEmail(email);
            if (user == null) {
                // 创建用户
                user = new AppUser();
                user.setId(IDUtils.nextId());
                user.setEmail(email);
                user.setPhone("");
                user.setNickName("");
                user.setAvatarUrl("");
                user.setSecret(RandomStringUtils.randomAlphanumeric(16));
                user.setStatus(Constants.OK);
                user.setCreateTime(new Date());
                userService.save(user);

                // 推广邀请处理
                Long inviterId = paramDTO.getInviterId();
                if (inviterId != null) {
                    AppUser inviter = userService.getById(inviterId);
                    if (inviter != null) {
                        Invite invite = new Invite();
                        invite.setInviterId(inviter.getId());
                        invite.setInviteeId(user.getId());
                        invite.setCreateTime(new Date());
                        inviteService.save(invite);
                    }
                }
            } else {
                user.setSecret(RandomStringUtils.randomAlphanumeric(16));
                user.setUpdateTime(new Date());
                userService.updateById(user);
            }

            if (user.getStatus().intValue() == Constants.NO) {
                throw ErrorEnum.USER_DISABLE.exception();
            }

            UserSessionDTO sessionDTO = sessionHelper.create(user.getId(), user.getNickName(), user.getSecret(), AppEnum.APP_WEB.name());
            return ResultInfo.success().setData(sessionDTO);
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }
}
