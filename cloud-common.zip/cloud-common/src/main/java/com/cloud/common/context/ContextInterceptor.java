package com.cloud.common.context;

import com.cloud.common.bean.SessionInfo;
import com.cloud.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Component
public class ContextInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String traceId = request.getHeader(TraceContext.TRACE_ID);
        String sessionStr = request.getHeader(SessionContext.SESSION_INFO);
        if (!StringUtils.isEmpty(sessionStr)) {
            SessionInfo sessionInfo = JsonUtils.parseObject(sessionStr, SessionInfo.class);
            SessionContext.set(sessionInfo);
            if (StringUtils.isEmpty(traceId)) {
                traceId = TraceContext.create(sessionInfo.getUserId());
            }
        }
        String versionInfo = request.getHeader(VersionContext.VERSION_INFO);
        if (!StringUtils.isEmpty(versionInfo)) {
            VersionContext.set(versionInfo);
        }

        TraceContext.set(traceId);
        RequestContext.set(request);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) {
        response.setHeader(HttpHeaders.PRAGMA, "no-cache");
        response.setHeader(HttpHeaders.CACHE_CONTROL, "no-cache");
        response.setDateHeader(HttpHeaders.EXPIRES, 0);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        TraceContext.remove();
        SessionContext.remove();
        VersionContext.remove();
        RequestContext.remove();
    }
}
