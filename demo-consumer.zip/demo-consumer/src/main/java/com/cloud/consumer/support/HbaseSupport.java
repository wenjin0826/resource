package com.cloud.consumer.support;

import com.cloud.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.ColumnPrefixFilter;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.hadoop.hbase.HbaseTemplate;
import org.springframework.data.hadoop.hbase.HbaseUtils;
import org.springframework.data.hadoop.hbase.TableCallback;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class HbaseSupport extends HbaseTemplate {

    @Value("${hbase.zookeeper.quorum:localhost}")
    private String zookeeperQuorum;

    @Value("${hbase.zookeeper.property.clientPort:2181}")
    private String zookeeperClientPort;

    @PostConstruct
    public void init() {
        Configuration conf = new Configuration();
        conf.set("hbase.zookeeper.quorum", zookeeperQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zookeeperClientPort);
        conf.set("zookeeper.znode.parent", "/hbase");
        setConfiguration(conf);
    }

    /**
     * 获取指定单个列的值
     *
     * @param tableName
     * @param familyName
     * @param rowName
     * @param columnName
     * @param resultClass
     * @return
     */
    public Object get(String tableName, String familyName, String rowName, String columnName, Class resultClass) {
        return this.get(tableName, rowName, familyName, columnName, (result, rowNum) -> parseColumnValue(result.value(), result.getRow(), resultClass));
    }

    /**
     * 获取指定多个列的值
     *
     * @param tableName
     * @param familyName
     * @param rowName
     * @param columnNames
     * @param resultClass
     * @return
     */
    public Object get(String tableName, String familyName, String rowName, List<String> columnNames, Class resultClass) {
        return this.execute(tableName, htable -> {
            byte[] rowKey = Bytes.toBytes(rowName);
            byte[] family = Bytes.toBytes(familyName);

            List<Get> gets = new ArrayList<>();
            for (String columnName : columnNames) {
                Get get = new Get(rowKey);
                get.addColumn(family, Bytes.toBytes(columnName));
                gets.add(get);
            }
            Result[] results = htable.get(gets);
            List list = new ArrayList<>(results.length);
            for (Result result : results) {
                Object value = parseColumnValue(result.value(), result.getRow(), resultClass);
                if (value != null) {
                    list.add(value);
                }
            }
            return list;
        });
    }

    /**
     * 根据行的范围查找（单列）
     *
     * @param tableName
     * @param familyName
     * @param startRow
     * @param stopRow
     * @param limit
     * @param columnName
     * @param resultClass
     * @return
     */
    public Object find(String tableName, String familyName, String startRow, String stopRow, Integer limit, String columnName, Class resultClass) {
        Scan scan = new Scan();
        initScan(scan, familyName, startRow, stopRow, limit);
        scan.addColumn(Bytes.toBytes(familyName), Bytes.toBytes(columnName));
        return this.find(tableName, scan, (result, rowNum) -> parseColumnValue(result.value(), result.getRow(), resultClass));
    }

    /**
     * 根据行的范围查找（多列）
     *
     * @param tableName
     * @param familyName
     * @param startRow
     * @param stopRow
     * @param limit
     * @param columnNames
     * @param resultClass
     * @return
     */
    public Object find(String tableName, String familyName, String startRow, String stopRow, Integer limit, List<String> columnNames, Class resultClass) {
        Scan scan = new Scan();
        initScan(scan, familyName, startRow, stopRow, limit);
        List<Filter> filters = new ArrayList<>();
        for (String columnName : columnNames) {
            filters.add(new ColumnPrefixFilter(Bytes.toBytes(columnName)));
        }
        scan.setFilter(new FilterList(FilterList.Operator.MUST_PASS_ONE, filters));
        return this.find(tableName, scan, (result, rowNum) -> parseRowCells(result.listCells(), resultClass));
    }

    /**
     * 保存数据
     *
     * @param tableName
     * @param familyName
     * @param rowName
     * @param columnName
     * @param columnValue
     */
    public void put(String tableName, String familyName, String rowName, String columnName, Object columnValue) {
        this.put(tableName, rowName, familyName, columnName, Bytes.toBytes(JsonUtils.toJSONString(columnValue)));
    }

    /**
     * 重写执行方法，目的设置连接复用
     *
     * @param tableName
     * @param action
     * @param <T>
     * @return
     */
    @Override
    public <T> T execute(String tableName, TableCallback<T> action) {
        HTable table = (HTable) HbaseUtils.getHTable(tableName, getConfiguration(), getCharset(), getTableFactory());
        try {
            setConnectionNoClose(table);
            T result = action.doInTable(table);
            table.flushCommits();
            return result;
        } catch (Throwable th) {
            if (th instanceof Error) {
                throw ((Error) th);
            }
            if (th instanceof RuntimeException) {
                throw ((RuntimeException) th);
            }
            throw convertHbaseAccessException((Exception) th);
        } finally {
            HbaseUtils.releaseTable(tableName, table, getTableFactory());
        }
    }

    /**
     * 设置连接不关闭
     *
     * @param table
     * @throws Exception
     */
    private void setConnectionNoClose(HTable table) throws Exception {
        Field field = table.getClass().getDeclaredField("cleanupConnectionOnClose");
        field.setAccessible(true);
        field.setBoolean(table, false);

        field = table.getClass().getDeclaredField("cleanupPoolOnClose");
        field.setAccessible(true);
        field.setBoolean(table, false);
    }

    /**
     * 初始化Scan
     *
     * @param scan
     * @param familyName
     * @param startRow
     * @param stopRow
     * @param limit
     */
    private void initScan(Scan scan, String familyName, String startRow, String stopRow, Integer limit) {
        scan.addFamily(Bytes.toBytes(familyName));
        scan.withStartRow(Bytes.toBytes(startRow), true);
        if (stopRow != null) {
            scan.withStopRow(Bytes.toBytes(stopRow), true);
        }
        if (limit != null) {
            scan.setLimit(limit);
        }
    }

    /**
     * 解析列值
     *
     * @param value
     * @param resultClass
     * @return
     */
    private Object parseColumnValue(byte[] value, byte[] rowKey, Class resultClass) {
        if (value == null) {
            return null;
        }
        String json = new String(value);
        if (json.trim().startsWith("[")) {
            List<Object> list = JsonUtils.parseArray(json, resultClass);
            for (Object obj : list) {
                setRowkey(rowKey, obj, resultClass);
            }
            return list;
        }
        Object obj = JsonUtils.parseObject(json, resultClass);
        setRowkey(rowKey, obj, resultClass);
        return obj;
    }

    /**
     * 设置rowKey
     *
     * @param rowKey
     * @param obj
     * @param resultClass
     */
    private void setRowkey(byte[] rowKey, Object obj, Class resultClass) {
        try {
            Field field = resultClass.getDeclaredField("rowKey");
            field.setAccessible(true);
            field.set(obj, new String(rowKey));
        } catch (Exception e) {
            // ignore
        }
    }

    /**
     * 解析多个列的值
     *
     * @param cells
     * @param resultClass
     * @return
     */
    private List<Object> parseRowCells(List<Cell> cells, Class resultClass) {
        List<Object> list = new ArrayList<>(cells.size());
        for (Cell cell : cells) {
            if (cell.getValueLength() > 0) {
                byte[] value = CellUtil.cloneValue(cell);
                list.add(parseColumnValue(value, cell.getRow(), resultClass));
            }
        }
        return list;
    }

}
