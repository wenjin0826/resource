package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.UserTask;

/**
 * 用户任务数据访问
 *
 * @author feng
 * @since 2021-11-28
 */
public interface UserTaskDao extends BaseMapper<UserTask> {
}