package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/09/25
 */
@Data
public class WechatGetURLSchemaParamDTO {
    private Integer articleId;
    private Long inviterId;
    private String ticket;
}
