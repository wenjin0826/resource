package com.cloud.common.tcc;

import com.cloud.common.context.AppContext;
import lombok.Data;

@Data
public class TCCRequest<T> {

    public static final int STATUS_TRY = 0;
    public static final int STATUS_CONFIRM = 1;
    public static final int STATUS_CANCEL = 2;

    /**
     * 当前状态
     */
    private int status = STATUS_TRY;

    /**
     * 全局事务ID
     */
    private String xid;

    /**
     * 请求名
     */
    private String name;

    /**
     * 业务对象数据
     */
    private T data;

    /**
     * 调用对象
     */
    TCCInvoker invoker;

    public TCCRequest(String name, T data) {
        this.name = name;
        this.data = data;
    }

    public void execute(TCCInvoker invoker) {
        this.invoker = invoker;
        AppContext.getBean(TCCTransactionManager.class).execute(this);
    }

    public boolean isTry() {
        return this.status == STATUS_TRY;
    }

    public boolean isConfirm() {
        return this.status == STATUS_CONFIRM;
    }

    public boolean isCancel() {
        return this.status == STATUS_CANCEL;
    }

}
