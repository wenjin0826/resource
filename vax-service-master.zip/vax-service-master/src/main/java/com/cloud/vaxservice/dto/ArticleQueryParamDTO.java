package com.cloud.vaxservice.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import jakarta.validation.constraints.NotNull;

/**
 * 文章查询参数
 *
 * @author feng
 * @since 2021-09-24
 */
@Data
public class ArticleQueryParamDTO {
    /**
     * 标题
     */
    private String title;

    /**
     * 类型
     */
    private Integer type;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 页码（1~1000之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 1000, message = "页码（1~1000之间）")
    private Integer pageNo;

    /**
     * 分页大小（5~100之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 1, max = 100, message = "分页大小（1~100之间）")
    private Integer pageSize;
}