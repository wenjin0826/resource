package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.ResultInfo;
import com.cloud.vaxservice.provider.AliyunOssCredentialDTO;
import com.cloud.vaxservice.provider.AliyunOssProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 文件接口
 */
@Slf4j
@RestController
public class FileAdminController {
    @Autowired
    private AliyunOssProvider ossProvider;

    /**
     * 获取临时凭证
     *
     * @return ResultInfo
     * @throws Exception
     */
    @PostMapping("/admin/file/getCredential")
    public ResultInfo<AliyunOssCredentialDTO> getFileCredential() throws Exception {
        return ResultInfo.success().setData(ossProvider.getCredential());
    }
}
