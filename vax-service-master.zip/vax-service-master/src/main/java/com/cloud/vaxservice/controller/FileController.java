package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.UUIDUtils;
import com.cloud.vaxservice.dto.GenQrcodeParamDTO;
import com.cloud.vaxservice.provider.AliyunOssCredentialDTO;
import com.cloud.vaxservice.provider.AliyunOssProvider;
import com.cloud.vaxservice.util.QrcodeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.io.ByteArrayInputStream;

/**
 * 文件接口
 */
@Slf4j
@RestController
public class FileController {
    @Autowired
    private AliyunOssProvider ossProvider;

    /**
     * 获取临时凭证
     *
     * @return ResultInfo
     * @throws Exception
     */
    @RequestMapping("/file/getCredential")
    public ResultInfo<AliyunOssCredentialDTO> getCredential() throws Exception {
        return ResultInfo.success().setData(ossProvider.getCredential());
    }

    /**
     * 获取临时凭证
     *
     * @param paramDTO
     * @return ResultInfo
     * @throws Exception
     */
    @PostMapping("/file/genQrcode")
    public ResultInfo<String> genQrcode(@Valid @RequestBody GenQrcodeParamDTO paramDTO) throws Exception {
        byte[] qrcodeBytes = QrcodeUtils.generateQrCodeByte(paramDTO.getText(), paramDTO.getWidth(), paramDTO.getHeight());
        String qrcodeFilePath = "qrcode/tmp_" + UUIDUtils.get() + ".png";
        ossProvider.putObject(qrcodeFilePath, new ByteArrayInputStream(qrcodeBytes));
        String qrcodeUrl = ossProvider.getUrl() + "/" + qrcodeFilePath;
        return ResultInfo.success().setData(qrcodeUrl);
    }
}
