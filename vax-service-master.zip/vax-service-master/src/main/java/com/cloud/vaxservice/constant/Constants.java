package com.cloud.vaxservice.constant;

public class Constants {
    public static final int OK = 1;
    public static final int NO = 0;
    public static final String ADMIN = "admin";
    public static final String SEPARATOR = ",";

    public static final String ADMIN_AES_SECRET = "9fa2d3dcsfcb8db9";

    public static final float VIP_DISCOUNT = 0.2F;
    public static final float INVITE_INCOME = 0.2F;
    public static final int SHARE_SCORE = 15;

    public static final String WEAPP_TICKET = "WeappTicket";
}
