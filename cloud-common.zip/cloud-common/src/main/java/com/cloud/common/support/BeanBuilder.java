package com.cloud.common.support;

import org.apache.commons.lang3.RandomStringUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;

public class BeanBuilder {

    private static final int RANDOM_MIN_COUNT = 1;
    private static final int RANDOM_MAX_COUNT = 8;

    public static <T> T build(Class<T> clazz) {
        try {
            T instance = clazz.newInstance();
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                field.setAccessible(true);
                Class fieldType = field.getType();
                if (fieldType == Boolean.class || fieldType == boolean.class) {
                    field.set(instance, true);
                } else if (fieldType == Short.class || fieldType == short.class) {
                    field.set(instance, (short) 1);
                } else if (fieldType == Integer.class || fieldType == int.class) {
                    field.set(instance, Integer.parseInt(RandomStringUtils.randomNumeric(RANDOM_MAX_COUNT)));
                } else if (fieldType == Long.class || fieldType == long.class) {
                    field.set(instance, Long.parseLong(RandomStringUtils.randomNumeric(RANDOM_MAX_COUNT)));
                } else if (fieldType == Float.class || fieldType == float.class) {
                    field.set(instance, Float.parseFloat(RandomStringUtils.randomNumeric(RANDOM_MIN_COUNT)));
                } else if (fieldType == Double.class || fieldType == double.class) {
                    field.set(instance, Double.parseDouble(RandomStringUtils.randomNumeric(RANDOM_MIN_COUNT)));
                } else if (fieldType == String.class) {
                    field.set(instance, RandomStringUtils.randomAlphabetic(RANDOM_MAX_COUNT));
                } else if (fieldType == Date.class) {
                    field.set(instance, new Date());
                } else if (fieldType == List.class) {
                    Class genericClazz = getGenericClass(field);
                    if (genericClazz != null) {
                        List list = new ArrayList();
                        list.add(build(genericClazz));
                        field.set(instance, list);
                    }
                } else if (fieldType == Set.class) {
                    Class genericClazz = getGenericClass(field);
                    if (genericClazz != null) {
                        Set sets = new HashSet();
                        sets.add(build(genericClazz));
                        field.set(instance, sets);
                    }
                } else if (!fieldType.isArray()) {
                    field.set(instance, build(fieldType));
                }
            }
            return instance;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 获取泛型类型
     *
     * @param field
     * @return
     */
    private static Class getGenericClass(Field field) throws Exception {
        Type genericType = field.getGenericType();
        if (genericType != null && genericType instanceof ParameterizedType) {
            String typeName = ((ParameterizedType) genericType).getActualTypeArguments()[0].getTypeName();
            return Class.forName(typeName);
        }
        return null;
    }

}
