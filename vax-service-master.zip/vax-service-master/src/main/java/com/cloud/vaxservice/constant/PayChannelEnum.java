package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum PayChannelEnum {

    WECHAT_PAY(1, "微信付款"),
    ALI_PAY(2, "支付宝付款");

    @Getter
    private int code;

    @Getter
    private String description;

    PayChannelEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static PayChannelEnum of(int code) {
        for (PayChannelEnum payChannelEnum : values()) {
            if (payChannelEnum.code == code) {
                return payChannelEnum;
            }
        }
        return null;
    }
}
