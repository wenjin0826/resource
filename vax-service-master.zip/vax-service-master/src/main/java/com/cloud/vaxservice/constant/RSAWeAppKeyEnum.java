package com.cloud.vaxservice.constant;

import lombok.Getter;

/**
 * RSA公钥和私钥
 *
 * @author fengwenjin
 * @since 2021/11/7
 */
public enum RSAWeAppKeyEnum {
    PUBLIC_KEY("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCLAACh6B5D2acfUq9IElekOg5jmUmOxBtd5s89c1KtNxVXcZQSRptQUWqGwQZpnshl4C3hNYGwGFa23Sesg2Lo1I+XDhnEgFp2nEXlRVjukHSogzZnx7xpjfke+P6Bd+gIiTwSp/QLIVw4k7Cr2buZnxzp2EgyuNvJMvvH+Vwm5wIDAQAB"),
    PRIVATE_KEY("MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIsAAKHoHkPZpx9Sr0gSV6Q6DmOZSY7EG13mzz1zUq03FVdxlBJGm1BRaobBBmmeyGXgLeE1gbAYVrbdJ6yDYujUj5cOGcSAWnacReVFWO6QdKiDNmfHvGmN+R74/oF36AiJPBKn9AshXDiTsKvZu5mfHOnYSDK428ky+8f5XCbnAgMBAAECgYBeFS9YZ2ts03p6ChZYOwoVP7KTmaKfPn+jjGGDn3Y7hggs+tSVljL0J1dqRGaZwP61bgq/396bGa4/8eszqm6cVOlhX1zJBo2RQhfGXmRgpPO/xPh3eD9uXvYwlNouMcssz87ZzObVgEpjRcsa7IG5llTVyLJCL76WAGBvISotsQJBAN2soz+rX2ksT6nuzcVA3Zrc9SnHBXpmVqrTuk7pb0Nt8DSdrAGLJ43Zu0YwTDk+M2dOymgxjQNeMACraNyeCn8CQQCghhUPl30VtgQu+5C6HjlKp//wbbyXr5F/QD40n+UACePRx0enqIwvDYvoiLJ0tlwFJ9V0gkXrmI/8cDI6HZ+ZAkBEydrK2jI8X9zEve8qw+tAsEp/0Vu41OMWFafd7wBw6z+8BCWpQPZgRW2g5UHyDYREDaYv2RiKMAMzYf2jYIOfAkBh/xkSaLADNhg9unQzO0pMil1UIRoWHCed4NFY/RgnOuJq6daTwvC5tPJppjIT0FRDDXthYjpfRsb4HGJ9WiJZAkEAl8gh7LR7Pz/qjro9JvCQ16PhA7gqiDT1YapwHBmjAF84sBFvG2+oh9oFI3gFwc2ySqEw4rTRKkUmQoCzM7tG0A==");

    @Getter
    private String value;

    RSAWeAppKeyEnum(String value) {
        this.value = value;
    }
}
