package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum TetrisScoreRankEnum {

    TOP_300(10000, "排名300以内"),
    TOP_500(9000, "排名500以内"),
    TOP_1000(8000, "排名1000以内"),
    TOP_2000(7000, "排名2000以内"),
    TOP_3000(6000, "排名3000以内"),
    TOP_4000(5000, "排名4000以内"),
    TOP_5000(3000, "排名5000以内"),
    TOP_10000(2000, "排名1万以内"),
    TOP_OTHER(0, "排名1万之外");

    @Getter
    private int minScore;

    @Getter
    private String description;

    TetrisScoreRankEnum(int minScore, String description) {
        this.minScore = minScore;
        this.description = description;
    }

    public static TetrisScoreRankEnum scoreOf(int score) {
        for (TetrisScoreRankEnum rankEnum : values()) {
            if (score >= rankEnum.minScore) {
                return rankEnum;
            }
        }
        return null;
    }

}
