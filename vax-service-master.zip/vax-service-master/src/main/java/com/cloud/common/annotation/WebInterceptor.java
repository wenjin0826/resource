package com.cloud.common.annotation;

import java.lang.annotation.*;

/**
 * web拦截器注解
 *
 * @author fengwenjin
 */
@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface WebInterceptor {
    int order() default 0;
}
