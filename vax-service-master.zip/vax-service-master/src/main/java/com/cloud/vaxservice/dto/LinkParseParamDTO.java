package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 功能描述
 *
 * @author feng
 * @since 2023/12/13
 */
@Data
public class LinkParseParamDTO {
    /**
     * 链接文本
     */
    @NotEmpty(message = "链接文本不能为空")
    private String linkText;
}
