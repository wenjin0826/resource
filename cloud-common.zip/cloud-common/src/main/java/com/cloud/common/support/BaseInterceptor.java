package com.cloud.common.support;

import com.cloud.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.concurrent.Callable;

@Slf4j
public class BaseInterceptor {

    public Object execute(ProceedingJoinPoint point, Callable callable) throws Throwable {
        Logger logger = getLogger(point);

        // 记录参数日志
        if (logger != null && logger.isDebugEnabled()) {
            logArgs(logger, point);
        }

        long beginTime = System.currentTimeMillis();
        Object result = null;
        try {
            // 调用方法
            if (callable == null) {
                result = point.proceed();
            } else {
                result = callable.call();
            }
            return result;
        } catch (Throwable e) {
            logError(point, e);
            throw e;
        } finally {
            logTime(point, beginTime);

            // 记录结果日志
            if (logger != null && logger.isDebugEnabled() && result != null) {
                logResult(logger, point, result);
            }
        }
    }

    private Logger getLogger(ProceedingJoinPoint point) {
        try {
            Field field = point.getSignature().getDeclaringType().getDeclaredField("log");
            if (Modifier.isStatic(field.getModifiers())) {
                field.setAccessible(true);
                return (Logger) field.get(point.getTarget());
            }
        } catch (Exception e) {
        }
        return null;
    }

    private void logError(ProceedingJoinPoint point, Throwable e) {
        String message = "execute failure, " + point.getSignature().toShortString() + " params >>> " + JsonUtils.toJSONString(point.getArgs());
        log.error(message, e);
    }

    private void logTime(ProceedingJoinPoint point, long beginTime) {
        long costTime = System.currentTimeMillis() - beginTime;
        if (costTime >= 3000) {
            log.warn("{} ExecuteBlocking={}", point.getSignature().toShortString(), costTime);
        } else if (costTime >= 500) {
            log.info("{} ExecuteSlowness={}", point.getSignature().toShortString(), costTime);
        }

        if (log.isDebugEnabled()) {
            log.debug("{} ExecuteTime={}", point.getSignature().toShortString(), costTime);
        }
    }

    private void logArgs(Logger logger, ProceedingJoinPoint point) {
        try {
            Object[] args = point.getArgs();
            StringBuilder params = new StringBuilder();
            if (args != null && args.length > 0) {
                for (Object arg : args) {
                    if (arg == null) {
                        params.append("null   ");
                    } else {
                        params.append(arg.toString() + "   ");
                    }
                }
            }
            logger.debug(point.getSignature().toShortString() + " params >>> {}", params.toString());
        } catch (Exception e) {
            log.error("logArgs error", e);
        }
    }

    private void logResult(Logger logger, ProceedingJoinPoint point, Object result) {
        try {
            logger.debug(point.getSignature().toShortString() + " result >>> {}", JsonUtils.toJSONString(result));
        } catch (Exception e) {
            log.error("logResult error", e);
        }
    }

}
