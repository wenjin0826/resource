package com.cloud.consumer.config;

import com.cloud.common.support.CacheConfigurer;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CacheConfig extends CacheConfigurer {

    public static final String USER = "DemoConsumer:User:";

    @Bean
    @Override
    public CacheManager cacheManager() {
        setTimeout(USER, 300);
        return createCacheManager();
    }

}
