package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.UserIncome;

/**
 * 用户收入数据访问
 *
 * @author feng
 * @since 2022/10/10
 */
public interface UserIncomeDao extends BaseMapper<UserIncome> {
}
