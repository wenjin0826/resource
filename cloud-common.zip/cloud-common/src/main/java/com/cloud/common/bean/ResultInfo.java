package com.cloud.common.bean;

import com.cloud.common.rpc.ResponseFuture;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.http.HttpStatus;

@Data
@Accessors(chain = true)
public class ResultInfo<T> {

    private int code;
    private String message;
    private T data;

    @JsonIgnore
    private ResponseFuture future;

    public static ResultInfo success() {
        return new ResultInfo().setCode(HttpStatus.OK.value());
    }

    public static ResultInfo failure() {
        return new ResultInfo().setCode(HttpStatus.EXPECTATION_FAILED.value());
    }

    public static ResultInfo conflict() {
        return new ResultInfo().setCode(HttpStatus.CONFLICT.value());
    }

    public static ResultInfo noContent() {
        return new ResultInfo().setCode(HttpStatus.NO_CONTENT.value());
    }

    public static ResultInfo badRequest() {
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value());
    }

    public ResultInfo setCode(int code) {
        HttpStatus status = HttpStatus.resolve(code);
        if (status != null) {
            this.message = status.getReasonPhrase();
        }
        this.code = code;
        return this;
    }

    public ResultInfo setData(T data) {
        this.data = data;
        return this;
    }

    public boolean successful() {
        if (future != null) {
            try {
                ResultInfo resultInfo = (ResultInfo) future.get();
                if (resultInfo != null) {
                    this.code = resultInfo.code;
                }
            } catch (InterruptedException e) {
            }
        }
        return this.code == HttpStatus.OK.value() ? true : false;
    }

}