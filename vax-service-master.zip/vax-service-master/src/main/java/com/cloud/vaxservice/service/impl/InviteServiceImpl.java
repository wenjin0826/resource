package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.vaxservice.dao.InviteDao;
import com.cloud.vaxservice.dto.InviteQueryParamDTO;
import com.cloud.vaxservice.entity.Invite;
import com.cloud.vaxservice.service.InviteService;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.util.DateTimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 邀请服务实现类
 *
 * @author feng
 * @since 2022/09/24
 */
@Slf4j
@Service
public class InviteServiceImpl extends ServiceImpl<InviteDao, Invite> implements InviteService {
    @Override
    public PageInfo<Invite> query(InviteQueryParamDTO paramDTO) {
        QueryWrapper<Invite> wrapper = new QueryWrapper<>();
        if (paramDTO.getInviterId() != null) {
            wrapper.eq(Invite.INVITER_ID, paramDTO.getInviterId());
        }
        wrapper.orderByDesc(Invite.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public List<Invite> listByDate(Date date) {
        LocalDate localDate = DateTimeUtils.asLocalDate(date);
        Date beginDate = DateTimeUtils.asDate(localDate);
        Date endDate = DateTimeUtils.asDate(localDate.plusDays(1));
        QueryWrapper<Invite> wrapper = new QueryWrapper<>();
        wrapper.ge(Invite.CREATE_TIME, beginDate);
        wrapper.lt(Invite.CREATE_TIME, endDate);
        return list(wrapper);
    }

    @Override
    public Invite getByInviteeId(Long inviteeId) {
        QueryWrapper<Invite> wrapper = new QueryWrapper<>();
        wrapper.eq(Invite.INVITEE_ID, inviteeId);
        return getOne(wrapper, false);
    }

    @Override
    public boolean exist(Long userId) {
        QueryWrapper<Invite> wrapper = new QueryWrapper<>();
        wrapper.eq(Invite.INVITER_ID, userId);
        wrapper.or();
        wrapper.eq(Invite.INVITEE_ID, userId);
        Invite invite = getOne(wrapper, false);
        return invite != null;
    }

}
