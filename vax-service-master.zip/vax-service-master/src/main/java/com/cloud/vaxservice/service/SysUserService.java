package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.SysUserQueryParamDTO;
import com.cloud.vaxservice.entity.SysUser;

public interface SysUserService extends IService<SysUser> {
    /**
     * 检查名称是否存在
     *
     * @param username
     * @param ignoreId
     * @return
     */
    boolean checkNameExist(String username, Integer ignoreId);

    /**
     * 根据用户名查询
     *
     * @param username
     * @return
     */
    SysUser getByUsername(String username);

    /**
     * 分页查询
     *
     * @param paramDTO
     * @return
     */
    PageInfo<SysUser> query(SysUserQueryParamDTO paramDTO);
}
