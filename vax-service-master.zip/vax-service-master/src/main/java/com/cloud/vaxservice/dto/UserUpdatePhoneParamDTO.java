package com.cloud.vaxservice.dto;

import com.cloud.common.validator.PhoneNumberCheck;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 用户更新手机号参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class UserUpdatePhoneParamDTO {
    /**
     * 手机号
     */
    @NotEmpty(message = "手机号不能为空")
    @PhoneNumberCheck(message = "手机号不正确")
    private String phone;

    /**
     * 验证码
     */
    @NotEmpty(message = "验证码不能为空")
    private String validCode;
}