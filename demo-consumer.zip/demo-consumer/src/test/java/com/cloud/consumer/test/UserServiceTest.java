package com.cloud.consumer.test;

import com.cloud.common.bean.ResultInfo;
import com.cloud.consumer.entity.User;
import com.cloud.consumer.provider.MessageProvider;
import com.cloud.consumer.service.impl.UserServiceImpl;
import com.cloud.consumer.test.support.MybatisConfig;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mybatis.spring.annotation.MapperScan;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@ComponentScan
@RunWith(SpringRunner.class)
@MapperScan(MybatisConfig.DAO_PACKAGE)
@Import(UserServiceImpl.class)
public class UserServiceTest {

    @MockBean
    private MessageProvider messageProvider;

    @Autowired
    private UserServiceImpl userService;

    @Test
    public void getById() {
        // 准备mock操作
        PowerMockito.when(messageProvider.send(Mockito.any())).thenReturn(ResultInfo.success());
        userService.setMessageProvider(messageProvider);

        // 准备测试数据
        User user = new User();
        user.setUsername(RandomStringUtils.randomAlphanumeric(8));
        user.setNickname("杰克");
        userService.save(user);

        // 执行逻辑
        User queryUser = userService.getById(user.getId());

        // 判断结果
        Assert.assertEquals(queryUser.getUsername(), user.getUsername());
    }
}
