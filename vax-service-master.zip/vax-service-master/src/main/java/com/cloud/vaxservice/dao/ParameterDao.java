package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Parameter;

/**
 * 参数数据访问
 *
 * @author feng
 * @since 2024/03/14
 */
public interface ParameterDao extends BaseMapper<Parameter> {
}
