package com.cloud.vaxservice.util;

import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.encoder.ByteMatrix;
import com.google.zxing.qrcode.encoder.Encoder;
import com.google.zxing.qrcode.encoder.QRCode;

import java.io.ByteArrayOutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Path;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/10/02
 */
public class QrcodeUtils {
    /**
     * 生成二维码,返回字节流
     *
     * @param text   二维码需要包含的信息
     * @param width  二维码宽度
     * @param height 二维码高度
     */
    public static byte[] generateQrCodeByte(String text, int width, int height) throws Exception {
        QRCode qrCode = Encoder.encode(text, ErrorCorrectionLevel.L);
        BitMatrix bitMatrix = buildBitMatrix(qrCode, width, height, 1);
        ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
        MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream);
        return pngOutputStream.toByteArray();
    }

    /**
     * 生成二维码,保存到本地
     *
     * @param text     二维码需要包含的信息
     * @param width    二维码宽度
     * @param height   二维码高度
     * @param filePath 图片保存路径
     */
    public static void generateQrCodeImage(String text, int width, int height, String filePath) throws Exception {
        QRCode qrCode = Encoder.encode(text, ErrorCorrectionLevel.L);
        BitMatrix bitMatrix = buildBitMatrix(qrCode, width, height, 1);
        Path path = FileSystems.getDefault().getPath(filePath);
        MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
    }

    private static BitMatrix buildBitMatrix(QRCode code, int width, int height, int quietZone) {
        ByteMatrix input = code.getMatrix();
        if (input == null) {
            throw new IllegalStateException();
        }
        int inputWidth = input.getWidth();
        int inputHeight = input.getHeight();
        int qrWidth = inputWidth + quietZone * 2;
        int qrHeight = inputHeight + quietZone * 2;
        int outputWidth = Math.max(width, qrWidth);
        int outputHeight = Math.max(height, qrHeight);

        int multiple = Math.min(outputWidth / qrWidth, outputHeight / qrHeight);

        int leftPadding = (outputWidth - inputWidth * multiple) / 2;
        int topPadding = (outputHeight - inputHeight * multiple) / 2;

        BitMatrix bitMatrix = new BitMatrix(outputWidth, outputHeight);

        int inputY = 0;
        for (int outputY = topPadding; inputY < inputHeight; outputY += multiple) {
            int inputX = 0;
            for (int outputX = leftPadding; inputX < inputWidth; outputX += multiple) {
                if (input.get(inputX, inputY) == 1) {
                    bitMatrix.setRegion(outputX, outputY, multiple, multiple);
                }
                inputX++;
            }
            inputY++;
        }
        return bitMatrix;
    }
}
