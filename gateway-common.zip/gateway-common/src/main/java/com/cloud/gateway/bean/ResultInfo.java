package com.cloud.gateway.bean;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.http.HttpStatus;

@Data
@Accessors(chain = true)
public class ResultInfo {

    private int code;
    private String message;
    private Object data;

    public ResultInfo setCode(int code) {
        HttpStatus status = HttpStatus.resolve(code);
        if (status != null) {
            this.message = status.getReasonPhrase();
        }
        this.code = code;
        return this;
    }

    public static ResultInfo success() {
        return new ResultInfo().setCode(HttpStatus.OK.value());
    }

    public static ResultInfo failure() {
        return new ResultInfo().setCode(HttpStatus.EXPECTATION_FAILED.value());
    }

    public boolean successed() {
        return this.code == HttpStatus.OK.value() ? true : false;
    }

}