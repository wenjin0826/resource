package com.cloud.vaxservice.provider.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 百度创建转写请求结果
 *
 * @author fengwenjin
 * @since 2021/9/2
 */
@NoArgsConstructor
@Data
public class BaiduCreateTranscribeResultDTO {
    @JsonProperty("task_id")
    private String taskId;

    @JsonProperty("task_status")
    private String taskStatus;
}
