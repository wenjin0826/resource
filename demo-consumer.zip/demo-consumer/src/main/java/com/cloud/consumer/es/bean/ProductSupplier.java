package com.cloud.consumer.es.bean;

import lombok.Data;

@Data
public class ProductSupplier {
    private String name;
    private String phone;
    private String address;
}
