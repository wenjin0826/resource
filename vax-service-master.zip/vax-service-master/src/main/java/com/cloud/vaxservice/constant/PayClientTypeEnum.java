package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum PayClientTypeEnum {

    APP(1),
    H5(2);

    @Getter
    private int code;

    PayClientTypeEnum(int code) {
        this.code = code;
    }

    public static PayClientTypeEnum of(Integer code) {
        if (code != null) {
            for (PayClientTypeEnum payChannelEnum : values()) {
                if (payChannelEnum.code == code) {
                    return payChannelEnum;
                }
            }
        }
        return null;
    }
}
