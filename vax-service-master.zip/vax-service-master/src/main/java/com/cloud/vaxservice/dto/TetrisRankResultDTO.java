package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.List;

/**
 * 俄罗斯方块排行榜结果
 *
 * @author feng
 * @since 2022/09/22
 */
@Data
public class TetrisRankResultDTO {
    private List<TetrisScoreDTO> rankList;
    private String myRank;
}
