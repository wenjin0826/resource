package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 用户刷新令牌参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class UserRefreshTokenParamDTO {
    /**
     * 刷新令牌
     */
    private String refreshToken;

    /**
     * 访问令牌
     */
    private String accessToken;
}