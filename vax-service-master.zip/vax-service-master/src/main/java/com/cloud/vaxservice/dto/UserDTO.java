package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 用户对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class UserDTO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 应用
     */
    private Integer app;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 密钥
     */
    private String secret;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 头像地址
     */
    private String headimgUrl;

    /**
     * 微信Openid
     */
    private String wxOpenId;

    /**
     * VIP用户
     */
    private Integer vip;

    /**
     * 积分
     */
    private Integer score;

    /**
     * 状态：1表示可用 0表示不可用
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
