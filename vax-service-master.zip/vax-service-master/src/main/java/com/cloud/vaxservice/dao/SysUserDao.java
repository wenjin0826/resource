package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.SysUser;

public interface SysUserDao extends BaseMapper<SysUser> {

}
