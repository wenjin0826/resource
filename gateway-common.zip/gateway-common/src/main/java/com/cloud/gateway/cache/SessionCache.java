package com.cloud.gateway.cache;

import com.cloud.gateway.bean.SessionInfo;
import com.cloud.gateway.util.JsonUtils;
import com.cloud.gateway.util.TokenUtils;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.ReactiveSubscription;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class SessionCache {

    private static final String STRING_SESSION_KEY_PREFIX = "SessionInfo:";
    private static final String PUB_CHANNEL_NAME = "SessionChange";
    private static final String KEY_SEPARATOR = ":";


    @Autowired
    private ReactiveRedisTemplate<String, Object> reactiveRedisTemplate;

    private final Object EMPTY = new Object();

    private Cache<String, SessionInfo> cache;

    @PostConstruct
    public void init() {
        cache = CacheBuilder.newBuilder()
                .initialCapacity(1000)
                .maximumSize(1000000)
                .expireAfterWrite(180, TimeUnit.SECONDS)
                .build();

        // 订阅redis会话改变，删除本地缓存
        reactiveRedisTemplate.listenToChannel(PUB_CHANNEL_NAME).doOnNext(msg -> {
            ReactiveSubscription.ChannelMessage channelMessage = (ReactiveSubscription.ChannelMessage) msg;
            String[] arr = channelMessage.getMessage().toString().split(KEY_SEPARATOR);
            if (arr.length == 2) {
                String appName = arr[0];
                String userId = arr[1];
                String key = STRING_SESSION_KEY_PREFIX + appName + KEY_SEPARATOR + userId;
                cache.invalidate(key);
                log.info("session invalidate key {}", key);
            }
        }).subscribe();
    }

    public Mono<Object> get(String token) {
        Pair<String, String> pair = TokenUtils.parse(token);
        if (pair == null) {
            return Mono.empty();
        }
        String appName = pair.getFirst();
        String userId = pair.getSecond();
        String key = STRING_SESSION_KEY_PREFIX + appName + KEY_SEPARATOR + userId;

        SessionInfo sessionInfo = cache.getIfPresent(key);
        if (sessionInfo != null) {
            if (sessionInfo.getSecret().equals(TokenUtils.getSecret(token))) {
                return Mono.just(sessionInfo);
            }
        }

        return reactiveRedisTemplate.opsForValue().get(key).map(data -> {
            if (data != null) {
                SessionInfo session = JsonUtils.parseObject(data.toString(), SessionInfo.class);
                TreeSet authResources = new TreeSet(session.getAuthResources());
                session.setAuthResources(authResources.descendingSet());
                cache.put(key, session);
                if (session.getSecret().equals(TokenUtils.getSecret(token))) {
                    return session;
                }
            }
            log.warn("get session not found, key={}", key);
            return EMPTY;
        }).filter(data -> data != EMPTY);
    }

}
