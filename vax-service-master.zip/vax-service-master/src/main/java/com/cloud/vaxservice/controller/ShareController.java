package com.cloud.vaxservice.controller;

import com.cloud.vaxservice.cache.ShareCache;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.dto.ArticleDTO;
import com.cloud.vaxservice.dto.ShareFetchDTO;
import com.cloud.vaxservice.dto.ShareInsertParamDTO;
import com.cloud.vaxservice.entity.Article;
import com.cloud.vaxservice.entity.Share;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.ArticleService;
import com.cloud.vaxservice.service.ShareService;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.support.ShareHelper;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.util.ObjectUtils;
import com.cloud.common.util.UUIDUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;

/**
 * 分享接口
 *
 * @author feng
 * @since 2022/06/11
 */
@Slf4j
@Controller
public class ShareController {
    @Autowired
    private ShareService shareService;

    @Autowired
    private ArticleService articleService;

    @Autowired
    private UserService userService;

    @Autowired
    private ShareHelper shareHelper;

    @Autowired
    private ShareCache shareCache;

    @ResponseBody
    @PostMapping("/share/insert")
    public ResultInfo<String> insert(@Valid @RequestBody ShareInsertParamDTO paramDTO) {
        Long userId = SessionContext.getUserId();
        String shareTicket = shareCache.getTicket(userId);
        if (!paramDTO.getShareTicket().equals(shareTicket)) {
            return ResultInfo.badRequest();
        }
        Share share = shareService.get(userId, paramDTO.getArticleId());
        if (share == null) {
            share = ObjectUtils.copy(paramDTO, Share.class);
            share.setUserId(userId);
            share.setCreateTime(new Date());
            shareService.save(share);

            // 奖励积分
            User user = userService.getById(userId);
            if (user != null) {
                user.setScore(user.getScore() + Constants.SHARE_SCORE);
                user.setUpdateTime(new Date());
                userService.updateById(user);
            }
        }
        return ResultInfo.success().setMessage("分享至少保留三天否则禁用该功能");
    }

    @ResponseBody
    @PostMapping("/share/fetch")
    public ResultInfo<ShareFetchDTO> fetch() {
        // 获取今日文章
        Article article = articleService.getTodayLatest();
        if (article == null) {
            return ResultInfo.success().setData(null);
        }
        Long userId = SessionContext.getUserId();
        // 检查今日是否已分享
        Share share = shareService.get(userId, article.getId());
        if (share != null) {
            return ResultInfo.success().setData(null);
        }
        // 保存分享票据
        String shareTicket = UUIDUtils.get();
        shareCache.saveTicket(userId, shareTicket);

        // 返回结果
        ShareFetchDTO shareFetchDTO = new ShareFetchDTO();
        shareFetchDTO.setShareUrl(shareHelper.getShareUrl(article));
        shareFetchDTO.setShareTip("分享一次奖励文字提取" + Constants.SHARE_SCORE + "分钟时长\n分享至少保留三天否则禁用该功能");
        shareFetchDTO.setShareTicket(shareTicket);
        shareFetchDTO.setDescription("");
        shareFetchDTO.setArticle(ObjectUtils.copy(article, ArticleDTO.class));
        return ResultInfo.success().setData(shareFetchDTO);
    }

    @ResponseBody
    @PostMapping("/share/getViewUrl")
    public ResultInfo<String> getViewUrl(String idCode) {
        if (StringUtils.isEmpty(idCode)) {
            return ResultInfo.badRequest();
        }
        String viewUrl = shareHelper.getViewUrl(idCode);
        return ResultInfo.success().setData(viewUrl);
    }

    @ResponseBody
    @PostMapping("/share/getProxyUrl")
    public ResultInfo<String> getProxyUrl(String idCode) {
        if (StringUtils.isEmpty(idCode)) {
            return ResultInfo.badRequest();
        }
        String proxyUrl = shareHelper.getProxyUrl(idCode);
        return ResultInfo.success().setData(proxyUrl);
    }

    @RequestMapping("/share/view/{idCode}")
    public String view(@PathVariable("idCode") String idCode, Model model) {
        Integer articleId = shareHelper.decode(idCode);
        model.addAttribute("articleId", articleId);
        return "article";
    }

    @RequestMapping("/share/proxy/{idCode}")
    public String proxy(@PathVariable("idCode") String idCode) {
        return "proxy";
    }

    @RequestMapping("/share/open/{idCode}")
    public String open(@PathVariable("idCode") String idCode) {
        return "share";
    }
}