package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.PaymentQueryParamDTO;
import com.cloud.vaxservice.entity.Payment;

/**
 * <p>
 * 付款单 服务类
 * </p>
 *
 * @author feng
 * @since 2021-09-25
 */
public interface PaymentService extends IService<Payment> {
    void handlePaid(Payment payment);

    PageInfo<Payment> query(PaymentQueryParamDTO paramDTO);

    Integer getStatus(Integer paymentId);

    Payment getByOrderNo(String orderNo);
}
