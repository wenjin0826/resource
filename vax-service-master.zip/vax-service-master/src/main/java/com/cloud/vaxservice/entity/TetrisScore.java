package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 俄罗斯方块分数实体类
 *
 * @author feng
 * @since 2022/09/21
 */
@Data
@TableName("t_tetris_score")
public class TetrisScore implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 用户IP
     */
    @TableField("user_ip")
    private String userIp;

    /**
     * 用户昵称
     */
    @TableField("nick_name")
    private String nickName;

    /**
     * 头像地址
     */
    @TableField("headimg_url")
    private String headimgUrl;

    /**
     * 游戏最高分
     */
    @TableField("game_score")
    private Integer gameScore;

    /**
     * 奖励级别
     */
    @TableField("reward_level")
    private Integer rewardLevel;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String USER_IP = "user_ip";
    public static final String NICK_NAME = "nick_name";
    public static final String HEADIMG_URL = "headimg_url";
    public static final String GAME_SCORE = "game_score";
    public static final String REWARD_LEVEL = "reward_level";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}
