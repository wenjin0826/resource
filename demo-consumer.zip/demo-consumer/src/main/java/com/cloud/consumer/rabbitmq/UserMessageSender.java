package com.cloud.consumer.rabbitmq;

import com.cloud.common.util.JsonUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserMessageSender {

    private static final String EXCHANGE_NAME = "user";

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void send(Object message) {
        rabbitTemplate.convertAndSend(EXCHANGE_NAME, "", JsonUtils.toJSONString(message));
    }

}
