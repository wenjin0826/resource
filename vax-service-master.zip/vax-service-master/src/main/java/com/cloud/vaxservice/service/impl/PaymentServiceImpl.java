package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.cache.PaymentCache;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.IncomeTypeEnum;
import com.cloud.vaxservice.dao.PaymentDao;
import com.cloud.vaxservice.dto.PayQueryParamDTO;
import com.cloud.vaxservice.entity.Invite;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.entity.UserIncome;
import com.cloud.vaxservice.service.InviteService;
import com.cloud.vaxservice.service.PaymentService;
import com.cloud.vaxservice.service.UserIncomeService;
import com.cloud.vaxservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 付款单 服务实现类
 * </p>
 *
 * @author feng
 * @since 2021-09-25
 */
@Slf4j
@Service
public class PaymentServiceImpl extends ServiceImpl<PaymentDao, Payment> implements PaymentService {

    @Autowired
    private UserService userService;

    @Autowired
    private UserIncomeService userIncomeService;

    @Autowired
    private InviteService inviteService;

    @Autowired
    private PaymentCache paymentCache;

    @Override
    public boolean save(Payment payment) {
        super.save(payment);
        paymentCache.saveStatus(payment.getId(), payment.getPayStatus());
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void handlePaid(Payment payment) {
        updateById(payment);
        paymentCache.saveStatus(payment.getId(), payment.getPayStatus());

        int score = payment.getPayMoney() / 10;
        User user = userService.getById(payment.getUserId());
        // VIP用户打折
        if (user.getVip().equals(Constants.OK)) {
            score += new BigDecimal(score).multiply(new BigDecimal(Constants.VIP_DISCOUNT)).intValue();
        }

        // 更新积分
        user.setScore(user.getScore() + score);
        user.setUpdateTime(new Date());
        userService.updateById(user);

        // 邀请收入处理
        Invite invite = inviteService.getByInviteeId(user.getId());
        if (invite != null) {
            int incomeMoney = new BigDecimal(payment.getPayMoney()).multiply(new BigDecimal(Constants.INVITE_INCOME)).intValue();

            UserIncome income = new UserIncome();
            income.setUserId(invite.getInviterId());
            income.setIncomeType(IncomeTypeEnum.INVITE_RECHARGE.getCode());
            income.setIncomeMoney(incomeMoney);
            income.setPaid(Constants.NO);
            income.setCreateTime(new Date());
            userIncomeService.save(income);
        }
    }

    @Override
    public PageInfo<Payment> query(PayQueryParamDTO paramDTO) {
        QueryWrapper<Payment> query = new QueryWrapper();
        if (paramDTO.getStatus() != null) {
            query.eq(Payment.PAY_STATUS, paramDTO.getStatus());
        }
        if (paramDTO.getUserId() != null) {
            query.eq(Payment.USER_ID, paramDTO.getUserId());
        }
        query.orderByDesc(Payment.ID);
        IPage page =  page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), query);
        return new PageInfo(page);
    }

    @Override
    public Integer getStatus(Integer paymentId) {
        return paymentCache.getStatus(paymentId);
    }

    @Override
    public Payment getByOrderNo(String orderNo) {
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.eq(Payment.ORDER_NO, orderNo);
        return getOne(queryWrapper);
    }
}
