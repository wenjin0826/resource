package com.cloud.vaxservice.provider.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 百度获取访问令牌结果
 *
 * @author fengwenjin
 * @since 2021/9/2
 */
@NoArgsConstructor
@Data
public class BaiduGetAccessTokenResultDTO {
    @JsonProperty("refresh_token")
    private String refreshToken;

    @JsonProperty("expires_in")
    private Integer expiresIn;

    @JsonProperty("scope")
    private String scope;

    @JsonProperty("session_key")
    private String sessionKey;

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("session_secret")
    private String sessionSecret;
}
