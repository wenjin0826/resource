package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.vaxservice.dto.SpeechQueryParamDTO;
import com.cloud.vaxservice.entity.Speech;
import com.cloud.vaxservice.service.SpeechService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

/**
 * 配音接口
 *
 * @author feng
 * @since 2021-11-28
 */
@Slf4j
@RestController
public class SpeechAdminController {
    @Autowired
    private SpeechService speechService;

    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/speech/query")
    public ResultInfo<PageInfo<Speech>> querySpeech(@Valid @RequestBody SpeechQueryParamDTO paramDTO) {
        PageInfo<Speech> pageInfo = speechService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }
}