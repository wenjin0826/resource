package com.cloud.vaxservice.provider;

import com.cloud.common.util.UUIDUtils;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.entity.Speech;
import com.cloud.vaxservice.service.SpeechService;
import com.tencent.SpeechClient;
import com.tencent.tts.model.SpeechSynthesisRequest;
import com.tencent.tts.model.SpeechSynthesisResponse;
import com.tencent.tts.service.SpeechSynthesisListener;
import com.tencent.tts.service.SpeechSynthesizer;
import com.tencent.tts.utils.PcmUtils;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class TencentSpeechProvider {
    @Value("${tencent.appId}")
    private String appId;

    @Value("${tencent.secretId}")
    private String secretId;

    @Value("${tencent.secretKey}")
    private String secretKey;

    @Autowired
    private AliyunOssProvider ossProvider;

    @Autowired
    private SpeechService speechService;

    private static ThreadPoolExecutor threadExecutor = new ThreadPoolExecutor(0, 15, 60, TimeUnit.SECONDS, new SynchronousQueue<>(), new ThreadPoolExecutor.CallerRunsPolicy());
    private static Map<String, SpeechTask> speechTaskMap = new ConcurrentHashMap();

    @PostConstruct
    public void init() {
        List<Speech> speechList = speechService.getRunnings();
        for (Speech speech : speechList) {
            create(speech);
        }
    }

    @Async
    public void create(Speech speech) {
        String symbols = ",.?，。？！、";
        String speechText = speech.getSpeechText();
        int textLen = speechText.length();
        int splitLen = 550;
        int lastEnd = 0;
        List<String> textList = new LinkedList<>();
        int batchCount = (textLen + splitLen - 1) / splitLen;
        for (int i = 0; i < batchCount; i++) {
            int begin = lastEnd == 0 ? i * splitLen : lastEnd;
            lastEnd = begin + splitLen;
            if (lastEnd < textLen) {
                // 截止最后一个字符是标点符号，构成完整句子
                String lastStr = speechText.substring(lastEnd, lastEnd + 1);
                if (!symbols.contains(lastStr)) {
                    for (int j = 0; j < 50; j++) {
                        lastEnd++;
                        lastStr = speechText.substring(lastEnd, lastEnd + 1);
                        if (symbols.contains(lastStr)) {
                            break;
                        }
                    }
                }
                lastEnd++;
                lastEnd = lastEnd > textLen ? textLen : lastEnd;
                textList.add(speechText.substring(begin, lastEnd));
            } else {
                textList.add(speechText.substring(begin));
            }
        }
        SpeechTask speechTask = new SpeechTask();
        speechTask.textList = textList;
        speechTask.handledIndex = 0;
        speechTaskMap.put(speech.getTaskId(), speechTask);
        threadExecutor.execute(() -> handleSpeech(speech, textList.get(0)));
    }

    public void handleSpeech(Speech speech, String text) {
        // 创建SpeechSynthesizerClient实例，目前是单例
        SpeechClient client = SpeechClient.newInstance(appId, secretId, secretKey);
        // 初始化SpeechSynthesizerRequest，SpeechSynthesizerRequest包含请求参数
        SpeechSynthesisRequest request = SpeechSynthesisRequest.initialize();
        request.setSessionId(UUIDUtils.get());
        request.setCodec("pcm");
        request.setSampleRate(16000);
        request.setVoiceType(Integer.valueOf(speech.getVoiceType()));
        request.setVolume(Integer.valueOf(speech.getVoiceVolume()));
        request.setSpeed(Float.valueOf(speech.getVoiceSpeed()));
        // 使用客户端client创建语音合成实例
        SpeechSynthesizer speechSynthesizer = client.newSpeechSynthesizer(request, new MySpeechSynthesizerListener(request, speech));
        speechSynthesizer.synthesis(text);
    }

    class SpeechTask {
        List<String> textList;
        int handledIndex;
    }

    class MySpeechSynthesizerListener extends SpeechSynthesisListener {
        private SpeechSynthesisRequest request;
        private Speech speech;

        public MySpeechSynthesizerListener(SpeechSynthesisRequest request, Speech speech) {
            this.request = request;
            this.speech = speech;
        }

        @Override
        public void onComplete(SpeechSynthesisResponse response) {
            log.info("onComplete SessionId={} Success={} Code={} End={} Message={}", request.getSessionId(), response.getSuccess(), response.getCode(), response.getEnd(), response.getMessage());

            try {
                // 失败
                if (!response.getSuccess()) {
                    clearTask(speech.getTaskId());
                    speechService.updateResult(TaskStatusEnum.FAILURE, speech);
                    return;
                }

                String taskId = speech.getTaskId();
                SpeechTask speechTask = speechTaskMap.get(taskId);
                int handledIndex = speechTask.handledIndex;
                List<String> textList = speechTask.textList;
                // 只有一个分片文本
                if (textList.size() == 1) {
                    savetoAliyun(response.getAudio());

                    clearTask(speech.getTaskId());
                    speechService.updateResult(TaskStatusEnum.SUCCESS, speech);
                    return;
                }

                // 保存到临时文件
                File tmpFile = getTmpFile(taskId + "_" + handledIndex + ".pcm");
                FileUtils.writeByteArrayToFile(tmpFile, response.getAudio());
                log.info("save to temporary file >>> {}", tmpFile.getAbsolutePath());

                if (handledIndex < textList.size() - 1) {
                    // 继续处理下一个分片文本
                    speechTask.handledIndex = handledIndex + 1;
                    threadExecutor.execute(() -> handleSpeech(speech, textList.get(speechTask.handledIndex)));
                    return;
                }
                // 合并分片文件为一个整体文件
                File targetFile = getTmpFile(taskId + ".pcm");
                if (targetFile.exists()) {
                    FileUtils.forceDelete(targetFile);
                    targetFile.createNewFile();
                }
                for (int i = 0; i < textList.size(); i++) {
                    tmpFile = getTmpFile(taskId + "_" + i + ".pcm");
                    FileUtils.writeByteArrayToFile(targetFile, FileUtils.readFileToByteArray(tmpFile), true);
                }
                savetoAliyun(FileUtils.readFileToByteArray(targetFile));

                clearTask(speech.getTaskId());
                speechService.updateResult(TaskStatusEnum.SUCCESS, speech);
            } catch (Exception e) {
                clearTask(speech.getTaskId());
                speechService.updateResult(TaskStatusEnum.FAILURE, speech);
            }
        }

        private File getTmpFile(String fileName) {
            return new File(System.getProperty("java.io.tmpdir") + "/" + fileName);
        }

        private void savetoAliyun(byte[] bytes) {
            // pcm转wav, wav大小为pcm字节+44wav头大小
            byte[] wav = new byte[44 + bytes.length];
            int bitNum = request.getSampleRate() == 16000 ? 16 : 8;
            PcmUtils.pcm2WavBytes(bytes, wav, request.getSampleRate(), 1, bitNum);
            String filePath = "speech/" + request.getSessionId() + ".wav";
            ossProvider.putObject(filePath, new ByteArrayInputStream(wav));
            speech.setAudioUrl(ossProvider.getUrl() + "/" + filePath);
        }

        private void clearTask(String taskId) {
            SpeechTask speechTask = speechTaskMap.get(taskId);
            speechTaskMap.remove(taskId);

            int listSize = speechTask.textList.size();
            if (listSize == 1) {
                return;
            }
            try {
                for (int i = 0; i < listSize; i++) {
                    File tmpFile = getTmpFile(taskId + "_" + i + ".pcm");
                    FileUtils.forceDelete(tmpFile);
                }
                File targetFile = getTmpFile(taskId + ".pcm");
                FileUtils.forceDelete(targetFile);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        @Override
        public void onMessage(byte[] data) {
        }

        @Override
        public void onFail(SpeechSynthesisResponse response) {
            log.warn("onFail SessionId={} Code={} Message={}", request.getSessionId(), response.getCode(), response.getMessage());
            speechService.updateResult(TaskStatusEnum.FAILURE, speech);
        }
    }
}
