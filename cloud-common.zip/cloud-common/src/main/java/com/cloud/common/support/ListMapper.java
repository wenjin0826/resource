package com.cloud.common.support;

import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * List转为Map使用的辅助类
 *
 * @param <T>
 */
public class ListMapper<T> {
    private Map<String, T> map;
    private List<T> list;

    public ListMapper(List<T> list) {
        this.list = list;
    }

    public List<T> getList() {
        return list;
    }

    public T get(String key, Function<T, String> keyFunction) {
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        if (map == null) {
            map = new HashMap<>();
            list.forEach(bean -> map.putIfAbsent(keyFunction.apply(bean), bean));
        }
        return map.get(key);
    }
}
