package com.cloud.common.validator;

import org.apache.commons.lang3.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

/**
 * 身份证校验逻辑
 *
 * @author fengwenjin
 */
public class IdCardValidator implements ConstraintValidator<IdCardCheck, String> {
    private IdCardCheck annotation;

    @Override
    public void initialize(IdCardCheck constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isEmpty(value)) {
            return true;
        }
        return Pattern.matches("(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)", value);
    }
}
