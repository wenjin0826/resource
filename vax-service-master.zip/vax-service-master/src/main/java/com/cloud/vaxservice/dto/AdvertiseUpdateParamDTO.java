package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotNull;

/**
 * 广告更新参数
 *
 * @author feng
 * @since 2022/06/13
 */
@Data
public class AdvertiseUpdateParamDTO {
    /**
     * 主键
     */
    @NotNull(message = "主键不能为空")
    private Integer id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 状态：1表示可用 0表示不可用
     */
    private Integer status;

    /**
     * 图片地址
     */
    private String imgUrl;

    /**
     * 查看地址
     */
    private String viewUrl;

    /**
     * 跳转地址
     */
    private String redirectUrl;

    /**
     * 排序值
     */
    private Integer sortIndex;
}