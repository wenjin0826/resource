package com.cloud.common.util;

import com.github.yitter.idgen.YitIdHelper;

/**
 * ID工具类（隔离ID的生成方案，以便后续调整时统一修改）
 *
 * @author fengwenjin
 */
public class IDUtils {
    /**
     * 获取ID
     *
     * @return long
     */
    public static long nextId() {
        return YitIdHelper.nextId();
    }
}
