package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum AsrBaiduEngineTypeEnum {
    // 中文 (1134是8k采样率)
    CHINESE(1134, 8000),
    // 英文
    ENGLISH(1737, 16000);

    @Getter
    private int pid;

    @Getter
    private int rate;

    AsrBaiduEngineTypeEnum(int pid, int rate) {
        this.pid = pid;
        this.rate = rate;
    }
}
