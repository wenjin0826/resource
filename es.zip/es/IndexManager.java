package com.cloud.consumer.es;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.IndexOperations;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class IndexManager implements ApplicationRunner {
    @Autowired
    private ElasticsearchRestTemplate elasticsearch;

    @Override
    public void run(ApplicationArguments args) {
        createIndex(IndexProduct.class);
    }

    public void deleteIndex(String indexName) {
        IndexOperations indexOps = elasticsearch.indexOps(IndexCoordinates.of(indexName));
        if (indexOps.exists()) {
            indexOps.delete();
        }
        log.error("delete index failure, indexName={} not exist");
    }

    private void createIndex(Class clazz) {
        IndexOperations indexOps = elasticsearch.indexOps(clazz);
        if (!indexOps.exists()) {
            indexOps.create();
            log.info("create index class={}", clazz.getName());
        }
        indexOps.putMapping(indexOps.createMapping(clazz));
    }
}
