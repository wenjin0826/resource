package com.cloud.vaxservice.dto;

import com.cloud.common.validator.EnumCheck;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 配音新增参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class SpeechCreateParamDTO {
    @NotEmpty(message = "语言环境不能为空")
    @EnumCheck(values = "ZH_CN,EN_US")
    private String locale;

    @NotEmpty(message = "配音内容不能为空")
    private String text;

    private Integer modelType;

    private Integer voiceType;

    private Integer volume;

    private Float speed;
}