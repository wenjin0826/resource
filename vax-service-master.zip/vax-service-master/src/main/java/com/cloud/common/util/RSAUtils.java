package com.cloud.common.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
 * RSA加解密工具类
 *
 * @author fengwenjin
 */
@Slf4j
public class RSAUtils {
    private static final String RSA = "RSA";
    private static final String RSA_KEY_ALGORITHM  = "RSA/ECB/PKCS1Padding";

    /**
     * 公钥加密
     *
     * @param publicKeyText
     * @param sourceText
     * @return String
     * @throws Exception
     */
    public static String encryptByPublicKey(String publicKeyText, String sourceText) {
        try {
            X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(Base64.decodeBase64(publicKeyText));
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
            Cipher cipher = Cipher.getInstance(RSA_KEY_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] result = cipher.doFinal(sourceText.getBytes());
            return Base64.encodeBase64String(result);
        } catch (Exception e) {
            log.warn("encryptByPublicKey failure sourceText={}", sourceText);
        }
        return "";
    }

    /**
     * 私钥解密
     *
     * @param privateKeyText
     * @param encryptText
     * @return String
     * @throws Exception
     */
    public static String decryptByPrivateKey(String privateKeyText, String encryptText) {
        try {
            PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKeyText));
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
            Cipher cipher = Cipher.getInstance(RSA_KEY_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] result = cipher.doFinal(Base64.decodeBase64(encryptText));
            return new String(result);
        } catch (Exception e) {
            log.warn("decryptByPrivateKey failure encryptText={}", encryptText);
        }
        return "";
    }

    /**
     * 私钥加密
     *
     * @param privateKeyText
     * @param sourceText
     * @return String
     * @throws Exception
     */
    public static String encryptByPrivateKey(String privateKeyText, String sourceText) {
        try {
            PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKeyText));
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
            Cipher cipher = Cipher.getInstance(RSA_KEY_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, privateKey);
            byte[] result = cipher.doFinal(sourceText.getBytes());
            return Base64.encodeBase64String(result);
        } catch (Exception e) {
            log.warn("encryptByPrivateKey failure sourceText={}", sourceText);
        }
        return "";
    }

    /**
     * 公钥解密
     *
     * @param publicKeyText
     * @param encryptText
     * @return String
     * @throws Exception
     */
    public static String decryptByPublicKey(String publicKeyText, String encryptText) {
        try {
            X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(Base64.decodeBase64(publicKeyText));
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
            Cipher cipher = Cipher.getInstance(RSA_KEY_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, publicKey);
            byte[] result = cipher.doFinal(Base64.decodeBase64(encryptText));
            return new String(result);
        } catch (Exception e) {
            log.warn("decryptByPublicKey failure encryptText={}", encryptText);
        }
        return "";
    }

    /**
     * 构建RSA密钥对
     *
     * @return RSAKeyPair
     * @throws Exception
     */
    public static RSAKeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(RSA);
        keyPairGenerator.initialize(1024);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        RSAPublicKey rsaPublicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) keyPair.getPrivate();
        String publicKeyString = Base64.encodeBase64String(rsaPublicKey.getEncoded());
        String privateKeyString = Base64.encodeBase64String(rsaPrivateKey.getEncoded());
        return new RSAKeyPair(publicKeyString, privateKeyString);
    }

    /**
     * RSA密钥对对象
     */
    @Data
    @AllArgsConstructor
    public static class RSAKeyPair {
        private String publicKey;
        private String privateKey;
    }
}
