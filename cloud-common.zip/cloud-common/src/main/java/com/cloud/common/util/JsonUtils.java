package com.cloud.common.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.lang.reflect.Type;
import java.util.List;

@Slf4j
@Component
public class JsonUtils {

    private static ObjectMapper objectMapper;
    private static ApplicationContext applicationContext;

    public JsonUtils(ApplicationContext context) {
        applicationContext = context;
    }

    public static String toJSONString(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return getObjectMapper().writeValueAsString(value);
        } catch (Exception e) {
            log.error("toJSONString error", e);
        }
        return null;
    }

    public static <T> T parseObject(String json, Class<T> clazz) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return getObjectMapper().readValue(json, clazz);
        } catch (Exception e) {
            log.error("parseObject error", e);
        }
        return null;
    }

    public static <T> T parseObject(String json, Type type) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return getObjectMapper().readValue(json, getObjectMapper().getTypeFactory().constructType(type));
        } catch (Exception e) {
            log.error("parseObject error", e);
        }
        return null;
    }

    public static <T> List<T> parseArray(String json, Class<T> clazz) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            JavaType javaType = getObjectMapper().getTypeFactory().constructParametricType(List.class, clazz);
            return getObjectMapper().readValue(json, javaType);
        } catch (Exception e) {
            log.error("parseArray error", e);
        }
        return null;
    }

    private static ObjectMapper getObjectMapper() {
        if (objectMapper == null) {
            if (applicationContext == null) {
                objectMapper = new ObjectMapper();
                objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            } else {
                objectMapper = applicationContext.getBean(ObjectMapper.class);
            }
        }
        return objectMapper;
    }

}
