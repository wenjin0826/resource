package com.cloud.vaxservice;

import com.cloud.common.util.RSAUtils;
import org.junit.Test;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/09/21
 */
public class TetrisScoreTest {
    @Test
    public void testTicket() throws Exception {
        RSAUtils.RSAKeyPair rsaKeyPair = RSAUtils.generateKeyPair();
        System.out.println("PublicKey >>> " + rsaKeyPair.getPublicKey());
        System.out.println("PrivateKey >>> " + rsaKeyPair.getPrivateKey());
    }
}
