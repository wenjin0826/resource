CREATE TABLE `t_sys_user`
(
    `id`          int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `username`    varchar(32) NOT NULL COMMENT '用户名',
    `nickname`    varchar(32) NOT NULL COMMENT '昵称',
    `password`    varchar(64) NOT NULL COMMENT '密码',
    `enabled`     int         NOT NULL COMMENT '是否可用',
    `role`        varchar(32) NOT NULL COMMENT '角色',
    `login_ip`    varchar(64) DEFAULT '' COMMENT '登录IP',
    `login_time`  datetime    DEFAULT NULL COMMENT '登录时间',
    `create_time` datetime    DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime    DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '管理员';


CREATE TABLE `t_role`
(
    `id`          int          NOT NULL AUTO_INCREMENT COMMENT '主键',
    `name`        varchar(32)  NOT NULL COMMENT '角色名',
    `access_path` varchar(512) NOT NULL COMMENT '访问路径',
    `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '角色';


CREATE TABLE `t_user`
(
    `id`          bigint NOT NULL COMMENT '主键',
    `phone`       varchar(30)  DEFAULT '' COMMENT '手机号',
    `secret`      varchar(30)  DEFAULT '' COMMENT '密钥',
    `nick_name`   varchar(30)  DEFAULT '' COMMENT '昵称',
    `headimg_url` varchar(300) DEFAULT '' COMMENT '头像地址',
    `wx_open_id`  varchar(50)  DEFAULT '' COMMENT '微信Openid',
    `app`         int          DEFAULT 1 COMMENT '来源的APP',
    `vip`         int          DEFAULT 0 COMMENT 'vip用户',
    `score`       int          DEFAULT 0 COMMENT '积分',
    `status`      int          DEFAULT 1 COMMENT '状态：1表示可用 0表示不可用',
    `create_time` datetime     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT 'APP用户';


CREATE TABLE `t_user_income`
(
    `id`           int    NOT NULL AUTO_INCREMENT COMMENT '主键',
    `user_id`      bigint NOT NULL COMMENT '用户ID',
    `income_type`  int    NOT NULL COMMENT '收入类型',
    `income_money` int    NOT NULL COMMENT '收入金额（单位分）',
    `paid`         int    NOT NULL COMMENT '是否付款：0未支付 1已支付',
    `create_time`  datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '用户收入';


CREATE TABLE `t_invite`
(
    `id`          bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
    `inviter_id`  bigint NOT NULL COMMENT '邀请人ID',
    `invitee_id`  bigint NOT NULL COMMENT '被邀请人ID',
    `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    INDEX         `idx_inviter_id`(`inviter_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '邀请';


CREATE TABLE `t_transcribe`
(
    `id`             int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `locale`         varchar(20) NOT NULL COMMENT '语言',
    `provider`       varchar(20) NOT NULL COMMENT '提供商',
    `task_id`        varchar(60) NOT NULL COMMENT '任务ID',
    `task_status`    varchar(30)  DEFAULT 'Running' COMMENT '任务状态',
    `task_result`    text COMMENT '转录的文案结果',
    `audio_url`      varchar(300) DEFAULT '' COMMENT '音频地址',
    `audio_duration` int          DEFAULT 0 COMMENT '音频时长，单位毫秒',
    `pay_score`      int          DEFAULT 0 COMMENT '支付积分',
    `create_user`    bigint       DEFAULT 0 COMMENT '创建人ID',
    `update_user`    bigint       DEFAULT 0 COMMENT '更新人ID',
    `create_time`    datetime     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`    datetime     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX            `idx_task_id`(`task_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '转录';


CREATE TABLE `t_speech`
(
    `id`          int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `locale`      varchar(20) NOT NULL COMMENT '语言',
    `provider`    varchar(20) NOT NULL COMMENT '提供商',
    `task_id`     varchar(60) NOT NULL COMMENT '任务ID',
    `task_status` varchar(30)  DEFAULT 'Running' COMMENT '任务状态',
    `task_text`   text COMMENT '任务文本',
    `audio_url`   varchar(300) DEFAULT '' COMMENT '音频地址',
    `pay_score`   int          DEFAULT 0 COMMENT '支付积分',
    `create_user` bigint       DEFAULT 0 COMMENT '创建人ID',
    `update_user` bigint       DEFAULT 0 COMMENT '更新人ID',
    `create_time` datetime     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime     DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '配音';

CREATE TABLE `t_payment`
(
    `id`          int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `app`         int                  DEFAULT 1 COMMENT '来源的APP',
    `user_id`     bigint      NOT NULL COMMENT '用户ID',
    `order_no`    varchar(32) NOT NULL COMMENT '订单号',
    `trade_no`    varchar(32)          DEFAULT '' COMMENT '交易号',
    `trade_type`  int         NOT NULL COMMENT '交易类型：1表示H5支付，2表示APP支付',
    `pay_channel` int         NOT NULL COMMENT '支付渠道：1表示微信，2表示支付宝',
    `pay_money`   int         NOT NULL COMMENT '支付金额（单位为分）',
    `pay_title`   varchar(32) NOT NULL COMMENT '支付标题',
    `pay_status`  int         NOT NULL DEFAULT 0 COMMENT '支付状态：0表示未支付，1表示支付成功，2表示支付失败',
    `create_time` datetime             DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime             DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX         `idx_orderno`(`order_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '支付单';


CREATE TABLE `t_transfer_payment`
(
    `id`          int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `user_id`     bigint      NOT NULL COMMENT '用户ID',
    `order_no`    varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
    `pay_channel` int         NOT NULL COMMENT '支付渠道：1表示微信，2表示支付宝',
    `pay_money`   int         NOT NULL COMMENT '支付金额（单位为分）',
    `pay_status`  int         NOT NULL DEFAULT 0 COMMENT '支付状态：0表示待付款，1表示付款成功，2表示付款失败',
    `pay_remark`  varchar(50) NOT NULL COMMENT '支付备注',
    `create_time` datetime             DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime             DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='企业付款单';


CREATE TABLE `t_feedback`
(
    `id`          int NOT NULL AUTO_INCREMENT COMMENT '主键',
    `title`       varchar(50)   DEFAULT '' COMMENT '标题',
    `content`     varchar(1000) DEFAULT '' COMMENT '内容',
    `user_id`     bigint        DEFAULT 0 COMMENT '用户ID',
    `create_time` datetime      DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '反馈';


CREATE TABLE `t_user_task`
(
    `id`          int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `task_id`     varchar(60) NOT NULL COMMENT '任务ID',
    `task_type`   int         DEFAULT 1 COMMENT '任务类型',
    `task_status` int         DEFAULT 1 COMMENT '任务状态',
    `task_title`  varchar(60) DEFAULT '' COMMENT '任务标题',
    `task_result` text COMMENT '任务结果',
    `pay_score`   int         DEFAULT 0 COMMENT '支付积分',
    `create_user` bigint      DEFAULT 0 COMMENT '创建人ID',
    `update_user` bigint      DEFAULT 0 COMMENT '更新人ID',
    `create_time` datetime    DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime    DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX         `idx_task_id`(`task_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '用户任务';


CREATE TABLE `t_article`
(
    `id`           int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `top`          int         NOT NULL DEFAULT 0 COMMENT '置顶',
    `type`         int         NOT NULL DEFAULT 1 COMMENT '分类',
    `title`        varchar(60) NOT NULL COMMENT '标题',
    `content`      text        NOT NULL COMMENT '内容',
    `status`       int                  DEFAULT 1 COMMENT '状态：1表示可用 0表示不可用',
    `img_url`      varchar(200)         DEFAULT '' COMMENT '图片地址',
    `share_url`    varchar(300)         DEFAULT '' COMMENT '分享地址：多个逗号分隔',
    `open_url`     varchar(300)         DEFAULT '' COMMENT '打开地址',
    `open_appid`   varchar(60)          DEFAULT '' COMMENT '打开Appid',
    `view_count`   int                  DEFAULT 0 COMMENT '阅读数',
    `publish_time` datetime             DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    `create_time`  datetime             DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`  datetime             DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '文章';


CREATE TABLE `t_share`
(
    `id`          int    NOT NULL AUTO_INCREMENT COMMENT '主键',
    `channel`     int    NOT NULL DEFAULT 0 COMMENT '渠道 0未知 1表示微信',
    `user_id`     bigint NOT NULL COMMENT '用户ID',
    `article_id`  int    NOT NULL COMMENT '文章ID',
    `view_count`  int             DEFAULT 0 COMMENT '阅读数',
    `create_time` datetime        DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '分享';


CREATE TABLE `t_advertise`
(
    `id`           int         NOT NULL AUTO_INCREMENT COMMENT '主键',
    `title`        varchar(60) NOT NULL COMMENT '标题',
    `content`      text        NOT NULL COMMENT '内容',
    `status`       int          DEFAULT 1 COMMENT '状态：1表示可用 0表示不可用',
    `img_url`      varchar(200) DEFAULT '' COMMENT '图片地址',
    `view_url`     varchar(200) DEFAULT '' COMMENT '查看地址',
    `redirect_url` varchar(200) DEFAULT '' COMMENT '跳转地址',
    `sort_index`   int          DEFAULT 1 COMMENT '排序值',
    `view_count`   int          DEFAULT 0 COMMENT '阅读数',
    `create_time`  datetime     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`  datetime     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '广告';


CREATE TABLE `t_tetris_score`
(
    `id`           bigint NOT NULL COMMENT '主键',
    `user_id`      bigint NOT NULL COMMENT '用户ID',
    `user_ip`      varchar(30)  DEFAULT '' COMMENT '用户IP',
    `nick_name`    varchar(30)  DEFAULT '' COMMENT '用户昵称',
    `headimg_url`  varchar(300) DEFAULT '' COMMENT '头像地址',
    `game_score`   int          DEFAULT 0 COMMENT '游戏分数',
    `reward_level` int          DEFAULT 0 COMMENT '奖励级别',
    `create_time`  datetime     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`  datetime     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    INDEX          `idx_user_id`(`user_id`) USING BTREE,
    INDEX          `idx_game_score`(`game_score`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '俄罗斯方块分数';


CREATE TABLE `t_tetris_reward`
(
    `id`           bigint      NOT NULL COMMENT '主键',
    `user_id`      bigint      NOT NULL COMMENT '用户ID',
    `nick_name`    varchar(30) NOT NULL DEFAULT '' COMMENT '用户昵称',
    `game_score`   int         NOT NULL DEFAULT 0 COMMENT '游戏分数',
    `reward_level` int         NOT NULL DEFAULT 0 COMMENT '奖励级别',
    `paid`         int         NOT NULL DEFAULT 0 COMMENT '是否付款：0未支付 1已支付',
    `description`  varchar(60)          DEFAULT '' COMMENT '描述',
    `create_time`  datetime             DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    INDEX          `idx_user_id`(`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '俄罗斯方块中奖';


CREATE TABLE `t_tetris_playlog`
(
    `id`          bigint NOT NULL COMMENT '主键',
    `user_id`     bigint NOT NULL COMMENT '用户ID',
    `user_ip`     varchar(30)     DEFAULT '' COMMENT '用户IP',
    `game_score`  int    NOT NULL DEFAULT 0 COMMENT '游戏分数',
    `game_level`  int    NOT NULL DEFAULT 0 COMMENT '游戏级别',
    `game_speed`  int    NOT NULL DEFAULT 0 COMMENT '游戏速度',
    `create_time` datetime        DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    INDEX         `idx_user_id`(`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT '俄罗斯方块游戏日志';