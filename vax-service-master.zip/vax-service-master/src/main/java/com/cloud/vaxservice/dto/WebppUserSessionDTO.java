package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * Web应用用户会话
 *
 * @author feng
 * @since 2022-09-19
 */
@Data
public class WebppUserSessionDTO {
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 头像地址
     */
    private String headimgUrl;

    /**
     * 积分
     */
    private Integer score;

    /**
     * 密钥
     */
    private String secret;

    /**
     * 访问令牌
     */
    private String token;
}