package com.cloud.consumer.es.support;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class AggregationResult {
    private String fieldJson;
    private String countName;
    private long countValue;
    private List<AggregationMetric> metricList = new ArrayList<>();

    public void addMetric(AggregationMetric aggregationMetric) {
        metricList.add(aggregationMetric);
    }
}
