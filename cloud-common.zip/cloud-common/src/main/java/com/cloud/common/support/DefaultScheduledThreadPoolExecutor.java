package com.cloud.common.support;

import com.cloud.common.bean.SessionInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.context.TraceContext;
import com.cloud.common.context.VersionContext;

import java.util.concurrent.*;

public class DefaultScheduledThreadPoolExecutor extends ScheduledThreadPoolExecutor {

    public DefaultScheduledThreadPoolExecutor(int corePoolSize) {
        super(corePoolSize);
    }

    public DefaultScheduledThreadPoolExecutor(int corePoolSize, ThreadFactory threadFactory) {
        super(corePoolSize, threadFactory);
    }

    public DefaultScheduledThreadPoolExecutor(int corePoolSize, RejectedExecutionHandler handler) {
        super(corePoolSize, handler);
    }

    public DefaultScheduledThreadPoolExecutor(int corePoolSize, ThreadFactory threadFactory, RejectedExecutionHandler handler) {
        super(corePoolSize, threadFactory, handler);
    }

    @Override
    public void execute(Runnable task) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        super.execute(() -> run(task, traceId, version, sessionInfo));
    }

    @Override
    public <T> Future<T> submit(Runnable task, T result) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.submit(() -> run(task, traceId, version, sessionInfo), result);
    }

    @Override
    public <T> Future<T> submit(Callable<T> task) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.submit(() -> run(task, traceId, version, sessionInfo));
    }

    @Override
    public Future<?> submit(Runnable task) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.submit(() -> run(task, traceId, version, sessionInfo));
    }

    @Override
    public ScheduledFuture<?> schedule(Runnable task, long delay, TimeUnit unit) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.schedule(() -> run(task, traceId, version, sessionInfo), delay, unit);
    }

    @Override
    public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, long initialDelay, long period, TimeUnit unit) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.scheduleAtFixedRate(() -> run(task, traceId, version, sessionInfo), initialDelay, period, unit);
    }

    @Override
    public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, long initialDelay, long delay, TimeUnit unit) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.scheduleWithFixedDelay(() -> run(task, traceId, version, sessionInfo), initialDelay, delay, unit);
    }

    @Override
    public <V> ScheduledFuture<V> schedule(Callable<V> task, long delay, TimeUnit unit) {
        String traceId = TraceContext.get();
        String version = VersionContext.get();
        SessionInfo sessionInfo = SessionContext.get();
        return super.schedule(() -> run(task, traceId, version, sessionInfo), delay, unit);
    }

    private void run(Runnable task, String traceId, String version, SessionInfo sessionInfo) {
        try {
            TraceContext.set(traceId);
            VersionContext.set(version);
            SessionContext.set(sessionInfo);
            task.run();
        } finally {
            TraceContext.remove();
        }
    }

    private <T> T run(Callable<T> task, String traceId, String version, SessionInfo sessionInfo) throws Exception {
        try {
            TraceContext.set(traceId);
            VersionContext.set(version);
            SessionContext.set(sessionInfo);
            return task.call();
        } finally {
            TraceContext.remove();
        }
    }

}
