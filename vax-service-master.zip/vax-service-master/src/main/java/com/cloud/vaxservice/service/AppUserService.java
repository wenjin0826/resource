package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.AppUserQueryParamDTO;
import com.cloud.vaxservice.entity.AppUser;

/**
 * APP用户服务接口
 *
 * @author makejava
 * @since 2024/11/16
 */
public interface AppUserService extends IService<AppUser> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<AppUser> query(AppUserQueryParamDTO paramDTO);

    /**
     * 根据邮箱查询
     *
     * @param email
     * @return User
     */
    AppUser getByEmail(String email);
}
