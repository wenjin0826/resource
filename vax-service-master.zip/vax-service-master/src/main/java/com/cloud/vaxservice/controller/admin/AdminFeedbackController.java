package com.cloud.vaxservice.controller.admin;

import com.cloud.vaxservice.dto.FeedbackDTO;
import com.cloud.vaxservice.dto.FeedbackQueryParamDTO;
import com.cloud.vaxservice.entity.Feedback;
import com.cloud.vaxservice.service.FeedbackService;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * 反馈接口
 *
 * @author feng
 * @since 2021-09-25
 */
@Slf4j
@RestController
public class AdminFeedbackController {
    @Autowired
    private FeedbackService feedbackService;

    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/feedback/query")
    public ResultInfo<PageInfo<FeedbackDTO>> query(@Valid @RequestBody FeedbackQueryParamDTO paramDTO) {
        PageInfo<Feedback> pageInfo = feedbackService.query(paramDTO);
        List<FeedbackDTO> list = ObjectUtils.copy(pageInfo.getRows(), FeedbackDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 根据主键ID删除
     *
     * @param id 主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/feedback/delete")
    public ResultInfo<String> delete(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        feedbackService.removeById(id);
        return ResultInfo.success();
    }
}