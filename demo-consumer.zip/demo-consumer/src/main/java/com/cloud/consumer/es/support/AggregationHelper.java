package com.cloud.consumer.es.support;

import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedTerms;
import org.elasticsearch.search.aggregations.metrics.*;
import org.springframework.data.domain.PageRequest;

import java.util.*;

public class AggregationHelper {
    /**
     * 聚合分析的分页对象，用于控制不返回搜索的数据
     *
     * @return PageRequest
     */
    public static PageRequest aggregationPage() {
        return PageRequest.of(0, 1);
    }

    /**
     * 分组聚合分析时，同时返回命中数据的其他字段，所以返回数量1条就满足了
     *
     * @param fieldNames
     * @return TopHitsAggregationBuilder
     */
    public static TopHitsAggregationBuilder topHitsBuilder(String[] fieldNames) {
        return AggregationBuilders.topHits("fetch_field_hits")
                .fetchSource(fieldNames, null)
                .size(1);
    }

    /**
     * 解析聚合结果
     *
     * @param aggList
     * @return BucketResult
     */
    public static AggregationResult parse(List<Aggregation> aggList) {
        AggregationResult aggregationResult = new AggregationResult();
        aggList.forEach(aggregation -> {
            // 累计计数
            if (aggregation instanceof ParsedValueCount) {
                ParsedValueCount parsedValueCount = (ParsedValueCount) aggregation;
                aggregationResult.setCountName(parsedValueCount.getName());
                aggregationResult.setCountValue(parsedValueCount.getValue());
                return;
            }
            // 去重计算
            if (aggregation instanceof ParsedCardinality) {
                ParsedCardinality parsedCardinality = (ParsedCardinality) aggregation;
                aggregationResult.setCountName(parsedCardinality.getName());
                aggregationResult.setCountValue(parsedCardinality.getValue());
                return;
            }
            // 字段属性
            if (aggregation instanceof ParsedTopHits) {
                ParsedTopHits topHits = (ParsedTopHits) aggregation;
                aggregationResult.setFieldJson(parseTopHits(topHits));
                return;
            }
            // 分组统计
            if (aggregation instanceof ParsedTerms) {
                ParsedTerms terms = (ParsedTerms) aggregation;
                terms.getBuckets().forEach(bucket -> {
                    AggregationMetric metric = new AggregationMetric();
                    metric.setKey(bucket.getKeyAsString());
                    metric.setCount(bucket.getDocCount());
                    aggregationResult.addMetric(metric);

                    bucket.getAggregations().asList().forEach(agg -> {
                        // 字段属性
                        if (agg instanceof ParsedTopHits) {
                            ParsedTopHits topHits = (ParsedTopHits) agg;
                            aggregationResult.setFieldJson(parseTopHits(topHits));
                            return;
                        }
                        parseSubAggregation(agg, metric);
                    });
                });
            }
        });
        return aggregationResult;
    }

    private static String parseTopHits(ParsedTopHits topHits) {
        SearchHit documentFields = Arrays.stream(topHits.getHits().getHits()).findFirst().orElse(null);
        return documentFields.getSourceAsString();
    }

    private static void parseSubAggregation(Aggregation agg, AggregationMetric aggregationMetric) {
        if (agg instanceof ParsedTerms) {
            List<AggregationMetric> subMetricList = new ArrayList<>();
            Map<AggregationMetric, List<Aggregation>> bucketMetricMap = new HashMap<>();

            // 处理分组
            ParsedTerms terms = (ParsedTerms) agg;
            terms.getBuckets().forEach(bucket -> {
                AggregationMetric subAggregationMetric = new AggregationMetric();
                subAggregationMetric.setKey(bucket.getKeyAsString());
                subAggregationMetric.setCount(bucket.getDocCount());
                subMetricList.add(subAggregationMetric);
                bucketMetricMap.put(subAggregationMetric, bucket.getAggregations().asList());
            });
            aggregationMetric.setSubMetricList(subMetricList);

            // 递归处理
            bucketMetricMap.entrySet().forEach(bucketEntry -> {
                List<Aggregation> aggList = bucketEntry.getValue();
                for (Aggregation subAgg : aggList) {
                    parseSubAggregation(subAgg, bucketEntry.getKey());
                }
            });
        } else if (agg instanceof ParsedSum) {
            ParsedSum parsedSum = (ParsedSum) agg;
            aggregationMetric.setSum(parsedSum.getValue());
        } else if (agg instanceof ParsedAvg) {
            ParsedAvg parsedAvg = (ParsedAvg) agg;
            aggregationMetric.setAvg(parsedAvg.getValue());
        } else if (agg instanceof ParsedMin) {
            ParsedMin parsedMin = (ParsedMin) agg;
            aggregationMetric.setMin(parsedMin.getValue());
        } else if (agg instanceof ParsedMax) {
            ParsedMax parsedMax = (ParsedMax) agg;
            aggregationMetric.setMax(parsedMax.getValue());
        }
    }
}
