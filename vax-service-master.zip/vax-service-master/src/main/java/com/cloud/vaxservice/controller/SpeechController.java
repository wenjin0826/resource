package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.dto.SpeechCreateParamDTO;
import com.cloud.vaxservice.dto.SpeechCreateResultDTO;
import com.cloud.vaxservice.dto.SpeechQueryParamDTO;
import com.cloud.vaxservice.entity.Speech;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.SpeechService;
import com.cloud.vaxservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 转录接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class SpeechController {
    @Autowired
    private SpeechService speechService;

    @Autowired
    private UserService userService;

    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/speech/query")
    public ResultInfo<PageInfo<Speech>> query(@Valid @RequestBody SpeechQueryParamDTO paramDTO) {
        paramDTO.setUserId(SessionContext.getUserId());
        PageInfo<Speech> pageInfo = speechService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }

    /**
     * 删除
     *
     * @param id
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/speech/delete")
    public ResultInfo<String> delete(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        speechService.removeById(id);
        return ResultInfo.success();
    }


    /**
     * 创建数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/speech/create")
    @Limit(limitMode = 1, limitCount = 30, durationSeconds = 3600)
    public ResultInfo<SpeechCreateResultDTO> create(@Valid @RequestBody SpeechCreateParamDTO paramDTO) {
        Long userId = SessionContext.getUserId();

        // 判断是否有正在处理中
        if (speechService.existRunning(userId)) {
            return ErrorEnum.EXTRACT_RUNNING.result();
        }

        // 查询用户数据
        int todayFreeCount = speechService.getTodayFreeCount(userId);
        User user = userService.getById(userId);
        int userScore = user.getScore();

        return ResultInfo.success();
    }
}