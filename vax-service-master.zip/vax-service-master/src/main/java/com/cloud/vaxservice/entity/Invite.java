package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 邀请实体类
 *
 * @author feng
 * @since 2022/09/24
 */
@Data
@TableName("t_invite")
public class Invite implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 邀请人ID
     */
    @TableField("inviter_id")
    private Long inviterId;

    /**
     * 被邀请人ID
     */
    @TableField("invitee_id")
    private Long inviteeId;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;


    public static final String ID = "id";
    public static final String INVITER_ID = "inviter_id";
    public static final String INVITEE_ID = "invitee_id";
    public static final String CREATE_TIME = "create_time";
}
