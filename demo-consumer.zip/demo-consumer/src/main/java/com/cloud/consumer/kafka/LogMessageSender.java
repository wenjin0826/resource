package com.cloud.consumer.kafka;

import com.cloud.common.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class LogMessageSender {

    private static final String TOPIC_NAME = "log";

    @Autowired
    private KafkaTemplate kafkaTemplate;

    public void send(Object message) {
        kafkaTemplate.send(TOPIC_NAME, "key", JsonUtils.toJSONString(message));
    }

}
