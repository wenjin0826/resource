package com.cloud.vaxservice.okx.dto;

import lombok.Data;

/**
 * 蜡烛数据
 *
 * @author feng
 * @since 2024/03/08
 */
@Data
public class CandleDataDTO {
    private String ts;
    private String open;
    private String high;
    private String low;
    private String close;
    private String vol;
    private String volCcy;
    private String volCcyQuote;
    private String confirm;
}
