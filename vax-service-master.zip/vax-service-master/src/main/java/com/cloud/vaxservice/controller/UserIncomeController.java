package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.vaxservice.cache.UserIncomeCache;
import com.cloud.vaxservice.dto.IncomeDTO;
import com.cloud.vaxservice.entity.UserIncome;
import com.cloud.vaxservice.service.UserIncomeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 用户收入接口
 */
@Slf4j
@Controller
public class UserIncomeController {
    @Autowired
    private UserIncomeService userIncomeService;

    @Autowired
    private UserIncomeCache userIncomeCache;

    /**
     * 查询用户自己的收入
     *
     * @return ResultInfo
     */
    @ResponseBody
    @PostMapping("/userIncome/query")
    public ResultInfo<IncomeDTO> query() throws Exception {
        Long userId = SessionContext.getUserId();
        IncomeDTO incomeDTO = userIncomeCache.getIncome(userId);
        if (incomeDTO == null) {
            List<UserIncome> paidList = userIncomeService.list(userId, true, null);
            List<UserIncome> unpaidList = userIncomeService.list(userId, false, null);
            int paidIncome = paidList.stream().mapToInt(UserIncome::getIncomeMoney).sum();
            int unpaidIncome = unpaidList.stream().mapToInt(UserIncome::getIncomeMoney).sum();
            incomeDTO = new IncomeDTO(paidIncome, unpaidIncome);
            userIncomeCache.saveIncome(userId, incomeDTO);
        }
        return ResultInfo.success().setData(incomeDTO);
    }
}
