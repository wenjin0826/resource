package com.cloud.common.rpc;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.util.concurrent.DefaultEventExecutorGroup;
import io.netty.util.concurrent.EventExecutorGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

@Slf4j
public class RPCServer implements ApplicationRunner, ApplicationListener<ContextClosedEvent> {

    public static final String SERVER_PORT_PREFIX = "1";

    @Value("${server.port:0}")
    private int serverPort;

    @Value("${rpcServerMaxThreads:0}")
    private int maxThreads;

    @Autowired
    private ServerHandler serverHandler;

    private NioEventLoopGroup bossGroup;
    private NioEventLoopGroup workerGroup;
    private EventExecutorGroup handlerGroup;
    private boolean started;

    public void start() {
        if (started || serverPort <= 0) {
            return;
        }
        started = true;
        maxThreads = maxThreads == 0 ? Runtime.getRuntime().availableProcessors() * 16 : maxThreads;
        bossGroup = new NioEventLoopGroup(1);
        workerGroup = new NioEventLoopGroup();
        handlerGroup = new DefaultEventExecutorGroup(maxThreads);
        try {
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(bossGroup, workerGroup);
            bootstrap.channel(NioServerSocketChannel.class);
            bootstrap.option(ChannelOption.SO_BACKLOG, 1000);
            bootstrap.childOption(ChannelOption.TCP_NODELAY, true);
            bootstrap.childOption(ChannelOption.SO_KEEPALIVE, true);
            bootstrap.handler(new LoggingHandler(LogLevel.INFO));
            bootstrap.childHandler(new ChannelInitializer<SocketChannel>() {
                @Override
                protected void initChannel(SocketChannel socketChannel) throws Exception {
                    ChannelPipeline pipeline = socketChannel.pipeline();
                    pipeline.addLast(new MessageEncoder());
                    pipeline.addLast(new MessageDecoder());
                    pipeline.addLast(handlerGroup, serverHandler);
                }
            });

            int port = Integer.parseInt(SERVER_PORT_PREFIX + serverPort);
            bootstrap.bind(port).sync();
            log.info("rpc server bind port {}", port);
        } catch (Exception e) {
            log.error("RPCServer start error", e);
        }
    }

    public void close() {
        if (bossGroup != null && workerGroup != null && handlerGroup != null) {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
            handlerGroup.shutdownGracefully();

            bossGroup = null;
            workerGroup = null;
            handlerGroup = null;
            started = false;
        }
    }

    @Override
    public void run(ApplicationArguments args) {
        this.start();
    }

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        this.close();
    }
}
