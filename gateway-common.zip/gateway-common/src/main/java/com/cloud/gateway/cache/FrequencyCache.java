package com.cloud.gateway.cache;

import com.cloud.gateway.bean.FrequencyLimit;
import com.cloud.gateway.bean.ResultInfo;
import com.cloud.gateway.util.JsonUtils;
import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;
import com.googlecode.concurrentlinkedhashmap.Weighers;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Slf4j
@Component
@EnableScheduling
public class FrequencyCache {

    private static final String SET_FREQUENCY_LIMIT_KEY = "FrequencyLimit";
    private static final String LIST_FREQUENCY_WARNING_KEY = "FrequencyWarning";

    @Autowired
    private ReactiveRedisTemplate<String, Object> reactiveRedisTemplate;

    private Map<String, FrequencyLimit> limitMap = new HashMap<>();
    private ConcurrentLinkedHashMap<String, CounterInfo> counterMap;

    @PostConstruct
    public void init() {
        counterMap = new ConcurrentLinkedHashMap.Builder<String, CounterInfo>()
                .maximumWeightedCapacity(1000000).weigher(Weighers.singleton()).build();
    }

    public ResultInfo checkAccess(String requestURI, String key) {
        if (StringUtils.isNotEmpty(key)) {
            FrequencyLimit frequencyLimit = limitMap.get(requestURI);
            if (frequencyLimit != null) {
                long currentTime = System.currentTimeMillis();
                String requestKey = requestURI + "@" + key;
                CounterInfo counterInfo = counterMap.get(requestKey);
                if (counterInfo == null || counterInfo.endTime < currentTime) {
                    counterInfo = new CounterInfo();
                    counterInfo.endTime = currentTime + frequencyLimit.getTimeSeconds() * 1000;
                    counterMap.put(requestKey, counterInfo);
                }
                counterInfo.count++;

                if (counterInfo.count > frequencyLimit.getLimitCount()) {
                    if (counterInfo.logTime + 5000 < currentTime) {
                        counterInfo.logTime = currentTime;
                        String content = "frequency limit requestKey=" + requestKey + " limitCount=" + frequencyLimit.getLimitCount() + " currentCount=" + counterInfo.count;
                        saveWarning(content);
                    }
                    return ResultInfo.failure().setCode(HttpStatus.TOO_MANY_REQUESTS.value());
                }
            }
        }
        return ResultInfo.success();
    }

    private void saveWarning(String content) {
        reactiveRedisTemplate.opsForList().leftPush(LIST_FREQUENCY_WARNING_KEY, content).map(size -> {
            if (size > 1000) {
                reactiveRedisTemplate.opsForList().rightPop(LIST_FREQUENCY_WARNING_KEY).subscribe();
            }
            return size;
        }).subscribe();
    }

    @Scheduled(fixedDelay = 5000)
    public void clean() {
        int cleanCount = 0;
        long currentTime = System.currentTimeMillis();
        Iterator<Map.Entry<String, CounterInfo>> iterator = counterMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, CounterInfo> entry = iterator.next();
            if (entry.getValue().endTime < currentTime) {
                iterator.remove();
                cleanCount++;
            }
            if (cleanCount > 200) {
                break;
            }
        }
    }

    @Scheduled(fixedDelay = 30000)
    public void load() {
        limitMap = new HashMap<>();
        reactiveRedisTemplate.opsForSet().members(SET_FREQUENCY_LIMIT_KEY).map(value -> {
            if (value != null && StringUtils.isNotEmpty(value.toString())) {
                if (log.isDebugEnabled()) {
                    log.debug("frequency limit >>> {}", value);
                }
                FrequencyLimit frequencyLimit = JsonUtils.parseObject(value.toString(), FrequencyLimit.class);
                limitMap.put(frequencyLimit.getRequestURI().trim(), frequencyLimit);
            }
            return value;
        }).subscribe();
    }

    @Data
    static class CounterInfo {
        private int count;
        private long logTime;
        private long endTime;
    }

}
