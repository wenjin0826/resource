package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotEmpty;

/**
 * 系统用户登录参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class SysUserLoginParamDTO {
    /**
     * 用户名
     */
    @NotEmpty(message = "用户名不能为空")
    private String username;

    /**
     * 密码
     */
    @NotEmpty(message = "密码不能为空")
    private String password;
}