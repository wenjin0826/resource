console.log("service worker loaded");

let websocket;
let websocketUrl;
let enableWebsocket = false;
let heartbeatInterval;

// 监听消息事件
self.addEventListener('message', (event) => {
    if (event.data) {
        if (event.data.action === 'startWebSocket') {
            websocketUrl = event.data.websocketUrl;
            enableWebsocket = true;
            startWebSocket();
            return;
        }

        if (event.data.action === 'stopWebSocket') {
            enableWebsocket = false;
            closeWebSocket();
            return;
        }
    }
});

// 启动 WebSocket 连接
function startWebSocket() {
    if (websocket) {
        return;
    }

    //websocketUrl = 'ws://localhost:8000/vax-service/websocket?token=xxxxxx';
    websocket = new WebSocket(websocketUrl);

    websocket.onopen = () => {
        console.log('WebSocket connection opened');
        startHeartbeat();
    };

    websocket.onmessage = (event) => {
        console.log('Message from server:', event.data);
        showNotification(event.data);
    };

    websocket.onclose = () => {
        console.log('WebSocket connection closed');
        websocket = null;
        stopHeartbeat();

        // 尝试重连
        if (enableWebsocket) {
            setTimeout(startWebSocket, 5000);
        }
    };

    websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
    };
}

function startHeartbeat() {
    // 开始心跳定时器
    heartbeatInterval = setInterval(() => {
        if (websocket != null && websocket.readyState === WebSocket.OPEN) {
            websocket.send('heartbeat');
            console.log('WebSocket send heartbeat msg');
        }
    }, 60000);
}

function stopHeartbeat() {
    // 清除心跳定时器
    clearInterval(heartbeatInterval);
}

// 关闭 WebSocket 连接
function closeWebSocket() {
    if (websocket) {
        websocket.close();
        websocket = null;
    }
}

// 显示通知
function showNotification(message) {
    let title = navigator.language == "zh-CN" ? "通知" : "Notification";
    self.registration.showNotification(title, {
        body: message,
        icon: 'image/logo-72.png'
    });
}
