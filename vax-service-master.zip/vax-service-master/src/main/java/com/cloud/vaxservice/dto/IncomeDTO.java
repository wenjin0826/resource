package com.cloud.vaxservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 收入DTO
 *
 * @author feng
 * @since 2023/12/22
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncomeDTO {
    /**
     * 已付款收入
     */
    private Integer paidIncome;

    /**
     * 未付款收入
     */
    private Integer unpaidIncome;
}
