package com.cloud.common.context;

import lombok.Data;
import org.springframework.web.method.HandlerMethod;

import java.util.LinkedHashMap;

/**
 * 请求映射
 *
 * @author fengwenjin
 */
@Data
public class RequestMapping {
    private String mappingUri;
    private Object handlerTarget;
    private HandlerMethod handlerMethod;
    private LinkedHashMap<String, Class> parameterMap;
}
