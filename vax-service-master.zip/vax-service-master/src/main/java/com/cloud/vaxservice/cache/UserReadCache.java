package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

@Component
public class UserReadCache {
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public boolean add(String value) {
        String key = "UserRead:" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        Long count = redisTemplate.opsForSet().add(key, value);
        if (count != null && count.intValue() == 1) {
            redisTemplate.expire(key, 24, TimeUnit.HOURS);
            return true;
        }
        return false;
    }
}
