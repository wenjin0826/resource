package com.cloud.common.exception;

import com.cloud.common.bean.ResultInfo;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.List;

/**
 * 全局异常处理
 *
 * @author fengwenjin
 */
@Slf4j
@ResponseBody
@ControllerAdvice
public class GlobalExceptionHandler {

    @Autowired
    private MessageSource messageSource;

    /**
     * 内部错误
     *
     * @param request
     * @param exception
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(Exception.class)
    public ResultInfo handleException(HttpServletRequest request, Exception exception) {
        log.error("requestURI=" + request.getRequestURI() + ", exception=" + exception.getMessage(), exception);

        String message = messageSource.getMessage(HttpStatus.INTERNAL_SERVER_ERROR.name(), null, LocaleContextHolder.getLocale());
        return new ResultInfo().setCode(HttpStatus.INTERNAL_SERVER_ERROR.value()).setMessage(message);
    }

    /**
     * 业务逻辑处理发生的异常
     *
     * @param exception
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(AppException.class)
    public ResultInfo handleAppException(AppException exception) {
        log.warn(exception.getMessage());

        int code = exception.getCode();
        code = code == 0 ? HttpStatus.EXPECTATION_FAILED.value() : code;
        String message = messageSource.getMessage(exception.getMessage(), null, LocaleContextHolder.getLocale());
        return ResultInfo.failure().setCode(code).setMessage(message);
    }

    /**
     * 参数绑定错误
     *
     * @param exception
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(BindException.class)
    public ResultInfo handleBindException(BindException exception) {
        String message = messageSource.getMessage(HttpStatus.BAD_REQUEST.name(), null, LocaleContextHolder.getLocale());
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(message);
    }

    /**
     * 参数匹配错误
     *
     * @param exception
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResultInfo handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException exception) {
        String message = messageSource.getMessage(HttpStatus.BAD_REQUEST.name(), null, LocaleContextHolder.getLocale());
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(message);
    }

    /**
     * 参数验证错误
     *
     * @param exception
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResultInfo handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        String message;
        List<FieldError> fieldErrors = exception.getBindingResult().getFieldErrors();
        if (CollectionUtils.isNotEmpty(fieldErrors)) {
            List<String> list = fieldErrors.stream().map(FieldError::getField).toList();
            message = "(" + StringUtils.join(list, ",") + ")";
        } else {
            message = messageSource.getMessage(HttpStatus.BAD_REQUEST.name(), null, LocaleContextHolder.getLocale());
        }
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(message);
    }

    /**
     * 请求无效
     *
     * @param exception
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResultInfo handleNotReadableException(HttpMessageNotReadableException exception) {
        String message = messageSource.getMessage(HttpStatus.BAD_REQUEST.name(), null, LocaleContextHolder.getLocale());
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(message);
    }

    /**
     * 请求方法不支持
     *
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResultInfo handleRequestMethodNotSupportedException() {
        return new ResultInfo().setCode(HttpStatus.METHOD_NOT_ALLOWED.value());
    }

    /**
     * 请求资源不存在
     *
     * @return ResultInfo
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResultInfo handleNoHandlerFoundException() {
        return new ResultInfo().setCode(HttpStatus.NOT_FOUND.value());
    }
}