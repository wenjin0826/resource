package com.cloud.common.bean;

import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotEmpty;

@Data
public class Message {

    public static final String LEVEL_LOWER = "Lower";
    public static final String LEVEL_NORMAL = "Normal";
    public static final String LEVEL_HIGHER = "Higher";

    @NotEmpty(message = "消息级别不能为空")
    private String level = LEVEL_NORMAL;

    @NotEmpty(message = "消息主题不能为空")
    @Length(max = 32, message = "消息主题长度不能超过32")
    private String topic;

    @NotEmpty(message = "消息内容不能为空")
    private String content;

    @NotEmpty(message = "消息路由Key不能为空")
    @Length(max = 32, message = "消息路由Key长度不能超过32")
    private String hashKey;

    @Range(min = 0, max = 15552000, message = "延时秒数在0~15552000秒之间")
    private Integer delaySeconds = 0;

}
