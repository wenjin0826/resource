package com.cloud.vaxservice.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * 文章
 *
 * @author feng
 * @since 2021-10-03
 */
@Data
public class ArticleDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 置顶
     */
    private Integer top;

    /**
     * 分类
     */
    private Integer type;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 状态：1表示可用 0表示不可用
     */
    private Integer status;

    /**
     * 图片地址
     */
    private String imgUrl;

    /**
     * 分享地址：多个逗号分隔
     */
    private String shareUrl;

    /**
     * 打开地址
     */
    private String openUrl;

    /**
     * 打开Appid
     */
    private String openAppid;

    /**
     * 阅读数
     */
    private Integer viewCount;

    /**
     * 发布日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date publishTime;
}