package com.cloud.consumer.es;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class BucketResult {
    private String fieldJSONString;
    private List<BucketMetric> bucketMetricList = new ArrayList<>();

    public void addBucketMetric(BucketMetric bucketMetric) {
        bucketMetricList.add(bucketMetric);
    }
}
