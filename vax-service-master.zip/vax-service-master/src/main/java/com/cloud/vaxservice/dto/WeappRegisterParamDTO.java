package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 微信小程序用户新增参数
 *
 * @author feng
 * @since 2022/09/19
 */
@Data
public class WeappRegisterParamDTO {
    /**
     * 昵称
     */
    private String nickName;

    /**
     * 头像地址
     */
    private String headimgUrl;

    /**
     * 微信code
     */
    @NotEmpty(message = "微信code不能为空")
    private String wechatCode;

    /**
     * 邀请人ID
     */
    private Long inviterId;
}
