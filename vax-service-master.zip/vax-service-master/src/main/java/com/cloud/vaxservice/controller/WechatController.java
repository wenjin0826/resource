package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.IDUtils;
import com.cloud.common.util.RSAUtils;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.config.WechatConfig;
import com.cloud.vaxservice.constant.*;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.Invite;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.InviteService;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.support.SessionHelper;
import com.cloud.vaxservice.support.WechatHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Date;

/**
 * 微信URL接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class WechatController {
    @Autowired
    private InviteService inviteService;

    @Autowired
    private UserService userService;

    @Autowired
    private WechatHelper wechatHelper;

    @Autowired
    private SessionHelper sessionHelper;

    @Autowired
    private WechatConfig wechatConfig;

    @Autowired
    private VaxConfig vaxConfig;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @ResponseBody
    @PostMapping("/weapp/login")
    public ResultInfo<UserSessionDTO> weappLogin(@Valid @RequestBody SecretLoginParamDTO paramDTO) throws Exception {
        Long userId = paramDTO.getUserId();
        String secret = paramDTO.getSecret();
        if (userId == null || StringUtils.isEmpty(secret)) {
            return ResultInfo.badRequest();
        }
        User user = userService.getById(userId);
        if (user == null) {
            log.warn("login failure user not exist, requestIP=" + RequestContext.getRequestIP());
            return ResultInfo.failure();
        }
        if (user.getStatus() == Constants.NO) {
            log.warn("login failure user disable, userId=" + userId);
            return ErrorEnum.USER_DISABLE.result();
        }

        secret = RSAUtils.decryptByPrivateKey(RSAWeAppKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getSecret());
        if (!user.getSecret().equals(secret)) {
            log.warn("login failure secret error, userId=" + userId);
            return ErrorEnum.LOGIN_FAILURE.result();
        }

        UserSessionDTO sessionDTO = sessionHelper.createUserSession(user, AppEnum.EXTRACT);
        return ResultInfo.success().setData(sessionDTO);
    }

    @ResponseBody
    @PostMapping("/weapp/register")
    public ResultInfo<UserSessionDTO> weappRegister(@Valid @RequestBody WeappRegisterParamDTO paramDTO) throws Exception {
        String wechatCode = RSAUtils.decryptByPrivateKey(RSAWeAppKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getWechatCode());
        if (StringUtils.isEmpty(wechatCode)) {
            return ResultInfo.badRequest();
        }
        final String lockKey = AppEnum.EXTRACT.name() + ":LockWechatCode:" + paramDTO.getWechatCode();
        if (!RemoteLock.lock(lockKey, 0)) {
            return ResultInfo.failure().setCode(HttpStatus.PROCESSING.value());
        }
        try {
            String wechatOpenId = wechatHelper.getOpenidForMP(wechatCode, wechatConfig.getWeAppId(), wechatConfig.getWeAppSecret());
            if (StringUtils.isEmpty(wechatOpenId)) {
                log.warn("register user wechatCode error, wechatCode=" + paramDTO.getWechatCode());
                return ErrorEnum.WECHAT_CODE_ERROR.result();
            }
            User user = userService.getByWxOpenId(wechatOpenId);
            if (user == null) {
                user = new User();
                user.setId(IDUtils.nextId());
                user.setSecret(RandomStringUtils.randomAlphanumeric(16));
                user.setNickName(paramDTO.getNickName());
                user.setHeadimgUrl(paramDTO.getHeadimgUrl());
                user.setWxOpenId(wechatOpenId);
                user.setScore(0);
                user.setStatus(Constants.OK);
                user.setCreateTime(new Date());
                user.setUpdateTime(new Date());
                userService.save(user);

                // 推广邀请处理
                if (paramDTO.getInviterId() != null) {
                    User inviter = userService.getById(paramDTO.getInviterId());
                    if (inviter != null) {
                        Invite invite = new Invite();
                        invite.setInviterId(paramDTO.getInviterId());
                        invite.setInviteeId(user.getId());
                        invite.setCreateTime(new Date());
                        inviteService.save(invite);
                    }
                }
            } else {
                user.setNickName(paramDTO.getNickName());
                user.setHeadimgUrl(paramDTO.getHeadimgUrl());
                userService.updateById(user);
            }
            UserSessionDTO sessionDTO = sessionHelper.createUserSession(user, AppEnum.EXTRACT);
            return ResultInfo.success().setData(sessionDTO);
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }

    /**
     * 微信登录
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/wechat/login")
    @Limit(limitCount = 10, durationSeconds = 300)
    public ResultInfo<UserSessionDTO> wechatLogin(@Valid @RequestBody WechatLoginParamDTO paramDTO) throws Exception {
        String code = RSAUtils.decryptByPrivateKey(RSAKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getCode());
        if (StringUtils.isEmpty(code)) {
            log.warn("wechat code={} invalid", paramDTO.getCode());
            return ResultInfo.badRequest();
        }
        // 查询微信用户信息
        WechatUserInfoDTO wechatUserInfo = wechatHelper.getUserInfoForApp(code, wechatConfig.getAppId(), wechatConfig.getAppSecret());
        String headimgUrl = wechatUserInfo.getHeadimgUrl();
        headimgUrl = StringUtils.isEmpty(headimgUrl) ? vaxConfig.getAvatarUrl() : headimgUrl;

        User user = userService.getByWxOpenId(wechatUserInfo.getOpenId());
        // 创建用户
        if (user == null) {
            user = new User();
            user.setId(IDUtils.nextId());
            user.setWxOpenId(wechatUserInfo.getOpenId());
            user.setNickName(wechatUserInfo.getNickName());
            user.setHeadimgUrl(headimgUrl);
            user.setSecret(RandomStringUtils.randomAlphanumeric(16));
            user.setStatus(Constants.OK);
            user.setCreateTime(new Date());
            userService.save(user);
        } else {
            user.setWxOpenId(wechatUserInfo.getOpenId());
            user.setNickName(wechatUserInfo.getNickName());
            user.setHeadimgUrl(headimgUrl);
            user.setSecret(RandomStringUtils.randomAlphanumeric(16));
            user.setUpdateTime(new Date());
            userService.updateById(user);
        }
        UserSessionDTO sessionDTO = sessionHelper.createUserSession(user, AppEnum.EXTRACT);
        return ResultInfo.success().setData(sessionDTO);
    }

    /**
     * 获取签名
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/wechat/getSignature")
    public ResultInfo<WechatSignDTO> getSignature(@Valid @RequestBody WechatGetSignatureParamDTO paramDTO) {
        WechatSignDTO signDTO = wechatHelper.getSignature(paramDTO.getUrl(), wechatConfig.getMpAppId(), wechatConfig.getMpAppSecret());
        return ResultInfo.success().setData(signDTO);
    }

    /**
     * 获取Scheme码
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/wechat/getURLScheme")
    public ResultInfo<String> getURLScheme(@Valid @RequestBody WechatGetURLSchemaParamDTO paramDTO) {
        String ticketKey = Constants.WEAPP_TICKET + ":" + paramDTO.getTicket();
        if (paramDTO.getArticleId() == null || redisTemplate.opsForValue().get(ticketKey) == null) {
            return ResultInfo.badRequest();
        }
        WechatWxaGenerateSchemeParamDTO schemeParamDTO = new WechatWxaGenerateSchemeParamDTO();
        schemeParamDTO.setIsExpire(true);
        schemeParamDTO.setExpireType(1);
        schemeParamDTO.setExpireInterval(1);
        WechatWxaGenerateSchemeParamDTO.JumpWxaDTO jumpWxaDTO = new WechatWxaGenerateSchemeParamDTO.JumpWxaDTO();
        jumpWxaDTO.setPath("/pages/recommend-list");
        String query = "openDetail=true&id=" + paramDTO.getArticleId();
        Long inviterId = paramDTO.getInviterId();
        if (inviterId != null && inviterId > 0) {
            query += "&inviterId=" + inviterId;
        }
        jumpWxaDTO.setQuery(query);
        schemeParamDTO.setJumpWxa(jumpWxaDTO);

        String urlScheme = wechatHelper.getURLScheme(schemeParamDTO, wechatConfig.getWeAppId(), wechatConfig.getWeAppSecret());
        return ResultInfo.success().setData(urlScheme);
    }
}