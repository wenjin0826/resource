package com.cloud.vaxservice.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "vax")
public class VaxConfig {
    /**
     * 公告提示
     */
    private String noticeTip;

    /**
     * 免费配音文本长度
     */
    private int freeTextLen;

    /**
     * 免费时长分钟
     */
    private int freeMinutes;

    /**
     * 每天免费限制次数
     */
    private int freeLimitCount;

    /**
     * 语音文件大小最大（单位M)
     */
    private int maxAudioSize;

    /**
     * 语音文件最大时长分钟
     */
    private int maxAudioMinutes;

    /**
     * 构建时间
     */
    private int buildTime;

    /**
     * 版本号
     */
    private int versionCode;

    /**
     * 版本下载地址
     */
    private String versionUrl;

    /**
     * 默认头像地址
     */
    private String avatarUrl;

    /**
     * 网站地址
     */
    private String siteUrl;
}
