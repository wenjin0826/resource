package com.cloud.common.rpc;

import com.cloud.common.util.JsonUtils;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.springframework.stereotype.Component;

@Sharable
@Component
public class ClientHandler extends SimpleChannelInboundHandler<RPCMessage> {

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RPCMessage msg) {
        ResponseFuture future = ResponseFutureManager.remove(msg.getSequence());
        if (future != null) {
            Object result = JsonUtils.parseObject(msg.getBodyData(), future.getReturnType());
            future.setResult(result);
        }
    }
}
