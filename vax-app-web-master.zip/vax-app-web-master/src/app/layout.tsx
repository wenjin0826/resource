import {Client, HydrationProvider} from "react-hydration-provider";
import {AntdRegistry} from "@ant-design/nextjs-registry";
import FrameLayout from "../layouts/FrameLayout";
import {BASE_PATH} from "@/commons/global";
import React from "react";
import {Metadata} from 'next'
import "./globals.css";
import {getText} from "@/commons/locale";

export const metadata: Metadata = {
    title: `${getText("aiaitou")}`,
    description: `${getText("aiaitou_description")}`,
    manifest: BASE_PATH + '/manifest.json',
}

interface Props {
    children: React.ReactNode;
}

export default function RootLayout({children}: Props) {
    return (
        <html lang="zh">
        <body>
        <HydrationProvider>
            <AntdRegistry>
                <Client>
                    <FrameLayout>
                        {children}
                    </FrameLayout>
                </Client>
            </AntdRegistry>
        </HydrationProvider>
        </body>
        </html>
    );
}
