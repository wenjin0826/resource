package com.cloud.common.validator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

/**
 * 手机号校验注解
 *
 * @author fengwenjin
 */
@Documented
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(PhoneNumberCheck.List.class)
@Constraint(validatedBy = {PhoneNumberValidator.class})
public @interface PhoneNumberCheck {
    String message() default "{*.validation.constraint.PhoneNumberCheck.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    @Documented
    @Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
        PhoneNumberCheck[] value();
    }
}
