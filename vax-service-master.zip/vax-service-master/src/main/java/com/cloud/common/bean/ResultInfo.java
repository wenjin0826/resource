package com.cloud.common.bean;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.http.HttpStatus;

/**
 * 结果信息
 *
 * @author fengwenjin
 */
@Data
@Accessors(chain = true)
public class ResultInfo<T> {
    /**
     * 状态码
     * 200成功
     * 400参数错误
     * 401未经授权
     * 403禁止访问
     * 404请求路径不存在
     * 405请求方法不允许
     * 417执行失败
     * 423熔断限流
     * 429访问频繁
     * 500系统错误
     */
    private int code;

    /**
     * 消息
     */
    private String message;

    /**
     * 数据
     */
    private T data;

    public static <T> ResultInfo<T> success() {
        return new ResultInfo<T>().setCode(HttpStatus.OK.value());
    }

    public static <T> ResultInfo<T> failure() {
        return new ResultInfo<T>().setCode(HttpStatus.EXPECTATION_FAILED.value());
    }

    public static <T> ResultInfo<T> badRequest() {
        return new ResultInfo<T>().setCode(HttpStatus.BAD_REQUEST.value());
    }

    public static <T> ResultInfo<T> manyRequest() {
        return new ResultInfo<T>().setCode(HttpStatus.TOO_MANY_REQUESTS.value());
    }

    public <T> ResultInfo<T> setCode(int code) {
        this.code = code;
        return (ResultInfo<T>) this;
    }

    public <T> ResultInfo<T> setMessage(String message) {
        this.message = message;
        return (ResultInfo<T>) this;
    }

    public <DT> ResultInfo<DT> setData(DT data) {
        this.data = (T) data;
        return (ResultInfo<DT>) this;
    }

    public boolean successful() {
        return this.code == HttpStatus.OK.value();
    }
}