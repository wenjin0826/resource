package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum IncomeTypeEnum {

    INVITE_RECHARGE(1, "邀请充值收入");

    @Getter
    private int code;

    @Getter
    private String description;

    IncomeTypeEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static IncomeTypeEnum of(int code) {
        for (IncomeTypeEnum typeEnum : values()) {
            if (typeEnum.code == code) {
                return typeEnum;
            }
        }
        return null;
    }

}
