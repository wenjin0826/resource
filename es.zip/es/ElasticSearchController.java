package com.cloud.consumer.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.consumer.es.AggregationSupport;
import com.cloud.consumer.es.BucketResult;
import com.cloud.consumer.es.IndexProduct;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/es")
public class ElasticSearchController {

    @Autowired
    private ElasticsearchRestTemplate elasticsearch;

    @PostMapping("/save")
    public ResultInfo save() {
        IndexProduct indexProduct = new IndexProduct();
        indexProduct.setId(15L);
        indexProduct.setName("小米青春版手机");
        indexProduct.setType("1");
        indexProduct.setLabel("phone");
        indexProduct.setColor("blue");
        indexProduct.setAmount(5000);
        indexProduct.setPrice(156900);
        indexProduct.setSupplier("xiaomi");
        indexProduct.setYear("2020");
        indexProduct.setQuarter("quarterOne");
        indexProduct.setDescription("小米热门畅销手机");
        indexProduct.setImgUrl("http://xxxxxxxx");
        elasticsearch.save(indexProduct);
        return ResultInfo.success();
    }

    @GetMapping("/search")
    public ResultInfo search() {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        //queryBuilder.must(QueryBuilders.rangeQuery(Product.PRICE).gte(199900).lte(399900));
        queryBuilder.should(QueryBuilders.termsQuery(IndexProduct.LABEL, "phone", "watch"));

        NativeSearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.boolQuery().filter(queryBuilder))
                .addAggregation(AggregationBuilders.terms("group_by_type").field(IndexProduct.TYPE)
                        .size(AggregationSupport.AGGREGATION_SIZE).order(BucketOrder.count(true))
                        .subAggregation(AggregationBuilders.terms("group_by_color").field(IndexProduct.COLOR))
                        //.subAggregation(AggregationBuilders.max("max_price").field(IndexProduct.PRICE))
                        .subAggregation(AggregationSupport.topHitsBuilder(new String[] {
                                IndexProduct.LABEL,
                                IndexProduct.SUPPLIER
                        })))
                .withPageable(AggregationSupport.aggregationPage())
                .build();
        SearchHits<IndexProduct> searchHits = elasticsearch.search(searchQuery, IndexProduct.class);
        BucketResult bucketResult = AggregationSupport.parse(searchHits.getAggregations().asList());
        return ResultInfo.success();
    }
}
