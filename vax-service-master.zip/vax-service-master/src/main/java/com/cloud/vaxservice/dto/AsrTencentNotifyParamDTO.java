package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 功能描述
 *
 * @author fengwenjin
 * @since 2021/12/31
 */
@Data
public class AsrTencentNotifyParamDTO {
    private Integer code;
    private String message;
    private Long requestId;
    private String audioUrl;
    private String text;
    private Double audioTime;
}
