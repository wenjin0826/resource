package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.ShareQueryParamDTO;
import com.cloud.vaxservice.entity.Share;

/**
 * 分享服务接口
 *
 * @author feng
 * @since 2022/06/11
 */
public interface ShareService extends IService<Share> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Share> query(ShareQueryParamDTO paramDTO);

    /**
     * 根据用户ID和文章ID获取
     *
     * @param userId
     * @param articleId
     * @return Share
     */
    Share get(Long userId, Integer articleId);

    /**
     * 增加阅读数
     *
     * @param userId
     * @param articleId
     */
    void incrViewCount(Long userId, Integer articleId);
}