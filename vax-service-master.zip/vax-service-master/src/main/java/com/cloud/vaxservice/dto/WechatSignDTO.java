package com.cloud.vaxservice.dto;

import lombok.Data;

@Data
public class WechatSignDTO {
    private String appId;
    private String nonceStr;
    private Long timestamp;
    private String signature;
}
