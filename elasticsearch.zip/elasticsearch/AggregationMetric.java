package com.cloud.common.elasticsearch;

import lombok.Data;

import java.util.List;

@Data
public class AggregationMetric {
    private String key;
    private long count;
    private double min;
    private double max;
    private double sum;
    private double avg;
    private List<AggregationMetric> subMetricList;
}
