// @ts-ignore
/* eslint-disable */
import request from "@/commons/request";

/** 此处后端没有提供注释 GET /file/getCredential */
export async function getFileCredential(options?: { [key: string]: any }) {
  return request<API.ResultInfoAliyunOssCredentialDTO>("/file/getCredential", {
    method: "GET",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 PUT /file/getCredential */
export async function getFileCredential3(options?: { [key: string]: any }) {
  return request<API.ResultInfoAliyunOssCredentialDTO>("/file/getCredential", {
    method: "PUT",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /file/getCredential */
export async function getFileCredential2(options?: { [key: string]: any }) {
  return request<API.ResultInfoAliyunOssCredentialDTO>("/file/getCredential", {
    method: "POST",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 DELETE /file/getCredential */
export async function getFileCredential5(options?: { [key: string]: any }) {
  return request<API.ResultInfoAliyunOssCredentialDTO>("/file/getCredential", {
    method: "DELETE",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 PATCH /file/getCredential */
export async function getFileCredential4(options?: { [key: string]: any }) {
  return request<API.ResultInfoAliyunOssCredentialDTO>("/file/getCredential", {
    method: "PATCH",
    ...(options || {}),
  });
}
