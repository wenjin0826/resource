package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum AppEnum {
    ADMIN(0, "管理后台应用"),
    EXTRACT(1, "语音速转文字应用");

    @Getter
    private int code;

    @Getter
    private String description;

    AppEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static AppEnum of(int code) {
        for (AppEnum appEnum : values()) {
            if (appEnum.code == code) {
                return appEnum;
            }
        }
        return null;
    }
}
