package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.constant.StatusEnum;
import com.cloud.vaxservice.dao.SpeechDao;
import com.cloud.vaxservice.dto.SpeechQueryParamDTO;
import com.cloud.vaxservice.entity.Speech;
import com.cloud.vaxservice.service.SpeechService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 配音服务实现类
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Service
public class SpeechServiceImpl extends ServiceImpl<SpeechDao, Speech> implements SpeechService {

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(Speech entity) {
        super.save(entity);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateById(Speech entity) {
        super.updateById(entity);
        return true;
    }

    @Override
    public PageInfo<Speech> query(SpeechQueryParamDTO paramDTO) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(Speech.CREATE_USER, paramDTO.getUserId());
        }
        wrapper.orderByDesc(Speech.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Speech getByTaskId(String taskId) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.TASK_ID, taskId);
        return getOne(wrapper, false);
    }

    @Override
    public List<Speech> getByTaskIds(List<String> taskIds) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.in(Speech.TASK_ID, taskIds);
        return list(wrapper);
    }

    @Override
    public int getTodayFreeCount(Long userId) {
        Date beginTime = DateTimeUtils.asDate(LocalDate.now());
        Date endTime = DateTimeUtils.asDate(LocalDate.now().plusDays(1));
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.CREATE_USER, userId);
        wrapper.eq(Speech.PAY_SCORE, 0);
        wrapper.gt(Speech.CREATE_TIME, beginTime);
        wrapper.lt(Speech.CREATE_TIME, endTime);
        wrapper.select(Speech.TASK_ID);
        return list(wrapper).size();
    }

    /**
     * 是否存在正在运行的转录
     *
     * @param userId
     * @return boolean
     */
    @Override
    public boolean existRunning(Long userId) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.CREATE_USER, userId);
        wrapper.eq(Speech.TASK_STATUS, StatusEnum.RUNNING.getStatus());
        return list(wrapper).size() > 0;
    }
}