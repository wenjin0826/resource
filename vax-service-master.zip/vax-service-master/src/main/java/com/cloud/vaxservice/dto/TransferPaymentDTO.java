package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 企业付款单对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class TransferPaymentDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 订单号
     */
    private String orderNo;

    /**
     * 支付渠道：1表示微信，2表示支付宝
     */
    private Integer payChannel;

    /**
     * 支付金额（单位为分）
     */
    private Integer payMoney;

    /**
     * 支付状态：0表示待付款，1表示付款成功，2表示付款失败
     */
    private Integer payStatus;

    /**
     * 支付备注
     */
    private String payRemark;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
