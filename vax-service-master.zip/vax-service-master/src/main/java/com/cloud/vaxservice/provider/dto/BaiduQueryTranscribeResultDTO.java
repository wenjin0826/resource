package com.cloud.vaxservice.provider.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * 百度查询转录结果
 *
 * @author feng
 * @since 2021/9/2
 */
@Data
public class BaiduQueryTranscribeResultDTO {
    @JsonProperty("log_id")
    private String logId;

    @JsonProperty("tasks_info")
    private List<BaiduTranscribeResultDTO> resultList;
}
