package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.util.IDUtils;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.*;
import com.cloud.vaxservice.dto.SpeechCreateParamDTO;
import com.cloud.vaxservice.dto.SpeechQueryParamDTO;
import com.cloud.vaxservice.entity.Speech;
import com.cloud.vaxservice.entity.Subscription;
import com.cloud.vaxservice.provider.AliyunOssProvider;
import com.cloud.vaxservice.provider.TencentSpeechProvider;
import com.cloud.vaxservice.service.SpeechService;
import com.cloud.vaxservice.service.SubscriptionService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 转录接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class SpeechController {
    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private SpeechService speechService;

    @Autowired
    private TencentSpeechProvider speechProvider;

    @Autowired
    private AliyunOssProvider ossProvider;

    @Autowired
    private VaxConfig vaxConfig;

    @Autowired
    private MessageSource messageSource;


    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/speech/query")
    public ResultInfo<PageInfo<Speech>> querySpeech(@Valid @RequestBody SpeechQueryParamDTO paramDTO) {
        paramDTO.setUserId(SessionContext.getUserId());
        PageInfo<Speech> pageInfo = speechService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }

    /**
     * 删除
     *
     * @param id
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/speech/delete")
    public ResultInfo<String> deleteSpeech(Integer id) {
        Speech speech = speechService.getById(id);
        if (speech == null || !speech.getUserId().equals(SessionContext.getUserId())) {
            return ResultInfo.badRequest();
        }
        speechService.removeById(id);

        String audioUrl = speech.getAudioUrl();
        String fileKey = audioUrl.substring(audioUrl.indexOf("speech"));
        ossProvider.deleteObject(fileKey);
        return ResultInfo.success();
    }


    /**
     * 创建数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/speech/create")
    @Limit(limitMode = 1, limitCount = 30, durationSeconds = 3600)
    public ResultInfo<String> createSpeech(@Valid @RequestBody SpeechCreateParamDTO paramDTO) {
        Long userId = SessionContext.getUserId();

        // 判断是否有正在处理中
        if (speechService.existRunning(userId)) {
            throw ErrorEnum.PROCESSING.exception();
        }

        // 查询用户数据
        int todayFreeCount = speechService.getTodayFreeCount(userId);
        Subscription subscription = subscriptionService.getSubscription(userId, ProductEnum.VOICE_TO_TEXT.name());
        int remainValue = subscription != null ? subscription.getRemainValue() : 0;

        int freeTextLen = vaxConfig.getFreeTextLen();
        int textLen = paramDTO.getSpeechText().length();
        int needTextLen = (textLen + freeTextLen - 1) / freeTextLen;

        if (textLen <= freeTextLen) {
            // 判断免费的次数
            if (todayFreeCount >= vaxConfig.getFreeLimitCount() && remainValue < needTextLen) {
                String message = messageSource.getMessage(ErrorEnum.TODAY_FREE_LIMITED.name(), null, LocaleContextHolder.getLocale());
                return ResultInfo.failure().setMessage(message);
            }
        } else if (remainValue < needTextLen){
            String message = messageSource.getMessage(ErrorEnum.REMAIN_VALUE_NOT_ENOUGH.name(), null, LocaleContextHolder.getLocale());
            return ResultInfo.failure().setMessage(message);
        }

        Speech speech = new Speech();
        speech.setLanguage(LanguageEnum.CHINESE.name());
        speech.setProvider(CloudProviderEnum.TENCENT.name());
        speech.setTaskId(String.valueOf(IDUtils.nextId()));
        speech.setSpeechText(paramDTO.getSpeechText());
        speech.setVoiceType(paramDTO.getVoiceType() + "");
        speech.setVoiceVolume(paramDTO.getVoiceVolume() + "");
        speech.setVoiceSpeed(paramDTO.getVoiceSpeed() + "");
        speech.setTaskStatus(TaskStatusEnum.RUNNING.getStatus());
        speech.setUserId(userId);
        speechService.save(speech);

        speechProvider.create(speech);
        return ResultInfo.success();
    }
}