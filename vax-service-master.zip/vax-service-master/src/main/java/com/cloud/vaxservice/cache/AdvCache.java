package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

@Component
public class AdvCache {
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public int inspireView() {
        String key = "InspireViewCount:" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int count = redisTemplate.opsForValue().increment(key).intValue();
        redisTemplate.expire(key, 24, TimeUnit.HOURS);
        return count;
    }
}
