package com.cloud.gateway.cache;

import com.cloud.gateway.bean.ReleaseInfo;
import com.cloud.gateway.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@EnableScheduling
public class ReleaseCache {

    private static final String STRING_RELEASE_INFO_KEY = "ReleaseInfo";

    @Autowired
    private ReactiveRedisTemplate<String, Object> reactiveRedisTemplate;

    private List<ReleaseInfo> releases;

    public List<ReleaseInfo> getReleases() {
        return releases == null ? Collections.EMPTY_LIST : releases;
    }

    @Scheduled(fixedDelay = 30000)
    public void load() {
        reactiveRedisTemplate.opsForValue().get(STRING_RELEASE_INFO_KEY).map(value -> {
            if (value != null) {
                log.debug("releases version >>> {}" + value.toString());
                List<ReleaseInfo> list = JsonUtils.parseArray(value.toString(), ReleaseInfo.class);
                releases = list.stream().sorted(Comparator.comparing(ReleaseInfo::getVersion).reversed())
                        .collect(Collectors.toList());
            }
            return value;
        }).subscribe();
    }

}
