package com.cloud.vaxservice.dto;

import com.cloud.common.util.DateTimeUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * 用户收入对象
 *
 * @author feng
 * @since 2022/10/10
 */
@Data
public class UserIncomeDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户ID
     */
    private String userFrom;

    /**
     * 收入日期
     */
    @JsonFormat(pattern = DateTimeUtils.DATE_FORMAT)
    private Date incomeDate;

    /**
     * 收入类型
     */
    private Integer incomeType;

    /**
     * 收入总和
     */
    private Integer incomeSum;

    /**
     * 是否付款：0未支付 1已支付
     */
    private Integer paid;

    /**
     * 创建时间
     */
    private Date createTime;

}
