package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.ProductEnum;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.dao.SpeechDao;
import com.cloud.vaxservice.dto.SpeechQueryParamDTO;
import com.cloud.vaxservice.entity.Speech;
import com.cloud.vaxservice.entity.Subscription;
import com.cloud.vaxservice.service.SpeechService;
import com.cloud.vaxservice.service.SubscriptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 配音服务实现类
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Service
public class SpeechServiceImpl extends ServiceImpl<SpeechDao, Speech> implements SpeechService {

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private VaxConfig vaxConfig;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(Speech entity) {
        super.save(entity);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateById(Speech entity) {
        super.updateById(entity);
        return true;
    }

    @Override
    public PageInfo<Speech> query(SpeechQueryParamDTO paramDTO) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(Speech.USER_ID, paramDTO.getUserId());
        }
        wrapper.orderByDesc(Speech.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Speech getByTaskId(String taskId) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.TASK_ID, taskId);
        return getOne(wrapper, false);
    }

    @Override
    public List<Speech> getByTaskIds(List<String> taskIds) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.in(Speech.TASK_ID, taskIds);
        return list(wrapper);
    }

    @Override
    public int getTodayFreeCount(Long userId) {
        Date beginTime = DateTimeUtils.asDate(LocalDate.now());
        Date endTime = DateTimeUtils.asDate(LocalDate.now().plusDays(1));
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.USER_ID, userId);
        wrapper.lt(Speech.SPEECH_TEXT, 150);
        wrapper.gt(Speech.CREATE_TIME, beginTime);
        wrapper.lt(Speech.CREATE_TIME, endTime);
        wrapper.select(Speech.TASK_ID);
        return list(wrapper).size();
    }

    /**
     * 是否存在正在运行的转录
     *
     * @param userId
     * @return boolean
     */
    @Override
    public boolean existRunning(Long userId) {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.USER_ID, userId);
        wrapper.eq(Speech.TASK_STATUS, TaskStatusEnum.RUNNING.getStatus());
        return list(wrapper).size() > 0;
    }

    @Override
    public List<Speech> getRunnings() {
        QueryWrapper<Speech> wrapper = new QueryWrapper<>();
        wrapper.eq(Speech.TASK_STATUS, TaskStatusEnum.RUNNING.getStatus());
        return list(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateResult(TaskStatusEnum taskStatusEnum, Speech speech) {
        speech.setTaskStatus(taskStatusEnum.getStatus());
        speech.setUpdateTime(new Date());
        updateById(speech);
        if (taskStatusEnum == TaskStatusEnum.SUCCESS) {
            int needTextLen = useTextLen(speech);
            if (needTextLen <= 0) {
                return;
            }
            Subscription subscription = subscriptionService.getSubscription(speech.getUserId(), ProductEnum.TEXT_TO_VOICE.name());
            int remainValue = subscription.getRemainValue() - needTextLen;
            if (remainValue < 0) {
                log.warn("userId={} remainValue={}", speech.getUserId(), remainValue);
            }
            subscription.setRemainValue(remainValue);
            subscription.setUpdateTime(new Date());
            subscriptionService.updateById(subscription);
        }
    }

    private int useTextLen(Speech speech) {
        // 计算需要支付的积分
        int needTextLen = 0;
        int textLen = speech.getSpeechText().length();
        int freeTextLen = vaxConfig.getFreeTextLen();
        if (textLen > freeTextLen) {
            needTextLen = textLen / freeTextLen;
        } else {
            int todayFreeCount = getTodayFreeCount(speech.getUserId());
            if (todayFreeCount > vaxConfig.getFreeLimitCount()) {
                needTextLen = textLen / freeTextLen;
            }
        }
        return needTextLen;
    }
}