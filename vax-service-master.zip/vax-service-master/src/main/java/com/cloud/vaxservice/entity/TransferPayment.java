package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 企业付款单实体类
 *
 * @author feng
 * @since 2022/09/26
 */
@Data
@TableName("t_transfer_payment")
public class TransferPayment implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 订单号
     */
    @TableField("order_no")
    private String orderNo;

    /**
     * 支付渠道：1表示微信，2表示支付宝
     */
    @TableField("pay_channel")
    private Integer payChannel;

    /**
     * 支付金额（单位为分）
     */
    @TableField("pay_money")
    private Integer payMoney;

    /**
     * 支付状态：0表示待付款，1表示付款成功，2表示付款失败
     */
    @TableField("pay_status")
    private Integer payStatus;

    /**
     * 支付备注
     */
    @TableField("pay_remark")
    private String payRemark;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String ORDER_NO = "order_no";
    public static final String PAY_CHANNEL = "pay_channel";
    public static final String PAY_MONEY = "pay_money";
    public static final String PAY_STATUS = "pay_status";
    public static final String PAY_REMARK = "pay_remark";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}
