package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.dto.SpeechQueryParamDTO;
import com.cloud.vaxservice.entity.Speech;

import java.util.List;

/**
 * 配音服务接口
 *
 * @author feng
 * @since 2021-09-02
 */
public interface SpeechService extends IService<Speech> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Speech> query(SpeechQueryParamDTO paramDTO);

    /**
     * 根据任务ID查询
     *
     * @param taskId
     * @return Speech
     */
    Speech getByTaskId(String taskId);

    /**
     * 根据任务ID批量查询
     *
     * @param taskIds
     * @return List<Speech>
     */
    List<Speech> getByTaskIds(List<String> taskIds);

    /**
     * 获取今日免费的次数
     *
     * @param userId
     * @return int
     */
    int getTodayFreeCount(Long userId);

    /**
     * 是否存在正在运行的配音
     *
     * @param userId
     * @return boolean
     */
    boolean existRunning(Long userId);

    /**
     * 获取运行中的配音
     *
     * @return List<Speech>
     */
    List<Speech> getRunnings();

    /**
     * 更新结果
     *
     * @param taskStatusEnum
     * @param speech
     */
    void updateResult(TaskStatusEnum taskStatusEnum, Speech speech);
}