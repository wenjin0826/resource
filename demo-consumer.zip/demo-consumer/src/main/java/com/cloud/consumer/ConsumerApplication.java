package com.cloud.consumer;

import com.cloud.common.annotation.CloudApplication;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;

//@EnableKafka
//@EnableRabbit
@CloudApplication
@MapperScan("com.cloud.consumer.dao")
public class ConsumerApplication {

	public static void main(String[] args) {
		System.setProperty("es.set.netty.runtime.available.processors", "false");
		SpringApplication.run(ConsumerApplication.class, args);
	}

}
