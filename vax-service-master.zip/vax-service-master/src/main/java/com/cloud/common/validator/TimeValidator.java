package com.cloud.common.validator;

import com.cloud.common.util.DateTimeUtils;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * 时间格式校验逻辑
 *
 * @author fengwenjin
 */
public class TimeValidator implements ConstraintValidator<TimeCheck, String> {
    private TimeCheck annotation;

    @Override
    public void initialize(TimeCheck constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isEmpty(value)) {
            return true;
        }
        return DateTimeUtils.checkTimeFormat(value, annotation.format());
    }
}
