package com.cloud.common.limit;

import java.lang.annotation.*;

/**
 * 访问频率限制注解
 *
 * @author fengwenjin
 */
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Limit {
    /**
     * 限制模式：0表示根据IP限制，1表示根据用户ID限制
     */
    int limitMode() default 0;

    /**
     * 限制次数
     */
    int limitCount() default 5;

    /**
     * 持续秒数
     */
    int durationSeconds() default 60;

    /**
     * 超过限制的提示消息
     */
    String message() default "访问频繁请稍后再试";
}
