package com.cloud.common.subscribe;

/**
 * 订阅消息处理者
 */
public interface MessageHandler {
    void handle(ChannelMessage message);
}
