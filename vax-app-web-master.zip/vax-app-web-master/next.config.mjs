/** @type {import('next').NextConfig} */
const nextConfig = {
    output: "standalone",
    typescript: {
        ignoreBuildErrors: true,
    },
    images: {
        unoptimized: true,  // 禁用图片优化
    },
};

export default nextConfig;
