package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 邀请对象
 *
 * @author feng
 * @since 2022/09/24
 */
@Data
public class InviteDTO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 邀请人ID
     */
    private Long inviterId;

    /**
     * 被邀请人ID
     */
    private Long inviteeId;

    /**
     * 被邀请人名称
     */
    private String inviteeName;

    /**
     * 被邀请人头像
     */
    private String inviteeHeadimgUrl;

    /**
     * 创建时间
     */
    private Date createTime;
}
