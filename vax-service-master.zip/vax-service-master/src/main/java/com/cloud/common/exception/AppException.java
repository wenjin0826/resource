package com.cloud.common.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

/**
 * 应用异常，用于业务逻辑处理失败时抛出
 *
 * @author fengwenjin
 */
@Data
public class AppException extends RuntimeException {
    private int errorCode = HttpStatus.EXPECTATION_FAILED.value();
    private String detail;

    public AppException(String message) {
        super(message);
    }

    public AppException(int errorCode) {
        this.errorCode = errorCode;
    }

    public AppException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public AppException(int errorCode, String message, String detail) {
        super(message);
        this.errorCode = errorCode;
        this.detail = detail;
    }
}
