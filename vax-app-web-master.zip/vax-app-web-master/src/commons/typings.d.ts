declare namespace Model {
    type LoginUser = {
        username?: string;
    };
}