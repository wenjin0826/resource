package com.cloud.common.validator;

import com.cloud.common.util.DateTimeUtils;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

/**
 * 日期格式校验注解
 *
 * @author fengwenjin
 */
@Documented
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(DateCheck.List.class)
@Constraint(validatedBy = {DateValidator.class})
public @interface DateCheck {
    String message() default "{*.validation.constraint.DateCheck.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String format() default DateTimeUtils.DATE_FORMAT;

    @Documented
    @Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
        DateCheck[] value();
    }
}
