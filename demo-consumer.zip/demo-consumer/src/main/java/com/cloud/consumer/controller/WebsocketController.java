package com.cloud.consumer.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.consumer.dto.WebsocketMsgDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class WebsocketController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @MessageMapping("/chat")
    public ResultInfo<String> chat(WebsocketMsgDTO messageDTO) {
        log.info("chat msg: {}", messageDTO);
        return ResultInfo.success();
    }

    @PostMapping("/reply")
    public ResultInfo<String> reply(WebsocketMsgDTO msgDTO) {
        log.info("reply msg: {}", msgDTO);
        messagingTemplate.convertAndSend("/" + msgDTO.getReceiverId(), msgDTO);
        return ResultInfo.success();
    }
}
