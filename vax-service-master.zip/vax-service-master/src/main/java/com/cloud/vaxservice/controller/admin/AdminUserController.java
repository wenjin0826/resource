package com.cloud.vaxservice.controller.admin;

import com.cloud.vaxservice.dto.UserDTO;
import com.cloud.vaxservice.dto.UserQueryParamDTO;
import com.cloud.vaxservice.dto.UserUpdateParamDTO;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.UserService;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * 用户接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class AdminUserController {
    @Autowired
    private UserService userService;

    /**
     * 分页查询用户
     *
     * @param paramDTO 参数对象
     * @return ResultInfo
     */
    @PostMapping("/admin/user/query")
    public ResultInfo<PageInfo<UserDTO>> query(@Valid @RequestBody UserQueryParamDTO paramDTO) {
        PageInfo<User> pageInfo = userService.query(paramDTO);
        List<UserDTO> list = ObjectUtils.copy(pageInfo.getRows(), UserDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 更新
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/user/update")
    public ResultInfo<String> update(@Valid @RequestBody UserUpdateParamDTO paramDTO) {
        User user = userService.getById(paramDTO.getId());
        if (user == null) {
            return ResultInfo.failure();
        }
        if (paramDTO.getVip() != null) {
            user.setVip(paramDTO.getVip());
        }
        if (paramDTO.getStatus() != null) {
            user.setStatus(paramDTO.getStatus());
        }
        userService.updateById(user);
        return ResultInfo.success();
    }
}