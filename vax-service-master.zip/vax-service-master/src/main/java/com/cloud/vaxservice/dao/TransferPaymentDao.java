package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.TransferPayment;

/**
 * 企业付款单数据访问
 *
 * @author feng
 * @since 2022/09/26
 */
public interface TransferPaymentDao extends BaseMapper<TransferPayment> {
}
