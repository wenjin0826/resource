package com.cloud.vaxservice.support;

import com.cloud.common.util.JsonUtils;
import com.cloud.common.util.UUIDUtils;
import com.cloud.vaxservice.cache.WechatCache;
import com.cloud.vaxservice.dto.WechatSignDTO;
import com.cloud.vaxservice.dto.WechatUserInfoDTO;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class WechatHelper {
    private static final String WECHAT_API_URL = "https://api.weixin.qq.com";

    @Autowired
    private WechatCache wechatCache;

    @Autowired
    private RestTemplate restTemplate;

    private RestTemplate uploadRestTemplate = new RestTemplate();

    private OkHttpClient okHttpClient;

    public WechatHelper() {
        okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
    }

    /**
     * 获取用户信息（APP端）
     *
     * @param code
     * @param appId
     * @param appSecret
     * @return WechatUserInfoDTO
     */
    public WechatUserInfoDTO getUserInfoForApp(String code, String appId, String appSecret) throws Exception {
        // 查询openId和accessToken
        String apiUrl = WECHAT_API_URL + "/sns/oauth2/access_token?grant_type=authorization_code&appid=" + appId + "&secret=" + appSecret + "&code=" + code;
        String resultText = restTemplate.exchange(apiUrl, HttpMethod.GET, HttpEntity.EMPTY, String.class).getBody();
        Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
        String openId = (String) map.get("openid");
        String accessToken = (String) map.get("access_token");
        // 查询用户信息
        return getUserInfo(accessToken, openId);
    }

    /**
     * 获取用户信息（公众平台）
     *
     * @param code
     * @param appId
     * @param appSecret
     * @return WechatUserInfoDTO
     */
    public WechatUserInfoDTO getUserInfoForMP(String code, String appId, String appSecret) throws Exception {
        String openId = getOpenidForMP(code, appId, appSecret);
        String accessToken = getAccessToken(appId, appSecret);
        // 查询用户信息
        return getUserInfo(accessToken, openId);
    }

    /**
     * 获取openid（小程序端也适用）
     *
     * @param code
     * @return
     */
    public String getOpenidForMP(String code, String appId, String secret) {
        String apiUrl = WECHAT_API_URL + "/sns/jscode2session?grant_type=authorization_code&appid=" + appId + "&secret=" + secret + "&js_code=" + code;
        String resultText = restTemplate.exchange(apiUrl, HttpMethod.GET, HttpEntity.EMPTY, String.class).getBody();
        Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
        return (String) map.get("openid");
    }

    /**
     * 获取签名数据
     *
     * @param url
     * @param appId
     * @param appSecret
     * @return String
     */
    public WechatSignDTO getSignature(String url, String appId, String appSecret) {
        try {
            String ticket = getTicket(appId, appSecret);
            if (ticket != null) {
                WechatSignDTO wechatSignDTO = new WechatSignDTO();
                wechatSignDTO.setAppId(appId);
                wechatSignDTO.setNonceStr(RandomStringUtils.randomAlphanumeric(16));
                wechatSignDTO.setTimestamp(System.currentTimeMillis() / 1000);

                StringBuilder signStr = new StringBuilder();
                signStr.append("jsapi_ticket=").append(ticket);
                signStr.append("&noncestr=").append(wechatSignDTO.getNonceStr());
                signStr.append("&timestamp=").append(wechatSignDTO.getTimestamp());
                signStr.append("&url=").append(url);
                String signature = sign(signStr.toString());

                wechatSignDTO.setSignature(signature);
                return wechatSignDTO;
            }
        } catch (Exception e) {
            log.error("getSignature error", e);
        }
        return null;
    }

    public boolean checkMsgSecurity(String msg, String appId, String appSecret) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, String> body = new HashMap<>();
        body.put("content", msg);

        String apiUrl = WECHAT_API_URL + "/wxa/msg_sec_check?access_token=" + getAccessToken(appId, appSecret);
        String resultText = restTemplate.exchange(apiUrl, HttpMethod.POST, new HttpEntity(body, headers), String.class).getBody();
        Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
        if (map.get("errcode").equals(87014)) {
            return false;
        }
        return true;
    }

    public boolean checkImgSecurity(MultipartFile file, String appId, String appSecret) throws IOException {
        String fileName = file.getOriginalFilename();
        File tmpFile = new File(System.getProperty("java.io.tmpdir") + UUIDUtils.get() + fileName.substring(fileName.lastIndexOf(".")));
        try {
            FileUtils.writeByteArrayToFile(tmpFile, file.getBytes());

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("media", new FileSystemResource(tmpFile));

            String apiUrl = WECHAT_API_URL + "/wxa/img_sec_check?access_token=" + getAccessToken(appId, appSecret);
            String resultText = uploadRestTemplate.exchange(apiUrl, HttpMethod.POST, new HttpEntity(body, headers), String.class).getBody();
            Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
            if (map.get("errcode").equals(87014)) {
                return false;
            }
            return true;
        } finally {
            tmpFile.delete();
        }
    }

    private WechatUserInfoDTO getUserInfo(String accessToken, String openId) throws Exception {
        String apiUrl = WECHAT_API_URL + "/sns/userinfo?access_token=" + accessToken + "&openid=" + openId;
        String resultText = restTemplate.exchange(apiUrl, HttpMethod.GET, HttpEntity.EMPTY, String.class).getBody();
        Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
        String nickName = (String) map.get("nickname");
        if (StringUtils.isNotEmpty(nickName)) {
            nickName = new String(nickName.getBytes("ISO-8859-1"), "UTF-8");
        } else {
            nickName = "";
        }
        String headimgUrl = (String) map.get("headimgurl");
        headimgUrl = headimgUrl == null ? "" : headimgUrl;
        WechatUserInfoDTO wechatUserInfoDTO = new WechatUserInfoDTO();
        wechatUserInfoDTO.setOpenId(openId);
        wechatUserInfoDTO.setNickName(nickName);
        wechatUserInfoDTO.setHeadimgUrl(headimgUrl);
        return wechatUserInfoDTO;
    }

    private String getTicket(String appId, String appSecret) {
        String ticket = wechatCache.getTicket(appId);
        if (StringUtils.isEmpty(ticket)) {
            String accessToken = getAccessToken(appId, appSecret);
            if (StringUtils.isEmpty(accessToken)) {
                return null;
            }
            String apiUrl = WECHAT_API_URL + "/cgi-bin/ticket/getticket?type=jsapi&access_token=" + accessToken;
            String resultText = restTemplate.exchange(apiUrl, HttpMethod.GET, HttpEntity.EMPTY, String.class).getBody();
            log.info("getTicket >>> {}", resultText);
            Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
            ticket = (String) map.get("ticket");
            if (StringUtils.isNotEmpty(ticket)) {
                wechatCache.saveTicket(appId, ticket);
            }
        }
        return ticket;
    }

    private String getAccessToken(String appId, String appSecret) {
        String accessToken = wechatCache.getAccessToken(appId);
        if (StringUtils.isEmpty(accessToken)) {
            String apiUrl = WECHAT_API_URL + "/cgi-bin/token?grant_type=client_credential&appid=" + appId + "&secret=" + appSecret;
            String resultText = restTemplate.exchange(apiUrl, HttpMethod.GET, HttpEntity.EMPTY, String.class).getBody();
            log.info("getAccessToken >>> {}", resultText);
            Map<String, Object> map = JsonUtils.parseObject(resultText, Map.class);
            accessToken = (String) map.get("access_token");
            if (StringUtils.isNotEmpty(accessToken)) {
                wechatCache.saveAccessToken(appId, accessToken);
            }
        }
        return accessToken;
    }

    private String sign(String decript) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        digest.update(decript.getBytes());
        byte byteArray[] = digest.digest();

        StringBuffer hexString = new StringBuffer();
        for (int i = 0; i < byteArray.length; i++) {
            String shaHex = Integer.toHexString(byteArray[i] & 0xFF);
            if (shaHex.length() < 2) {
                hexString.append(0);
            }
            hexString.append(shaHex);
        }
        return hexString.toString();
    }
}
