package com.cloud.vaxservice.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

/**
 * 微信应用内支付请求DTO
 *
 * @author fengwenjin
 * @since 2021/11/22
 */
@Data
public class WxAppPayReqDTO {
    @JsonAlias("appid")
    private String appId;

    @JsonAlias("partnerid")
    private String partnerId;

    @JsonAlias("prepayid")
    private String prepayId;

    @JsonAlias("noncestr")
    private String nonceStr;

    @JsonAlias("timestamp")
    private String timeStamp;

    @JsonAlias("package")
    private String packageValue;

    @JsonAlias("sign")
    private String sign;
}
