package com.cloud.gateway.config;

import com.cloud.gateway.ribbon.RibbonBestRule;
import com.cloud.gateway.ribbon.RibbonServerPing;
import com.netflix.loadbalancer.IPing;
import com.netflix.loadbalancer.IRule;
import org.springframework.cloud.netflix.ribbon.RibbonClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RibbonClients(defaultConfiguration = RibbonConfig.class)
public class RibbonConfig {

    @Bean
    public IRule ribbonBestRule() {
        return new RibbonBestRule();
    }

    @Bean
    public IPing ribbonServerPing(IRule rule) {
        RibbonBestRule ribbonBestRule = (RibbonBestRule) rule;
        return new RibbonServerPing(ribbonBestRule);
    }

}
