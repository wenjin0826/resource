package com.cloud.vaxservice.controller;

import com.cloud.vaxservice.cache.AdvCache;
import com.cloud.vaxservice.config.WeappConfig;
import com.cloud.vaxservice.dto.AdvDTO;
import com.cloud.vaxservice.dto.AdvertiseDTO;
import com.cloud.vaxservice.entity.Advertise;
import com.cloud.vaxservice.service.AdvertiseService;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 广告接口
 *
 * @author feng
 * @since 2022/06/13
 */
@Slf4j
@RestController
public class AdvertiseController {
    @Autowired
    private AdvertiseService advertiseService;

    @Autowired
    private WeappConfig weappConfig;

    @Autowired
    private AdvCache advCache;

    @PostMapping("/advertise/inspireView")
    public ResultInfo<AdvDTO> inspireView() {
        AdvDTO advDTO = new AdvDTO();
        advDTO.setInspireClickEnable(weappConfig.isInspireClickEnable());
        advDTO.setInspireClickPercent(weappConfig.getInspireClickPercent());
        if (SessionContext.getUserId() > 0) {
            int viewCount = advCache.inspireView();
            advDTO.setInspireViewCount(viewCount);
        }
        return ResultInfo.success().setData(advDTO);
    }

    @PostMapping("/advertise/isEnable")
    public ResultInfo<Boolean> isEnable() {
        return ResultInfo.success().setData(weappConfig.isInspireClickEnable());
    }

    @PostMapping("/advertise/view")
    public ResultInfo<AdvertiseDTO> view(Integer id, Integer shareUserId) {
        log.info("AdvertiseView id={} shareUserId={}", id, shareUserId);
        Advertise advertise = advertiseService.getById(id);
        if (advertise != null) {
            advertise.setViewCount(advertise.getViewCount() + 1);
            advertiseService.updateById(advertise);
        }
        return ResultInfo.success().setData(ObjectUtils.copy(advertise, AdvertiseDTO.class));
    }

    @PostMapping("/advertise/list")
    public ResultInfo<List<AdvertiseDTO>> list() {
        List<Advertise> advertiseList = advertiseService.getEnableList();
        List<AdvertiseDTO> list = ObjectUtils.copy(advertiseList, AdvertiseDTO.class);
        list.forEach(advertiseDTO -> advertiseDTO.setContent(null));
        return ResultInfo.success().setData(list);
    }
}