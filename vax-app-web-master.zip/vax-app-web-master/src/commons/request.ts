import axios from "axios";
import {BASE_PATH, getToken, removeLoginUser, removeToken, REQUEST_TIMEOUT} from "@/commons/global";

// 创建 Axios 实例
const BASE_URL = "http://localhost:8000/vax-service";
//const BASE_URL = "https://www.aiaitou.com/vax-service";
const request = axios.create({
    baseURL: BASE_URL,
    timeout: REQUEST_TIMEOUT,
    withCredentials: true,
});

// 创建请求拦截器
request.interceptors.request.use(
    function (config) {
        // 请求执行前执行
        config.headers.set("token", getToken());
        return config;
    },
    function (error) {
        // 处理请求错误
        return Promise.reject(error);
    },
);

// 创建响应拦截器
request.interceptors.response.use(
    // 2xx 响应触发
    function (response) {
        // 处理响应数据
        const {data} = response;
        // 未登录
        if (data.code === 401) {
            removeToken();
            removeLoginUser();
            // 不是登录页面，则跳转到登录页面
            if (!window.location.pathname.includes("/login")) {
                window.location.href = BASE_PATH + '/login';
            }
        } else if (data.code !== 200) {
            return Promise.reject(new Error(data.message));
        }
        return data;
    },
    // 非 2xx 响应触发
    function (error) {
        // 处理响应错误
        return Promise.reject(error);
    },
);

export default request;
