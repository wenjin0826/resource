package com.cloud.vaxservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/08/27
 */
@NoArgsConstructor
@Data
public class WechatWxaGenerateSchemeParamDTO {

    @JsonProperty("jump_wxa")
    private JumpWxaDTO jumpWxa;

    @JsonProperty("is_expire")
    private Boolean isExpire;

    @JsonProperty("expire_type")
    private Integer expireType;

    @JsonProperty("expire_interval")
    private Integer expireInterval;

    @NoArgsConstructor
    @Data
    public static class JumpWxaDTO {
        @JsonProperty("path")
        private String path;

        @JsonProperty("query")
        private String query;
    }
}
