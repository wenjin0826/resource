package com.cloud.vaxservice.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties("alipay")
public class AlipayConfig {
    /**
     * 商户ID
     */
    private String mchId;

    /**
     * 回调通知地址
     */
    private String notifyUrl;
}
