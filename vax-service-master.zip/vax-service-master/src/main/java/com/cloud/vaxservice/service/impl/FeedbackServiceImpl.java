package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.dao.FeedbackDao;
import com.cloud.vaxservice.entity.Feedback;
import com.cloud.vaxservice.service.FeedbackService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * 反馈服务实现类
 *
 * @author feng
 * @since 2021-09-25
 */
@Slf4j
@Service
public class FeedbackServiceImpl extends ServiceImpl<FeedbackDao, Feedback> implements FeedbackService {
    @Override
    public PageInfo<Feedback> query(FeedbackQueryParamDTO paramDTO) {
        QueryWrapper<Feedback> wrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(paramDTO.getTitle())) {
            wrapper.like(Feedback.TITLE, paramDTO.getTitle());
        }
        wrapper.orderByDesc(Feedback.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }
}