package com.cloud.common.validator;

import com.cloud.common.util.DateTimeUtils;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

/**
 * 时间格式校验注解
 *
 * @author fengwenjin
 */
@Documented
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(TimeCheck.List.class)
@Constraint(validatedBy = {TimeValidator.class})
public @interface TimeCheck {
    String message() default "{*.validation.constraint.TimeCheck.message}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String format() default DateTimeUtils.TIME_FORMAT;

    @Documented
    @Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
        TimeCheck[] value();
    }
}
