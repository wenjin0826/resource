package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.vaxservice.entity.TransferPayment;

/**
 * 企业付款单服务接口
 *
 * @author feng
 * @since 2022/09/26
 */
public interface TransferPaymentService extends IService<TransferPayment> {
    /**
     * 企业付款
     *
     * @param payment
     * @param openid
     * @return
     */
    boolean doPay(TransferPayment payment, String openid);
}
