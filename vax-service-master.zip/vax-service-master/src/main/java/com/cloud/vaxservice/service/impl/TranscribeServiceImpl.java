package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.ProductEnum;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.dao.TranscribeDao;
import com.cloud.vaxservice.dto.TranscribeQueryParamDTO;
import com.cloud.vaxservice.entity.Subscription;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.service.SubscriptionService;
import com.cloud.vaxservice.service.TranscribeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 转录任务服务实现类
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Service
public class TranscribeServiceImpl extends ServiceImpl<TranscribeDao, Transcribe> implements TranscribeService {

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private VaxConfig vaxConfig;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(Transcribe entity) {
        super.save(entity);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateById(Transcribe entity) {
        super.updateById(entity);
        return true;
    }

    @Override
    public PageInfo<Transcribe> query(TranscribeQueryParamDTO paramDTO) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(Transcribe.USER_ID, paramDTO.getUserId());
        }
        wrapper.orderByDesc(Transcribe.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Transcribe getByTaskId(String taskId) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.TASK_ID, taskId);
        return getOne(wrapper, false);
    }

    @Override
    public List<Transcribe> getByTaskIds(List<String> taskIds) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.in(Transcribe.TASK_ID, taskIds);
        return list(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateResult(TaskStatusEnum taskStatusEnum, Transcribe transcribe) {
        transcribe.setTaskStatus(taskStatusEnum.getStatus());
        transcribe.setUpdateTime(new Date());
        updateById(transcribe);

        if (taskStatusEnum == TaskStatusEnum.SUCCESS) {
            int needMinutes = useMinutes(transcribe);
            if (needMinutes <= 0) {
                return;
            }
            Subscription subscription = subscriptionService.getSubscription(transcribe.getUserId(), ProductEnum.VOICE_TO_TEXT.name());
            if (subscription != null) {
                int remainValue = subscription.getRemainValue() - needMinutes;
                if (remainValue < 0) {
                    log.warn("userId={} remainValue={}", transcribe.getUserId(), remainValue);
                }
                subscription.setRemainValue(remainValue);
                subscription.setUpdateTime(new Date());
                subscriptionService.updateById(subscription);
            }
        }
    }

    private int useMinutes(Transcribe transcribe) {
        // 计算分钟数
        int timeSeconds = transcribe.getAudioDuration().intValue();
        int totalMinutes = timeSeconds / 60;
        if (timeSeconds % 60 > 0) {
            totalMinutes++;
        }

        // 计算需要分钟
        int needMinutes = 0;
        int freeMinutes = vaxConfig.getFreeMinutes();
        if (totalMinutes > freeMinutes) {
            needMinutes = totalMinutes;
        } else {
            int todayFreeCount = getTodayFreeCount(transcribe.getUserId());
            if (todayFreeCount > vaxConfig.getFreeLimitCount()) {
                needMinutes = totalMinutes;
            }
        }
        return needMinutes;
    }

    @Override
    public void cleanExpired(Date dateTime) {
        QueryWrapper<Transcribe> queryWrapper = new QueryWrapper<>();
        queryWrapper.lt(Transcribe.CREATE_TIME, dateTime);
        remove(queryWrapper);
    }

    @Override
    public int getTodayFreeCount(Long userId) {
        Date beginTime = DateTimeUtils.asDate(LocalDate.now());
        Date endTime = DateTimeUtils.asDate(LocalDate.now().plusDays(1));
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.USER_ID, userId);
        wrapper.lt(Transcribe.AUDIO_DURATION, 300);
        wrapper.gt(Transcribe.CREATE_TIME, beginTime);
        wrapper.lt(Transcribe.CREATE_TIME, endTime);
        wrapper.select(Transcribe.TASK_ID);
        return list(wrapper).size();
    }

    /**
     * 是否存在正在运行的转录
     *
     * @param userId
     * @return boolean
     */
    @Override
    public boolean existRunning(Long userId) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.USER_ID, userId);
        wrapper.eq(Transcribe.TASK_STATUS, TaskStatusEnum.RUNNING.getStatus());
        return list(wrapper).size() > 0;
    }

    @Override
    public List<Transcribe> getRunnings() {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.TASK_STATUS, TaskStatusEnum.RUNNING.getStatus());
        return list(wrapper);
    }
}