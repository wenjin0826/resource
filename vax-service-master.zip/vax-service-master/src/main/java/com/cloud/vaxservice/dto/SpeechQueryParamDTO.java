package com.cloud.vaxservice.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import jakarta.validation.constraints.NotNull;

/**
 * 配音查询参数
 *
 * @author feng
 * @since 2021-11-28
 */
@Data
public class SpeechQueryParamDTO {
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 页码（1~100之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 100, message = "页码（1~100之间）")
    private Integer pageNo;

    /**
     * 分页大小（1~100之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 1, max = 100, message = "分页大小（1~100之间）")
    private Integer pageSize;
}