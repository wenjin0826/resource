"use client";
import {LogoutOutlined} from "@ant-design/icons";
import {ProLayout} from "@ant-design/pro-components";
import {Dropdown, message} from "antd";
import React, {useEffect} from "react";
import {menus} from "@/layouts/FrameLayout/menu";
import {usePathname, useRouter} from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import {BASE_PATH, getLoginUser, removeLoginUser, removeToken} from "@/commons/global";
import LoginPage from "@/app/login/page";
import {getText} from "@/commons/locale";
import {userLogout} from "@/api/appUserController";
import "./index.css";

interface Props {
    children: React.ReactNode;
}

/**
 * 全局框架布局
 * @param children
 * @constructor
 */
export default function FrameLayout({children}: Props) {
    const pathname = usePathname();
    const router = useRouter();

    let LOGIN_NAME = getText("login");
    let loginUser = getLoginUser();
    let username: any = loginUser != null ? loginUser.username : LOGIN_NAME;
    if (username == LOGIN_NAME) {
        children = <LoginPage/>;
    }

    // 注册ServiceWorker
    useEffect(() => {
        registerServiceWorker();
    }, []);

    /**
     * 用户注销
     */
    const logout = async () => {
        try {
            await userLogout();
            removeToken();
            removeLoginUser();
            router.push("/login");
        } catch (e: any) {
            message.error(getText("fail") + ": " + e.message);
        }
    };

    return (
        <div
            id="frameLayout"
            style={{
                overflow: "auto",
            }}
        >
            <ProLayout
                title={`${getText("aiaitou")}`}
                layout="top"
                logo={
                    <Image
                        src={`${BASE_PATH}/image/logo-32.png`}
                        height={32}
                        width={32}
                        style={{padding: '5px'}}
                        alt={`${getText("aiaitou")}`}
                    />
                }
                location={{
                    pathname,
                }}
                avatarProps={{
                    src: `${BASE_PATH}/image/avatar.png`,
                    size: "small",
                    title: username,
                    render: (props, dom) => {
                        if (username == LOGIN_NAME) {
                            return (
                                <div onClick={() => {
                                    router.push("/login");
                                }}>
                                    {dom}
                                </div>
                            );
                        }
                        return (
                            <Dropdown
                                menu={{
                                    items: [
                                        {
                                            key: "logout",
                                            icon: <LogoutOutlined/>,
                                            label: `${getText("logout")}`,
                                        },
                                    ],
                                    onClick: async (event: { key: React.Key }) => {
                                        const {key} = event;
                                        if (key === "logout") {
                                            logout();
                                        }
                                    },
                                }}
                            >
                                {dom}
                            </Dropdown>
                        );
                    },
                }}
                actionsRender={(props) => {
                    return [];
                }}
                headerTitleRender={(logo, title) => {
                    return (
                        <a>
                            {logo}
                            {title}
                        </a>
                    );
                }}
                onMenuHeaderClick={(e) => console.log(e)}
                // 定义有哪些菜单
                menuDataRender={() => {
                    return menus;
                }}
                // 定义了菜单项如何渲染
                menuItemRender={(item, dom) => (
                    <Link href={item.path || "/"} target={item.target}>
                        {dom}
                    </Link>
                )}
            >
                {children}
            </ProLayout>
        </div>
    );
}

function registerServiceWorker() {
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register(BASE_PATH + '/service-worker.js').then((registration) => {
                console.log("service worker register >>> ", registration);
            })
        }
    }
}