package com.cloud.vaxservice.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "weapp")
public class WeappConfig {
    /**
     * 激励广告是否启用
     */
    private boolean inspireClickEnable;

    /**
     * 激励广告点击百分率
     */
    private int inspireClickPercent;
}
