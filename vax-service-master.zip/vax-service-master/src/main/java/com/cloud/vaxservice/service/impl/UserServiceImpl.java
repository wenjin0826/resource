package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.vaxservice.dao.UserDao;
import com.cloud.vaxservice.dto.UserQueryParamDTO;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.UserService;
import com.cloud.common.bean.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 用户服务实现类
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserDao, User> implements UserService {
    @Override
    public PageInfo<User> query(UserQueryParamDTO paramDTO) {
        QueryWrapper<User> wrapper = new QueryWrapper();
        if (paramDTO.getId() != null) {
            wrapper.eq(User.ID, paramDTO.getId());
        }
        wrapper.orderByDesc(User.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public User getByPhone(String phone) {
        QueryWrapper<User> wrapper = new QueryWrapper();
        wrapper.eq(User.PHONE, phone);
        return getOne(wrapper, false);
    }

    @Override
    public User getByWxOpenId(String wxOpenId) {
        QueryWrapper<User> wrapper = new QueryWrapper();
        wrapper.eq(User.WX_OPEN_ID, wxOpenId);
        return getOne(wrapper, false);
    }
}