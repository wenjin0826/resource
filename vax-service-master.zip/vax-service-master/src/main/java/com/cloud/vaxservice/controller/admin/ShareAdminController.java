package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.dto.ShareDTO;
import com.cloud.vaxservice.dto.ShareQueryParamDTO;
import com.cloud.vaxservice.entity.Share;
import com.cloud.vaxservice.service.ShareService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;

/**
 * 分享接口
 *
 * @author feng
 * @since 2022/06/11
 */
@Slf4j
@RestController
public class ShareAdminController {
    @Autowired
    private ShareService shareService;
    
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/share/query")
    public ResultInfo<PageInfo<ShareDTO>> queryShare(@Valid @RequestBody ShareQueryParamDTO paramDTO) {
        PageInfo<Share> pageInfo = shareService.query(paramDTO);
        List<ShareDTO> list = ObjectUtils.copy(pageInfo.getRows(), ShareDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }
}