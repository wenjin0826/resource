package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.util.IDUtils;
import com.cloud.common.util.ObjectUtils;
import com.cloud.common.util.RSAUtils;
import com.cloud.common.util.UUIDUtils;
import com.cloud.vaxservice.cache.TetrisCache;
import com.cloud.vaxservice.config.TetrisConfig;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.RSAKeyEnum;
import com.cloud.vaxservice.constant.TetrisRewardLevelEnum;
import com.cloud.vaxservice.constant.TetrisScoreRankEnum;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.TetrisPlaylog;
import com.cloud.vaxservice.entity.TetrisReward;
import com.cloud.vaxservice.entity.TetrisScore;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.TetrisPlaylogService;
import com.cloud.vaxservice.service.TetrisRewardService;
import com.cloud.vaxservice.service.TetrisScoreService;
import com.cloud.vaxservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 俄罗斯方块接口
 *
 * @author feng
 * @since 2022/09/20
 */
@Slf4j
@RestController
public class TetrisController {
    @Autowired
    private TetrisScoreService tetrisScoreService;

    @Autowired
    private TetrisRewardService tetrisRewardService;

    @Autowired
    private TetrisPlaylogService tetrisPlaylogService;

    @Autowired
    private UserService userService;

    @Autowired
    private TetrisCache tetrisCache;

    @Autowired
    private TetrisConfig tetrisConfig;

    /**
     * 查询排行榜
     *
     * @return ResultInfo 响应结果
     */
    @PostMapping("/tetris/queryRank")
    @Limit(limitMode = 1, limitCount = 10, durationSeconds = 30)
    public ResultInfo<TetrisRankResultDTO> queryRank() {
        // 查询TOP100数据
        List<TetrisScoreDTO> rankList = tetrisCache.getRankTop();
        if (rankList == null) {
            List<TetrisScore> list = tetrisScoreService.queryTop(100);
            List<TetrisScoreDTO> resultList = new ArrayList<>(list.size());
            for (TetrisScore tetrisScore : list) {
                TetrisScoreDTO tetrisScoreDTO = ObjectUtils.copy(tetrisScore, TetrisScoreDTO.class);
                tetrisScoreDTO.setRewardLevelDesc(TetrisRewardLevelEnum.levelOf(tetrisScore.getRewardLevel()).getDescription());
                resultList.add(tetrisScoreDTO);
            }
            tetrisCache.saveRankTop(resultList);
        }

        // 查我的最高分数
        Long userId = SessionContext.getUserId();
        String myRank = "你还没有分数，期待你的挑战";
        TetrisScore tetrisScore = tetrisScoreService.getByUserId(userId);
        if (tetrisScore != null) {
            myRank = "你的最高分数" + tetrisScore.getGameScore() + "，" + getTopRankDesc(rankList, tetrisScore);
        }

        // 返回结果
        TetrisRankResultDTO rankResultDTO = new TetrisRankResultDTO();
        rankResultDTO.setRankList(rankList);
        rankResultDTO.setMyRank(myRank);
        return ResultInfo.success().setData(rankResultDTO);
    }

    private String getTopRankDesc(List<TetrisScoreDTO> rankList, TetrisScore tetrisScore) {
        TetrisScoreRankEnum rankEnum = TetrisScoreRankEnum.scoreOf(tetrisScore.getGameScore());
        if (rankEnum == TetrisScoreRankEnum.TOP_300) {
            int index = 0;
            Long userId = tetrisScore.getUserId();
            for (TetrisScoreDTO scoreDTO : rankList) {
                index++;
                if (scoreDTO.getUserId().equals(userId)) {
                    return "排名" + index;
                }
            }
            return rankEnum.getDescription();
        }
        return rankEnum.getDescription();
    }

    /**
     * 保存分数
     *
     * @param paramDTO 参数
     * @return ResultInfo 响应结果
     */
    @PostMapping("/tetris/saveScore")
    public ResultInfo<TetrisScoreSaveResultDTO> saveScore(@Valid @RequestBody TetrisScoreSaveParamDTO paramDTO) {
        // 检查票据
        Long userId = SessionContext.getUserId();
        String ticket = RSAUtils.decryptByPrivateKey(RSAKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getTicket());
        if (!ticket.equals(tetrisCache.getTicket(userId))) {
            log.warn("ticket={} userId={} not found", ticket, userId);
            return ResultInfo.badRequest();
        }
        tetrisCache.removeTicket(userId);
        tetrisCache.incrTodayPlayCount(userId);

        User user = userService.getById(userId);
        String nickName = user.getNickName();
        String headimgUrl = user.getHeadimgUrl();

        Integer gameScore = paramDTO.getGameScore();
        log.info("tetris saveScore userId={}, score={}", userId, gameScore);

        // 处理分数
        TetrisScoreSaveResultDTO resultDTO = handleScore(userId, nickName, headimgUrl, gameScore);
        return ResultInfo.success().setData(resultDTO);
    }

    private TetrisScoreSaveResultDTO handleScore(Long userId, String nickName, String headimgUrl, Integer gameScore) {
        TetrisRewardLevelEnum rewardLevelEnum = TetrisRewardLevelEnum.LEVEL_0;
        TetrisScore tetrisScore = tetrisScoreService.getByUserId(userId);
        if (tetrisScore == null) {
            rewardLevelEnum = TetrisRewardLevelEnum.scoreOf(gameScore);
            tetrisScore = new TetrisScore();
            tetrisScore.setId(IDUtils.nextId());
            tetrisScore.setUserId(userId);
            tetrisScore.setUserIp(RequestContext.getRequestIP());
            tetrisScore.setNickName(nickName);
            tetrisScore.setHeadimgUrl(headimgUrl);
            tetrisScore.setGameScore(gameScore);
            tetrisScore.setRewardLevel(rewardLevelEnum.getLevel());
            tetrisScoreService.save(tetrisScore);
        } else if (gameScore > tetrisScore.getGameScore()) {
            rewardLevelEnum = TetrisRewardLevelEnum.scoreOf(gameScore);
            tetrisScore.setUserIp(RequestContext.getRequestIP());
            tetrisScore.setNickName(nickName);
            tetrisScore.setHeadimgUrl(headimgUrl);
            tetrisScore.setGameScore(gameScore);
            tetrisScore.setRewardLevel(rewardLevelEnum.getLevel());
            tetrisScore.setUpdateTime(new Date());
            tetrisScoreService.updateById(tetrisScore);
        }

        // 结果信息
        TetrisScoreSaveResultDTO resultDTO = new TetrisScoreSaveResultDTO();
        resultDTO.setRewardLevel(rewardLevelEnum.getLevel());
        resultDTO.setRewardLevelDesc(rewardLevelEnum.getDescription());

        // 添加中奖记录
        if (rewardLevelEnum != TetrisRewardLevelEnum.LEVEL_0) {
            TetrisReward tetrisReward = new TetrisReward();
            tetrisReward.setId(IDUtils.nextId());
            tetrisReward.setUserId(userId);
            tetrisReward.setNickName(nickName);
            tetrisReward.setGameScore(gameScore);
            tetrisReward.setRewardLevel(tetrisScore.getRewardLevel());
            tetrisReward.setCreateTime(new Date());
            tetrisReward.setPaid(Constants.NO);
            tetrisReward.setDescription("IP地址" + RequestContext.getRequestIP());
            tetrisRewardService.save(tetrisReward);

            resultDTO.setScoreDesc("分数" + gameScore + "，恭喜获得" + rewardLevelEnum.getDescription());
        } else {
            resultDTO.setScoreDesc("分数" + gameScore + "，继续加油争取获奖");
        }
        return resultDTO;
    }

    /**
     * 获取我的票据
     *
     * @return ResultInfo 响应结果
     */
    @PostMapping("/tetris/getMyTicket")
    public ResultInfo<String> getMyTicket() {
        String ticket = UUIDUtils.get();
        tetrisCache.saveTicket(SessionContext.getUserId(), ticket);
        return ResultInfo.success().setData(ticket);
    }

    @PostMapping("/tetris/canPlay")
    public ResultInfo<TetrisCanPlayDTO> canPlay() {
        TetrisCanPlayDTO canPlayDTO = new TetrisCanPlayDTO();
        int todayPlayCount = tetrisCache.getTodayPlayCount(SessionContext.getUserId());
        if (todayPlayCount < tetrisConfig.getMaxDayPlayCount()) {
            canPlayDTO.setEnable(true);
        } else {
            canPlayDTO.setEnable(false);
            canPlayDTO.setFailureMsg("每天" + tetrisConfig.getMaxDayPlayCount() + "次已用完，明天可继续");
        }
        return ResultInfo.success().setData(canPlayDTO);
    }

    /**
     * 保存玩游戏日志
     *
     * @return ResultInfo 响应结果
     */
    @PostMapping("/tetris/savePlaylog")
    @Limit(limitMode = 1, limitCount = 3, durationSeconds = 30)
    public ResultInfo<String> savePlaylog(@Valid @RequestBody TetrisPlaylogSaveParamDTO paramDTO) {
        Integer score = paramDTO.getScore();
        Integer level = paramDTO.getLevel();
        Integer speed = paramDTO.getSpeed();
        Long userId = SessionContext.getUserId();
        log.info("tetris savePlaylog userId={}, score={}, level={}, speed={}", userId, score, level, speed);
        if (score > 0 && level > 0) {
            TetrisPlaylog playlog = new TetrisPlaylog();
            playlog.setId(IDUtils.nextId());
            playlog.setUserId(userId);
            playlog.setUserIp(RequestContext.getRequestIP());
            playlog.setGameScore(score);
            playlog.setGameLevel(level);
            playlog.setGameSpeed(speed);
            playlog.setCreateTime(new Date());
            tetrisPlaylogService.insert(playlog);
        }
        return ResultInfo.success();
    }
}
