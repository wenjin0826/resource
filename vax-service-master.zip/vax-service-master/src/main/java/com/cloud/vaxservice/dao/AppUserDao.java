package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.AppUser;

/**
 * APP用户数据访问
 *
 * @author makejava
 * @since 2024/11/16
 */
public interface AppUserDao extends BaseMapper<AppUser> {
}
