package com.cloud.consumer.test.support;

import com.baomidou.mybatisplus.autoconfigure.MybatisPlusAutoConfiguration;
import com.baomidou.mybatisplus.autoconfigure.MybatisPlusProperties;
import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;

@Configuration
@Import(MybatisPlusAutoConfiguration.class)
public class MybatisConfig {
    public static final String DAO_PACKAGE = "com.cloud.consumer.dao";

    @Bean
    @Primary
    public MybatisPlusProperties mybatisPlusProperties() {
        MybatisConfiguration configuration = new MybatisConfiguration();
        configuration.setCacheEnabled(false);
        configuration.setUseActualParamName(false);
        configuration.setMapUnderscoreToCamelCase(true);

        MybatisPlusProperties mybatisPlusProperties = new MybatisPlusProperties();
        mybatisPlusProperties.setConfiguration(configuration);
        return mybatisPlusProperties;
    }

    @Bean
    public PaginationInterceptor paginationInterceptor() {
        return new PaginationInterceptor();
    }

}
