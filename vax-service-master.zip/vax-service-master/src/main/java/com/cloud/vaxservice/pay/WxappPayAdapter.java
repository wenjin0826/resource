package com.cloud.vaxservice.pay;

import com.cloud.vaxservice.config.WechatConfig;
import com.cloud.vaxservice.constant.TradeTypeEnum;
import com.cloud.common.util.JsonUtils;
import com.egzosn.pay.common.bean.CertStoreType;
import com.egzosn.pay.common.bean.PayOrder;
import com.egzosn.pay.common.bean.PayOutMessage;
import com.egzosn.pay.common.bean.TransferOrder;
import com.egzosn.pay.common.bean.result.PayError;
import com.egzosn.pay.common.exception.PayErrorException;
import com.egzosn.pay.common.http.HttpConfigStorage;
import com.egzosn.pay.common.util.sign.SignUtils;
import com.egzosn.pay.wx.api.WxPayConfigStorage;
import com.egzosn.pay.wx.api.WxPayService;
import com.egzosn.pay.wx.bean.WxTransactionType;
import com.egzosn.pay.wx.bean.WxTransferType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Map;

@Slf4j
@Component
public class WxappPayAdapter {

    @Autowired
    private WechatConfig wechatConfig;

    @Autowired
    private WxPayNotifyHandler wxPayBackHandler;

    private WxPayService wxPayService;

    private WxPayService sslWxPayService;

    public String getQrcode(String payTitle, Integer payMoney, String orderNo) {
        BigDecimal money = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100));
        PayOrder payOrder = new PayOrder(payTitle, "", money, orderNo, WxTransactionType.NATIVE);
        return wxPayService.getQrPay(payOrder);
    }

    public String orderInfo(int tradeType, String payTitle, Integer payMoney, String orderNo, String openid) {
        BigDecimal money = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100));
        WxTransactionType transactionType = TradeTypeEnum.of(tradeType) == TradeTypeEnum.APP ? WxTransactionType.APP : WxTransactionType.JSAPI;
        PayOrder payOrder = new PayOrder(payTitle, "", money, orderNo, transactionType);
        payOrder.setOpenid(openid);
        Map<String, Object> resultMap = wxPayService.orderInfo(payOrder);
        return JsonUtils.toJSONString(resultMap);
    }

    public boolean transfer(Integer payMoney, String orderNo, String openid, String remark) {
        BigDecimal money = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100));
        TransferOrder transferOrder = new TransferOrder();
        transferOrder.setTransferType(WxTransferType.TRANSFERS);
        transferOrder.setAmount(money);
        transferOrder.setPayeeAccount(openid);
        transferOrder.setOutNo(orderNo);
        transferOrder.setRemark(remark);
        Map result = sslWxPayService.transfer(transferOrder);
        if (WxPayService.SUCCESS.equals(result.get("return_code"))
                && WxPayService.SUCCESS.equals(result.get("result_code"))){
            return true;
        }
        log.error("wxPay transfer failure, result >>> " + JsonUtils.toJSONString(result));
        return false;
    }

    public PayOutMessage payBack(Map<String, String[]> parameterMap, InputStream input) {
        try {
            return wxPayService.payBack(parameterMap, input);
        } catch (PayErrorException e) {
            PayError payError = e.getPayError();
            if (payError != null && payError.getErrorCode().equals("XML failure")) {
                return null;
            }
            throw e;
        }
    }

    /**
     * 创建微信支付服务
     *
     */
    @PostConstruct
    public void createWxPayService() {
        HttpConfigStorage httpConfigStorage = new HttpConfigStorage();
        httpConfigStorage.setMaxTotal(200);
        httpConfigStorage.setDefaultMaxPerRoute(100);

        wxPayService = new WxPayService(buildConfigStorage());
        wxPayService.setRequestTemplateConfigStorage(httpConfigStorage);
        wxPayService.setPayMessageHandler(wxPayBackHandler);
    }

    /**
     * 创建SSL微信支付服务，付款到零钱使用
     *
     */
    @PostConstruct
    private void createSslWxPayService() {
        HttpConfigStorage sslHttpConfigStorage = new HttpConfigStorage();
        sslHttpConfigStorage.setMaxTotal(50);
        sslHttpConfigStorage.setDefaultMaxPerRoute(10);
        sslHttpConfigStorage.setKeystore(wechatConfig.getPayApiCertPath());
        sslHttpConfigStorage.setStorePassword(wechatConfig.getPayAccountId());
        sslHttpConfigStorage.setCertStoreType(CertStoreType.PATH);

        sslWxPayService = new WxPayService(buildConfigStorage());
        sslWxPayService.setRequestTemplateConfigStorage(sslHttpConfigStorage);
    }

    private WxPayConfigStorage buildConfigStorage() {
        WxPayConfigStorage wxPayConfigStorage = new WxPayConfigStorage();
        wxPayConfigStorage.setAppid(wechatConfig.getAppId());
        wxPayConfigStorage.setMchId(wechatConfig.getPayAccountId());
        wxPayConfigStorage.setSecretKey(wechatConfig.getPayApiSecretKey());
        wxPayConfigStorage.setNotifyUrl(wechatConfig.getPayNotifyUrl());
        wxPayConfigStorage.setSignType(SignUtils.MD5.name());
        wxPayConfigStorage.setInputCharset("utf-8");
        return wxPayConfigStorage;
    }
}
