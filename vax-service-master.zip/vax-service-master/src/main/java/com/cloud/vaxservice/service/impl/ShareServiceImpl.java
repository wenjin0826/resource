package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.ShareDao;
import com.cloud.vaxservice.dto.ShareQueryParamDTO;
import com.cloud.vaxservice.entity.Share;
import com.cloud.vaxservice.service.ShareService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * 分享服务实现类
 *
 * @author feng
 * @since 2022/06/11
 */
@Slf4j
@Service
public class ShareServiceImpl extends ServiceImpl<ShareDao, Share> implements ShareService {
    @Override
    public PageInfo<Share> query(ShareQueryParamDTO paramDTO) {
        QueryWrapper<Share> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(Share.USER_ID, paramDTO.getUserId());
        }
        if (paramDTO.getArticleId() != null) {
            wrapper.eq(Share.ARTICLE_ID, paramDTO.getArticleId());
        }
        wrapper.orderByDesc(Share.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Share get(Long userId, Integer articleId) {
        QueryWrapper<Share> wrapper = new QueryWrapper<>();
        wrapper.eq(Share.USER_ID, userId);
        wrapper.eq(Share.ARTICLE_ID, articleId);
        return getOne(wrapper, false);
    }

    @Override
    public void incrViewCount(Long userId, Integer articleId) {
        Share share = get(userId, articleId);
        if (share != null) {
            share.setViewCount(share.getViewCount() + 1);
            share.setUpdateTime(new Date());
            updateById(share);
        }
    }
}