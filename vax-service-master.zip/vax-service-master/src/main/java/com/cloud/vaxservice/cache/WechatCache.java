package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class WechatCache {
    private static final String TOKEN_KEY_PREFIX = "WechatToken:";
    private static final String TICKET_KEY_PREFIX = "WechatTicket:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public String getAccessToken(String appId) {
        return (String) redisTemplate.opsForValue().get(TOKEN_KEY_PREFIX + appId);
    }

    public void saveAccessToken(String appId, String accessToken) {
        redisTemplate.opsForValue().set(TOKEN_KEY_PREFIX + appId, accessToken, 7000, TimeUnit.SECONDS);
    }

    public String getTicket(String appId) {
        return (String) redisTemplate.opsForValue().get(TICKET_KEY_PREFIX + appId);
    }

    public void saveTicket(String appId, String ticket) {
        redisTemplate.opsForValue().set(TICKET_KEY_PREFIX + appId, ticket, 7000, TimeUnit.SECONDS);
    }
}
