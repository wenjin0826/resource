package com.cloud.vaxservice.job;

import com.cloud.common.support.ListMapper;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.constant.CloudProviderEnum;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.provider.BaiduAsrProvider;
import com.cloud.vaxservice.provider.TencentAsrProvider;
import com.cloud.vaxservice.provider.dto.BaiduTranscribeResultDTO;
import com.cloud.vaxservice.service.TranscribeService;
import com.google.common.collect.Lists;
import com.tencentcloudapi.asr.v20190614.models.TaskStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 转录任务
 *
 * @author fengwenjin
 * @since 2021/11/18
 */
@Slf4j
@Component
public class TranscribeJob {
    @Autowired
    private TranscribeService transcribeService;

    @Autowired
    private TencentAsrProvider tencentAsrProvider;

    @Autowired
    private BaiduAsrProvider baiduAsrProvider;

    @Scheduled(cron = "0 0 3 * * ?")
    public void clean() {
        String lockKey = "Transcribe:CleanJobLock";
        if (!RemoteLock.lock(lockKey, 0)) {
            return;
        }
        try {
            log.info("transcribe clean job begin");
            LocalDate date = LocalDate.now().minusDays(90);
            Date dateTime = DateTimeUtils.asDate(date);
            transcribeService.cleanExpired(dateTime);
            log.info("transcribe clean finish");
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }

    //@Scheduled(fixedDelay = 15000)
    public void fetchResult() {
        String lockKey = "Transcribe:LockFetchResultJob";
        if (!RemoteLock.lock(lockKey, 0)) {
            return;
        }
        try {
            List<Transcribe> transcribeList = transcribeService.getRunnings();
            if (CollectionUtils.isEmpty(transcribeList)) {
                return;
            }
            Map<String, List<Transcribe>> providerMap = transcribeList.stream().collect(Collectors.groupingBy(Transcribe::getProvider));
            for (String key : providerMap.keySet()) {
                List<Transcribe> list = providerMap.get(key);
                if (CloudProviderEnum.TENCENT.name().equals(key)) {
                    handleForTencent(list);
                } else {
                    handleForBaidu(list);
                }
            }
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }

    private void handleForTencent(List<Transcribe> list) {
        // 由于结果已经有通知的方式，这里检查时间为3分钟后才去调用接口
        long durationTime = 3 * 60 * 1000L;
        long currentTime = System.currentTimeMillis();
        for (Transcribe transcribe : list) {
            if (transcribe.getCreateTime().getTime() + durationTime < currentTime) {
                log.warn("tencentAsrProvider queryRecTask taskId={}", transcribe.getTaskId());
                long taskId = Long.parseLong(transcribe.getTaskId());
                TaskStatus taskStatus = tencentAsrProvider.queryRecTask(taskId);
                int status = taskStatus.getStatus().intValue();
                // 处理中
                if (status == 1) {
                    continue;
                }
                if (status == 2) {
                    // 成功
                    String taskResult = tencentAsrProvider.getTaskResult(taskStatus.getResult(), transcribe.getLanguage());
                    transcribe.setTaskResult(taskResult);
                    transcribe.setAudioDuration(taskStatus.getAudioDuration().longValue());
                    transcribe.setTaskStatus(TaskStatusEnum.SUCCESS.getStatus());
                    transcribeService.updateResult(TaskStatusEnum.SUCCESS, transcribe);
                } else {
                    // 失败
                    transcribeService.updateResult(TaskStatusEnum.FAILURE, transcribe);
                }
            }
        }
    }

    private void handleForBaidu(List<Transcribe> list) {
        List<String> taskIdList = list.stream().map(Transcribe::getTaskId).collect(Collectors.toList());
        Lists.partition(taskIdList, 200).forEach(taskIds -> {
            List<BaiduTranscribeResultDTO> resultList = baiduAsrProvider.queryTranscribeTasks(taskIds);
            if (CollectionUtils.isEmpty(resultList)) {
                return;
            }
            List<BaiduTranscribeResultDTO> transcribeResultList = resultList.stream()
                    .filter(resultDTO -> !resultDTO.getTaskStatus().equals(TaskStatusEnum.RUNNING.getStatus()))
                    .collect(Collectors.toList());
            if (CollectionUtils.isEmpty(transcribeResultList)) {
                return;
            }
            ListMapper<BaiduTranscribeResultDTO> transcribeResultListMapper = new ListMapper<>(transcribeResultList, BaiduTranscribeResultDTO::getTaskId);
            List<String> ids = transcribeResultList.stream().map(BaiduTranscribeResultDTO::getTaskId).collect(Collectors.toList());
            List<Transcribe> transcribeList = transcribeService.getByTaskIds(ids);
            for (Transcribe transcribe : transcribeList) {
                BaiduTranscribeResultDTO resultDTO = transcribeResultListMapper.get(transcribe.getTaskId());
                if (resultDTO == null) {
                    continue;
                }
                log.info("taskId={}, taskStatus={}", resultDTO.getTaskId(), resultDTO.getTaskStatus());
                TaskStatusEnum taskStatusEnum = TaskStatusEnum.of(resultDTO.getTaskStatus());

                // 转写成功则获取结果
                BaiduTranscribeResultDTO.TaskResult taskResult = resultDTO.getTaskResult();
                if (taskStatusEnum == TaskStatusEnum.SUCCESS) {
                    StringBuilder resultBuilder = new StringBuilder();
                    for (String result : taskResult.getResult()) {
                        resultBuilder.append(result);
                    }
                    transcribe.setTaskResult(resultBuilder.toString());
                    transcribe.setAudioDuration(taskResult.getAudioDuration());
                }
                // 失败则记录日志
                else {
                    log.warn("audioUrl={} errMsg={}", transcribe.getAudioUrl(), taskResult.getErrMsg());
                }
                transcribeService.updateResult(taskStatusEnum, transcribe);
            }
        });
    }
}
