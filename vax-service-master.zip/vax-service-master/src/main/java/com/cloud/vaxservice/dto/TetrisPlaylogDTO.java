package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 俄罗斯方块游戏日志对象
 *
 * @author feng
 * @since 2022/09/23
 */
@Data
public class TetrisPlaylogDTO {
    /**
     * 主键
     */
    private Long id;
    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户IP
     */
    private String userIp;

    /**
     * 应用类型
     */
    private String appType;

    /**
     * 游戏分数
     */
    private Integer gameScore;

    /**
     * 游戏级别
     */
    private Integer gameLevel;

    /**
     * 游戏速度
     */
    private Integer gameSpeed;

}
