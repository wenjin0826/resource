package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 用户任务新增参数
 *
 * @author feng
 * @since 2021-11-28
 */
@Data
public class UserTaskInsertParamDTO {
    /**
     * 任务ID
     */
    @NotEmpty(message = "任务ID不能为空")
    private String taskId;

    /**
     * 任务类型
     */
    @NotNull(message = "任务类型不能为空")
    private Integer taskType;

    /**
     * 任务状态
     */
    @NotNull(message = "任务状态不能为空")
    private Integer taskStatus;

    /**
     * 任务标题
     */
    @NotEmpty(message = "任务标题不能为空")
    private String taskTitle;

    /**
     * 任务结果
     */
    @NotEmpty(message = "任务结果不能为空")
    private String taskResult;
}