package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Payment;

/**
 * <p>
 * 付款单 Mapper 接口
 * </p>
 *
 * @author feng
 * @since 2021-09-25
 */
public interface PaymentDao extends BaseMapper<Payment> {

}
