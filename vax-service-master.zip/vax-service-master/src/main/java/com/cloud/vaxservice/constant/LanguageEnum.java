package com.cloud.vaxservice.constant;

public enum LanguageEnum {
    CHINESE,
    ENGLISH;
}
