package com.cloud.vaxservice.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import java.util.Date;

/**
 * 文章更新参数
 *
 * @author feng
 * @since 2021-09-24
 */
@Data
public class ArticleUpdateParamDTO {
    /**
     * 主键
     */
    @NotNull(message = "主键不能为空")
    private Integer id;

    /**
     * 置顶
     */
    private Integer top;

    /**
     * 分类
     */
    private Integer type;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 图片地址
     */
    private String imgUrl;

    /**
     * 分享地址：多个逗号分隔
     */
    private String shareUrl;

    /**
     * 打开地址
     */
    private String openUrl;

    /**
     * 打开Appid
     */
    private String openAppid;

    /**
     * 发布日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date publishTime;
}