package com.cloud.vaxservice.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties("wechat")
public class WechatConfig {
    /**
     * 开放平台APPID
     */
    private String appId;

    /**
     * 开放平台密钥
     */
    private String appSecret;

    /**
     * 公众平台APPID
     */
    private String mpAppId;

    /**
     * 公众平台密钥
     */
    private String mpAppSecret;

    /**
     * 小程序APPID
     */
    private String weAppId;

    /**
     * 小程序密钥
     */
    private String weAppSecret;

    /**
     * 微信支付商户配置
     */
    private String payAccountId;
    private String payApiSecretKey;
    private String payApiCertPath;
    private String payNotifyUrl;
}
