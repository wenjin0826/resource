package com.cloud.consumer.akka;

import com.cloud.common.akka.ActorMessage;
import com.cloud.common.akka.BaseActor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class DemoActor extends BaseActor {

    @Override
    public void onMessage(ActorMessage message) {
        log.info("receive message >>> {}", message.getData().toString());
    }
}
