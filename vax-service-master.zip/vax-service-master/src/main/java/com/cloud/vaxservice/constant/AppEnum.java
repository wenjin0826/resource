package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum AppEnum {
    ADMIN_WEB(0, "后台管理"),
    APP_WEB(1, "前台应用");

    @Getter
    private int code;

    @Getter
    private String description;

    AppEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static AppEnum of(int code) {
        for (AppEnum appEnum : values()) {
            if (appEnum.code == code) {
                return appEnum;
            }
        }
        return null;
    }
}
