package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum AsrTencentEngineTypeEnum {
    // 中文
    CHINESE("16k_zh"),
    // 英文
    ENGLISH("16k_en");

    @Getter
    private String code;

    AsrTencentEngineTypeEnum(String code) {
        this.code = code;
    }
}
