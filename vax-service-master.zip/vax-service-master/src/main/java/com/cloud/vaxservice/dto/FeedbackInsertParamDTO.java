package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 反馈新增参数
 *
 * @author feng
 * @since 2021-09-25
 */
@Data
public class FeedbackInsertParamDTO {
    /**
     * 标题
     */
    @NotEmpty(message = "标题不能为空")
    private String title;

    /**
     * 内容
     */
    @NotEmpty(message = "内容不能为空")
    private String content;
}