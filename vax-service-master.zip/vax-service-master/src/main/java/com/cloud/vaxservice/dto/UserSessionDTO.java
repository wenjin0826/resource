package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 用户会话
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class UserSessionDTO {
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 头像地址
     */
    private String headimgUrl;

    /**
     * 密钥
     */
    private String secret;

    /**
     * 分数
     */
    private Integer score;

    /**
     * 访问令牌
     */
    private String accessToken;

    /**
     * 刷新令牌
     */
    private String refreshToken;
}