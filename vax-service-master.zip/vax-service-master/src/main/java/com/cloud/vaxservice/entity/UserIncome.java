package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户收入实体类
 *
 * @author feng
 * @since 2022/10/10
 */
@Data
@TableName("t_user_income")
public class UserIncome implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 收入类型
     */
    @TableField("income_type")
    private Integer incomeType;

    /**
     * 收入总和
     */
    @TableField("income_money")
    private Integer incomeMoney;

    /**
     * 是否付款：0未支付 1已支付
     */
    @TableField("paid")
    private Integer paid;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;


    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String INCOME_TYPE = "income_type";
    public static final String INCOME_MONEY = "income_money";
    public static final String PAID = "paid";
    public static final String CREATE_TIME = "create_time";
}
