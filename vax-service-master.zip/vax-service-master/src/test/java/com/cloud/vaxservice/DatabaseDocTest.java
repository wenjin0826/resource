package com.cloud.vaxservice;

import cn.smallbun.screw.core.Configuration;
import cn.smallbun.screw.core.engine.EngineConfig;
import cn.smallbun.screw.core.engine.EngineFileType;
import cn.smallbun.screw.core.engine.EngineTemplateType;
import cn.smallbun.screw.core.execute.DocumentationExecute;
import cn.smallbun.screw.core.process.ProcessConfig;
import com.cloud.Application;
import com.cloud.common.context.AppContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 数据库文档测试
 *
 * @author fengwenjin
 * @since 2021/11/9
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class DatabaseDocTest {
    @Test
    public void generateDoc() {
        EngineConfig engineConfig = EngineConfig.builder()
                // 生成文件路径
                .fileOutputDir("/Doc")
                // 打开目录
                .openOutputDir(true)
                // 文件类型
                .fileType(EngineFileType.WORD)
                // 模板实现
                .produceType(EngineTemplateType.freemarker).build();

        // 配置设置
        Configuration configuration = Configuration.builder()
                .version("1.0.0")
                .description("数据库文档")
                .dataSource(AppContext.getBean(DataSource.class))
                .engineConfig(engineConfig)
                .produceConfig(getProcessConfig())
                .build();

        // 执行生成
        new DocumentationExecute(configuration).execute();
    }

    private ProcessConfig getProcessConfig() {
        // 忽略表名
        List<String> ignoreTable = Arrays.asList("flyway_schema_history");
        // 忽略表前缀
        List<String> ignorePrefix = Collections.emptyList();
        // 忽略表后缀
        List<String> ignoreSuffix = Collections.emptyList();

        return ProcessConfig.builder()
                // 根据名称生成指定表
                .designatedTableName(new ArrayList<>())
                // 根据表前缀生成
                .designatedTablePrefix(new ArrayList<>())
                // 根据表后缀生成
                .designatedTableSuffix(new ArrayList<>())
                // 忽略表名
                .ignoreTableName(ignoreTable)
                // 忽略表前缀
                .ignoreTablePrefix(ignorePrefix)
                // 忽略表后缀
                .ignoreTableSuffix(ignoreSuffix).build();
    }
}
