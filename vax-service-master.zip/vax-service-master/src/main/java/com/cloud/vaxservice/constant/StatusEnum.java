package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum StatusEnum {
    // 处理中
    RUNNING("Running"),
    // 处理完成
    FINISH("Success"),
    // 处理失败
    FAILURE("Failure");

    @Getter
    private String status;

    StatusEnum(String status) {
        this.status = status;
    }

    public static StatusEnum of(String status) {
        for (StatusEnum statusEnum : values()) {
            if (statusEnum.status.equals(status)) {
                return statusEnum;
            }
        }
        return null;
    }
}
