package com.cloud.vaxservice.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * APP用户更新参数
 *
 * @author makejava
 * @since 2024/11/16
 */
@Data
public class AppUserUpdateParamDTO {
    /**
     * ID
     */
    @NotNull(message = "ID不能为空")
    private Long id;

    /**
     * VIP用户
     */
    private Integer vip;

    /**
     * 积分
     */
    private Integer score;

    /**
     * 状态
     */
    private Integer status;

}
