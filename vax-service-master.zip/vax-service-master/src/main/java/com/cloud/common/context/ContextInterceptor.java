package com.cloud.common.context;

import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.common.annotation.WebInterceptor;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.bean.SessionInfo;
import com.cloud.common.config.WebConfig;
import com.cloud.common.support.SessionCache;
import com.cloud.common.util.JsonUtils;
import com.cloud.common.util.TokenUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Set;

/**
 * 上下文拦截器
 *
 * @author fengwenjin
 */
@Slf4j
@Component
@WebInterceptor(order = Ordered.HIGHEST_PRECEDENCE)
public class ContextInterceptor extends HandlerInterceptorAdapter {
    @Autowired
    private WebConfig webConfig;

    @Autowired
    private SessionCache sessionCache;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        RequestContext.set(request);
        if (HttpMethod.OPTIONS.name().equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String requestURI = request.getRequestURI();
        if (isExcludeURI(requestURI)) {
            return true;
        }

        // 应用版本
        String appVersion = request.getHeader("AppVersion");
        appVersion = appVersion == null ? "" : appVersion;

        if (requestURI.endsWith("/register") || requestURI.endsWith("/login") || requestURI.endsWith("/refreshToken")) {
            log.info("appVersion={}, requestURI={}", appVersion, requestURI);
            return true;
        }

        // 获取token和会话
        SessionInfo sessionInfo = null;
        String token = getToken(request);
        if (StringUtils.isNotEmpty(token)) {
            // 检查token
            TokenUtils.AppUser appUser = TokenUtils.parse(token);
            if (appUser == null) {
                responseResultInfo(response, ResultInfo.failure().setCode(HttpStatus.UNAUTHORIZED.value()));
                return false;
            }
            // 获取会话
            sessionInfo = sessionCache.get(appUser.getAppName(), appUser.getUserId());
            if (sessionInfo == null) {
                responseResultInfo(response, ResultInfo.failure().setCode(HttpStatus.UNAUTHORIZED.value()));
                return false;
            }
            SessionContext.set(sessionInfo);
        } else if (!AppContext.isProdEnv()) {
            // 用于本地非登录态调试
            sessionInfo = SessionInfo.buildDefault();
            SessionContext.set(sessionInfo);
        }
        String userId = sessionInfo == null ? "" : sessionInfo.getUserId();

        // 创建跟踪号
        String traceId = request.getHeader(TraceContext.TRACE_ID);
        if (StringUtils.isEmpty(traceId)) {
            traceId = TraceContext.create(userId);
        }
        TraceContext.set(traceId);
        log.info("appVersion={}, userId={}, requestURI={}", appVersion, userId, requestURI);

        if (sessionInfo == null) {
            responseResultInfo(response, ResultInfo.failure().setCode(HttpStatus.UNAUTHORIZED.value()));
            return false;
        }
        if (!checkAuth(request, sessionInfo)) {
            responseResultInfo(response, ResultInfo.failure().setCode(HttpStatus.FORBIDDEN.value()));
            return false;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) {
        response.setHeader(HttpHeaders.PRAGMA, "no-cache");
        response.setHeader(HttpHeaders.CACHE_CONTROL, "no-cache");
        response.setDateHeader(HttpHeaders.EXPIRES, 0);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        SessionContext.remove();
        RequestContext.remove();
        TraceContext.remove();
    }

    private void responseResultInfo(HttpServletResponse response, ResultInfo resultInfo) throws Exception {
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().println(JsonUtils.toJSONString(resultInfo));
    }

    private boolean isExcludeURI(String requestURI) {
        List<String> excludeURIPrefixs = webConfig.getExcludeURIPrefixs();
        if (excludeURIPrefixs != null) {
            for (String uri : excludeURIPrefixs) {
                if (requestURI.startsWith(uri)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 检查授权资源
     *
     * @param request
     * @return boolean
     */
    private boolean checkAuth(HttpServletRequest request, SessionInfo sessionInfo) {
        String requestURI = request.getRequestURI();
        boolean adminApp = sessionInfo.getAppName().equals(AppEnum.ADMIN.name()) ? true : false;
        if (!adminApp && requestURI.startsWith(request.getContextPath() + "/admin")) {
            return false;
        }
        Set<String> authResources = sessionInfo.getAuthResources();
        if (CollectionUtils.isEmpty(authResources)) {
            return true;
        }
        for (String url : authResources) {
            if (requestURI.startsWith(url)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取令牌
     *
     * @param request
     * @return String
     */
    private String getToken(HttpServletRequest request) {
        String token = request.getHeader(SessionContext.TOKEN);
        token = token == null ? request.getParameter(SessionContext.TOKEN) : token;
        return token;
    }
}
