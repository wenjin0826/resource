package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class ValidCodeCache {

    private static final String STRING_KEY_PREFIX = "ValidCode:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public String getValidCode(String phone) {
        String key = STRING_KEY_PREFIX + phone;
        return (String) redisTemplate.opsForValue().get(key);
    }

    public void saveValidCode(String phone, String validCode) {
        String key = STRING_KEY_PREFIX + phone;
        redisTemplate.opsForValue().set(key, validCode, 10, TimeUnit.MINUTES);
    }
}
