package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.Advertise;

import java.util.List;

/**
 * 广告服务接口
 *
 * @author feng
 * @since 2022/06/13
 */
public interface AdvertiseService extends IService<Advertise> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Advertise> query(AdvertiseQueryParamDTO paramDTO);

    /**
     * 获取可用列表
     *
     * @return
     */
    List<Advertise> getEnableList();
}