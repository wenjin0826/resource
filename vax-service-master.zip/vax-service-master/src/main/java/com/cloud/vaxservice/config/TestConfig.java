package com.cloud.vaxservice.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "test")
public class TestConfig {
    /**
     * 手机号
     */
    private String phone;

    /**
     * 验证码
     */
    private String validCode;
}
