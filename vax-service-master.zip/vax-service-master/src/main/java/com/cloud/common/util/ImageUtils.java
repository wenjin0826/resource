package com.cloud.common.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * 图片工具类
 *
 * @author fengwenjin
 */
public class ImageUtils {
    public static File merge(InputStream bgFile, InputStream addFile, String formatName, int x, int y) throws IOException {
        BufferedImage bgImage = ImageIO.read(bgFile);
        Graphics2D graphics = bgImage.createGraphics();
        graphics.drawImage(ImageIO.read(addFile), x, y, null);

        String targetPath = System.getProperty("java.io.tmpdir") + UUIDUtils.get() + "." + formatName;
        File targetFile = new File(targetPath);
        ImageIO.write(bgImage, formatName, targetFile);
        return targetFile;
    }
}
