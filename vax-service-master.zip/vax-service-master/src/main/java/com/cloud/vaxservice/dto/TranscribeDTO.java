package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 转录结果
 *
 * @author feng
 * @since 2021/9/2
 */
@Data
public class TranscribeDTO {
    private String taskId;
    private String taskStatus;
    private String taskResult;
    private Integer audioDuration;
    private Date updateTime;
}
