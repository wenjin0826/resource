package com.cloud.common.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Component
public class RemoteLock {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private ScheduledExecutorService scheduledExecutorService = new ScheduledThreadPoolExecutor(Runtime.getRuntime().availableProcessors());
    private final long TIMEOUT_MILLIS = 6000L;

    /**
     * 加锁
     *
     * @param key
     * @param waitMillis
     * @return boolean
     */
    public boolean lock(String key, long waitMillis) {
        long beginTime = System.currentTimeMillis();
        while (true) {
            String value = UUID.randomUUID().toString();
            if (redisTemplate.opsForValue().setIfAbsent(key, value, TIMEOUT_MILLIS, TimeUnit.MILLISECONDS)) {
                addSchedule(key, value);
                return true;
            }
            if (System.currentTimeMillis() - beginTime > waitMillis) {
                break;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
        }
        return false;
    }

    /**
     * 解锁
     *
     * @param key
     */
    public void unlock(String key) {
        redisTemplate.delete(key);
    }

    private void addSchedule(String key, String value) {
        scheduledExecutorService.schedule(() -> {
            String cacheValue = (String) redisTemplate.opsForValue().get(key);
            if (cacheValue != null && cacheValue.equals(value)) {
                redisTemplate.expire(key, TIMEOUT_MILLIS, TimeUnit.MILLISECONDS);
                addSchedule(key, value);
            }
        }, TIMEOUT_MILLIS / 6, TimeUnit.MILLISECONDS);
    }

}
