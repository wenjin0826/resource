package com.cloud.common.feign;

import com.alibaba.csp.sentinel.Entry;
import com.alibaba.csp.sentinel.EntryType;
import com.alibaba.csp.sentinel.SphU;
import com.alibaba.csp.sentinel.Tracer;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.context.TraceContext;
import com.cloud.common.context.VersionContext;
import com.cloud.common.mock.HttpMockInterceptor;
import com.cloud.common.ribbon.RibbonBestRule;
import com.cloud.common.rpc.*;
import com.cloud.common.support.BaseInterceptor;
import com.cloud.common.util.JsonUtils;
import com.netflix.loadbalancer.LoadBalancerStats;
import com.netflix.loadbalancer.Server;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.lang.annotation.Annotation;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeoutException;

@Slf4j
@Aspect
@Component
public class FeignInterceptor extends BaseInterceptor implements RequestInterceptor {

    private Set<String> services = new HashSet();

    @Autowired
    private RPCClient rpcClient;

    @Autowired
    private HttpMockInterceptor mockInterceptor;

    @Override
    public void apply(RequestTemplate requestTemplate) {
        if (requestTemplate != null) {
            String traceId = TraceContext.get();
            if (traceId != null) {
                requestTemplate.header(TraceContext.TRACE_ID, traceId);
            }
            Object sessionInfo = SessionContext.get();
            if (sessionInfo != null) {
                requestTemplate.header(SessionContext.SESSION_INFO, JsonUtils.toJSONString(sessionInfo));
            }
            String versionInfo = VersionContext.get();
            if (versionInfo != null) {
                requestTemplate.header(VersionContext.VERSION_INFO, versionInfo);
            }
        }
    }

    @Around("@annotation(FeignInvoke)")
    public Object doFeign(ProceedingJoinPoint point) {
        // 支持mock
        if (mockInterceptor.canMock(point)) {
            return mockInterceptor.invokeMock(point);
        }

        // 获取调用属性
        InvokeAttribute invokeAttribute = getInvokeAttribute(point);
        String resourceName = invokeAttribute.buildResourceName();

        Entry entry = null;
        try {
            // Sentinel检查
            entry = SphU.entry(resourceName, EntryType.OUT);
            if (invokeAttribute.isRpc && services.contains(invokeAttribute.serviceName)) {
                return execute(point, () -> rpcInvoke(point, invokeAttribute));
            }
            // rpc首次调用，也要初始化ribbon相关状态
            services.add(invokeAttribute.serviceName);
            return execute(point, null);
        } catch (Throwable e) {
            if (BlockException.isBlockException(e)) {
                log.warn("{} circuit break", resourceName);
                return new ResultInfo().setCode(HttpStatus.SERVICE_UNAVAILABLE.value());
            } else {
                Tracer.traceEntry(e, entry);
                return new ResultInfo().setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            }
        } finally {
            // Sentinel清理
            if (entry != null) {
                entry.exit();
            }
        }
    }

    /**
     * 获取调用属性
     *
     * @param point
     * @return InvokeAttribute
     */
    private InvokeAttribute getInvokeAttribute(ProceedingJoinPoint point) {
        //获取调用属性
        String requestUri = null;
        FeignInvoke feignInvoke = null;
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        Annotation[] annotations = methodSignature.getMethod().getAnnotations();
        for (Annotation annotation : annotations) {
            if (annotation instanceof FeignInvoke) {
                feignInvoke = (FeignInvoke) annotation;
            } else if (annotation instanceof GetMapping) {
                requestUri = ((GetMapping) annotation).value()[0];
            } else if (annotation instanceof PostMapping) {
                requestUri = ((PostMapping) annotation).value()[0];
            } else if (annotation instanceof PutMapping) {
                requestUri = ((PutMapping) annotation).value()[0];
            } else if (annotation instanceof DeleteMapping) {
                requestUri = ((DeleteMapping) annotation).value()[0];
            } else if (annotation instanceof RequestMapping) {
                requestUri = ((RequestMapping) annotation).value()[0];
            }
        }
        if (requestUri == null) {
            throw new RuntimeException("feign client not found request uri");
        }
        if (feignInvoke == null) {
            throw new RuntimeException("feign client not found @FeignInvoke annotation");
        }
        //本地调试启动时，不注册到注册中心
        boolean isRegisterWithEureka = true;
        String registerWithEureka = System.getenv("eureka.client.register-with-eureka");
        if (registerWithEureka != null && registerWithEureka.equals("false")) {
            isRegisterWithEureka = false;
        }
        boolean isAsync = feignInvoke.async();
        boolean isRpc = isRegisterWithEureka ? feignInvoke.rpc() : false;
        int timeout = feignInvoke.timeout();

        //获取调用服务名
        Class<?> classTarget = point.getTarget().getClass().getInterfaces()[0];
        String serviceName = classTarget.getAnnotation(FeignClient.class).name();
        return new InvokeAttribute(serviceName, requestUri, isAsync, isRpc, timeout);
    }

    /**
     * RPC调用
     *
     * @param point
     * @param invokeAttribute
     * @return Object
     * @throws Exception
     */
    private Object rpcInvoke(ProceedingJoinPoint point, InvokeAttribute invokeAttribute) throws Exception {
        Server server = RibbonBestRule.getInstance(invokeAttribute.serviceName).doChoose(invokeAttribute.serviceName);
        if (server == null) {
            throw new RuntimeException(invokeAttribute.serviceName + " service unavailable");
        }
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        String[] parameterNames = methodSignature.getParameterNames();
        Object[] parameterValues = point.getArgs();
        RPCMessage message = createMessage(invokeAttribute.requestUri, parameterNames, parameterValues);

        ResponseFuture future = new ResponseFuture(message.getSequence(), invokeAttribute.timeout, methodSignature.getMethod().getGenericReturnType());
        ResponseFutureManager.add(future);
        try {
            int port = Integer.parseInt(RPCServer.SERVER_PORT_PREFIX + server.getPort());
            rpcClient.send(server.getHost(), port, message);
            if (invokeAttribute.isAsync) {
                return new ResultInfo().setFuture(future);
            }
            Object result = future.get();
            if (result == null) {
                throw new SocketTimeoutException();
            }
            return result;
        } catch (Throwable e) {
            ResponseFutureManager.remove(future.getSequence());
            if (e instanceof SocketException || e instanceof SocketTimeoutException || e instanceof TimeoutException) {
                LoadBalancerStats loadBalancerStats = RibbonBestRule.getInstance(invokeAttribute.serviceName).getLoadBalancerStats();
                loadBalancerStats.getSingleServerStat(server).incrementSuccessiveConnectionFailureCount();
            }
            throw e;
        }
    }

    /**
     * 创建发生消息
     *
     * @param uri
     * @param parameterNames
     * @param parameterValues
     * @return Message
     */
    private RPCMessage createMessage(String uri, String[] parameterNames, Object[] parameterValues) {
        //请求参数
        HashMap<String, Object> parameterMap = new HashMap<>();
        for (int i = 0; i < parameterNames.length; i++) {
            parameterMap.put(parameterNames[i], parameterValues[i]);
        }

        //请求对象
        Request request = new Request();
        request.setRequestParam(JsonUtils.toJSONString(parameterMap));
        request.setRequestUri(uri);
        request.setTraceId(TraceContext.get());
        request.setVersionInfo(VersionContext.get());
        if (SessionContext.get() != null) {
            request.setSessionInfo(JsonUtils.toJSONString(SessionContext.get()));
        }
        return new RPCMessage(JsonUtils.toJSONString(request));
    }

    /**
     * 调用属性内部类
     */
    static class InvokeAttribute {
        String serviceName;
        String requestUri;
        boolean isAsync;
        boolean isRpc;
        int timeout;

        public InvokeAttribute(String serviceName, String requestUri, boolean isAsync, boolean isRpc, int timeout) {
            this.serviceName = serviceName;
            this.requestUri = requestUri;
            this.isAsync = isAsync;
            this.isRpc = isRpc;
            this.timeout = timeout;
        }

        public String buildResourceName() {
            StringBuilder resourceName = new StringBuilder();
            if (isRpc) {
                resourceName.append("rpc");
            } else {
                resourceName.append("http");
            }
            resourceName.append("://");
            resourceName.append(serviceName);
            resourceName.append(requestUri);
            return resourceName.toString();
        }
    }

}
