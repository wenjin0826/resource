package com.cloud.vaxservice.pay;

import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.constant.PayStatusEnum;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.service.PaymentService;
import com.egzosn.pay.common.api.PayMessageHandler;
import com.egzosn.pay.common.api.PayService;
import com.egzosn.pay.common.bean.PayOutMessage;
import com.egzosn.pay.common.exception.PayErrorException;
import com.egzosn.pay.wx.api.WxPayService;
import com.egzosn.pay.wx.bean.WxPayMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

@Slf4j
@Component
public class WxPayNotifyHandler implements PayMessageHandler<WxPayMessage, PayService> {

    @Autowired
    private PaymentService paymentService;

    /**
     * 微信支付回调的处理
     *
     * @param wxPayMessage 支付消息
     * @param contextMap   上下文
     * @param payService   支付服务
     * @throws PayErrorException 支付错误异常
     */
    @Override
    public PayOutMessage handle(WxPayMessage wxPayMessage, Map<String, Object> contextMap, PayService payService) throws PayErrorException {
        log.info("wxPayNotify >>> {}", JsonUtils.toJSONString(wxPayMessage.getPayMessage()));
        PayOutMessage failureMessage = payService.getPayOutMessage(WxPayService.FAILURE, WxPayService.FAILURE);

        if (!WxPayService.SUCCESS.equals(wxPayMessage.getPayMessage().get(WxPayService.RETURN_CODE))) {
            return failureMessage;
        }
        String orderNo = wxPayMessage.getOutTradeNo();
        if (StringUtils.isEmpty(orderNo)) {
            return failureMessage;
        }

        String lockKey = "Lock:Payment:" + orderNo;
        if (!RemoteLock.lock(lockKey, 0)) {
            return failureMessage;
        }

        try {
            Payment payment = paymentService.getByOrderNo(orderNo);
            if (payment == null || payment.getPayStatus() != PayStatusEnum.UNDO.getCode()) {
                return failureMessage;
            }
            payment.setTradeNo(wxPayMessage.getTransactionId());
            payment.setUpdateTime(new Date());
            if (WxPayService.SUCCESS.equals(wxPayMessage.getResultCode())) {
                payment.setPayStatus(PayStatusEnum.PAID.getCode());
                paymentService.handlePaid(payment);
            } else {
                payment.setPayStatus(PayStatusEnum.PAID_FAIL.getCode());
                paymentService.updateById(payment);
            }
            return payService.getPayOutMessage(WxPayService.SUCCESS, "OK");
        } catch (Exception e) {
            log.error("wxpay notify handle error", e);
        } finally {
            RemoteLock.unlock(lockKey);
        }
        return failureMessage;
    }
}
