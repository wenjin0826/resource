package com.cloud.consumer.support;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class HiveSupport extends JdbcTemplate {

    @Value("${hive.url}")
    private String url;

    @Value("${hive.user}")
    private String user;

    @Value("${hive.password}")
    private String password;

    @Value("${hive.driverClassName}")
    private String driverClassName;

    @PostConstruct
    public void init() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setJdbcUrl(url);
        dataSource.setUsername(user);
        dataSource.setPassword(password);

        setDataSource(dataSource);
        afterPropertiesSet();
    }

}
