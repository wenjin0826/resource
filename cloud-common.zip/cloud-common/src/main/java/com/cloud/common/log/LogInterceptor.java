package com.cloud.common.log;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Aspect
@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
public class LogInterceptor {

    private static final String RESULT_NAME = "result";

    private ExpressionParser parser = new SpelExpressionParser();
    private Map<Method, Expression> expressionMap = new ConcurrentHashMap<>();

    @Around("@annotation(LogInfo)")
    public Object doLog(ProceedingJoinPoint point) throws Throwable {
        //执行业务逻辑
        long beginTime = System.currentTimeMillis();
        Object result = point.proceed();
        long costTime = System.currentTimeMillis() - beginTime;

        try {
            logMessage(point, result, costTime);
        } catch (Exception e) {
            log.error("log message error", e);
        }

        return result;
    }

    /**
     * 输出日志信息
     * @param point
     * @param result
     * @param costTime
     */
    private void logMessage(ProceedingJoinPoint point, Object result, long costTime) {
        //解析参数
        Map<String, Object> parameterMap = new HashMap<>();
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        String[] parameterNames = methodSignature.getParameterNames();
        if (parameterNames != null && parameterNames.length > 0) {
            Object[] parameterValues = point.getArgs();
            for (int i = 0; i < parameterNames.length; i++) {
                parameterMap.put(parameterNames[i], parameterValues[i]);
            }
        }
        parameterMap.put(RESULT_NAME, result);

        //设置EL表达式上下文
        StandardEvaluationContext evalContext = new StandardEvaluationContext();
        evalContext.setVariables(parameterMap);

        //从表达式获取日志输出
        String message = (String) getExpression(point).getValue(evalContext);
        log.info(point.getSignature().toShortString() + " {} ExecuteTime={}", message, costTime);
    }

    /**
     * 获取表达式
     * @param point
     * @return Expression
     */
    private Expression getExpression(ProceedingJoinPoint point) {
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        Method method = methodSignature.getMethod();

        //从缓存获取，没有则生成后放入缓存
        Expression expression = expressionMap.get(method);
        if (expression == null) {
            LogInfo logAnnotation = method.getDeclaredAnnotation(LogInfo.class);
            expression = parser.parseExpression(logAnnotation.value());
            expressionMap.put(method, expression);
        }
        return expression;
    }

}
