package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 分享实体类
 *
 * @author feng
 * @since 2022/06/23
 */
@Data
@TableName("t_share")
public class Share implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 渠道 0未知 1表示微信
     */
    @TableField("channel")
    private Integer channel;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 文章ID
     */
    @TableField("article_id")
    private Integer articleId;

    /**
     * 阅读数
     */
    @TableField("view_count")
    private Integer viewCount;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String CHANNEL = "channel";
    public static final String USER_ID = "user_id";
    public static final String ARTICLE_ID = "article_id";
    public static final String VIEW_COUNT = "view_count";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}