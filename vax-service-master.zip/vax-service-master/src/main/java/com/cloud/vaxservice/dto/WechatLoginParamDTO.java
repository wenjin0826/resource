package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 微信登录参数
 *
 * @author feng
 * @since 2021-11-20
 */
@Data
public class WechatLoginParamDTO {
    /**
     * 微信授权code
     */
    private String code;
}