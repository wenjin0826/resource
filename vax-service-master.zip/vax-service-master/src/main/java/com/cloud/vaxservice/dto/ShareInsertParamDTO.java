package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 分享新增参数
 *
 * @author feng
 * @since 2022/06/11
 */
@Data
public class ShareInsertParamDTO {
    /**
     * 渠道 0未知 1表示微信
     */
    @NotNull(message = "渠道不能为空")
    private Integer channel;

    /**
     * 文章ID
     */
    @NotNull(message = "文章ID不能为空")
    private Integer articleId;

    /**
     * 分享票据
     */
    @NotEmpty(message = "分享票据不能为空")
    private String shareTicket;

}