package com.cloud.consumer.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.consumer.es.IndexProduct;
import com.cloud.consumer.es.bean.ProductSupplier;
import com.cloud.consumer.es.support.AggregationHelper;
import com.cloud.consumer.es.support.AggregationResult;
import com.cloud.consumer.es.support.ElasticsearchSupport;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.BucketOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@Slf4j
@RestController
@RequestMapping("/es")
public class ElasticSearchController {

    @Autowired
    private ElasticsearchSupport elasticsearchSupport;

    @PostMapping("/save")
    public ResultInfo save() {
        IndexProduct indexProduct = new IndexProduct();
        indexProduct.setId(15L);
        indexProduct.setName("小米青春版手机");
        indexProduct.setType("1");
        indexProduct.setColor("blue");
        indexProduct.setAmount(5000);
        indexProduct.setPrice(156900);
        indexProduct.setReleaseTime(System.currentTimeMillis());
        indexProduct.setLabel("phone electronic");

        ProductSupplier productSupplier = new ProductSupplier();
        productSupplier.setName("小米");
        productSupplier.setPhone("077589889968");
        productSupplier.setAddress("广东深圳市数码广场");
        indexProduct.setProductSupplier(productSupplier);

        indexProduct.setDescription("小米热门畅销手机");
        indexProduct.setImgUrl("http://xxxxxxxx");
        elasticsearchSupport.save(indexProduct, IndexProduct.class, elasticsearchSupport.indexYear(new Date()));
        return ResultInfo.success();
    }

    @GetMapping("/search")
    public ResultInfo search() {
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        //queryBuilder.must(QueryBuilders.rangeQuery(Product.PRICE).gte(199900).lte(399900));
        queryBuilder.should(QueryBuilders.termsQuery(IndexProduct.LABEL, "phone", "watch"));

        NativeSearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.boolQuery().filter(queryBuilder))
                .addAggregation(AggregationBuilders.terms("group_by_type").field(IndexProduct.TYPE)
                        .order(BucketOrder.count(true)).size(100)
                        .subAggregation(AggregationBuilders.terms("group_by_color").field(IndexProduct.COLOR))
                        //.subAggregation(AggregationBuilders.max("max_price").field(IndexProduct.PRICE))
                        .subAggregation(AggregationHelper.topHitsBuilder(new String[] {
                                IndexProduct.TYPE,
                                IndexProduct.NAME
                        })))
                .withPageable(AggregationHelper.aggregationPage())
                .build();

        String indexDate = elasticsearchSupport.indexYear(new Date());
        SearchHits<IndexProduct> searchHits = elasticsearchSupport.search(searchQuery, IndexProduct.class, indexDate);
        AggregationResult aggregationResult = AggregationHelper.parse(searchHits.getAggregations().asList());
        return ResultInfo.success();
    }
}
