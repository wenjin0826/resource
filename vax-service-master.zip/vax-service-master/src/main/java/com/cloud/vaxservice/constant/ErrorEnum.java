package com.cloud.vaxservice.constant;

import com.cloud.common.exception.AppException;

/**
 * 错误枚举
 *
 * @author feng
 * @since 2021-09-02
 */
public enum ErrorEnum {
    PROCESSING,
    NO_PERMISSION,
    PASSWORD_ERROR,
    USER_DISABLE,
    USER_NOTEXIST,
    USERNAME_EXIST,
    LOGIN_FAILURE,
    NAME_EXIST,
    VERIFY_CODE_ERROR,
    SEND_SMS_FAILURE,
    TODAY_FREE_LIMITED,
    PHONE_NUMBER_ERROR,
    WECHAT_CODE_ERROR,
    REMAIN_VALUE_NOT_ENOUGH;

    public AppException exception() {
        return new AppException(name());
    }

}
