package com.cloud.gateway.filter;

import com.alibaba.csp.sentinel.AsyncEntry;
import com.alibaba.csp.sentinel.EntryType;
import com.alibaba.csp.sentinel.SphU;
import com.alibaba.csp.sentinel.Tracer;
import com.alibaba.csp.sentinel.context.ContextUtil;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.cloud.gateway.bean.ReleaseInfo;
import com.cloud.gateway.bean.ResultInfo;
import com.cloud.gateway.bean.SessionInfo;
import com.cloud.gateway.cache.FrequencyCache;
import com.cloud.gateway.cache.ReleaseCache;
import com.cloud.gateway.cache.SessionCache;
import com.cloud.gateway.config.AppProperties;
import com.cloud.gateway.ribbon.RibbonBestRule;
import com.cloud.gateway.support.VersionContext;
import com.cloud.gateway.util.JsonUtils;
import com.netflix.loadbalancer.LoadBalancerStats;
import com.netflix.loadbalancer.Server;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.support.ServerWebExchangeUtils;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;

import static org.springframework.cloud.gateway.support.ServerWebExchangeUtils.GATEWAY_REQUEST_URL_ATTR;

@Slf4j
public abstract class BaseFilter implements GlobalFilter, Ordered {

    private static final String TOKEN = "token";
    private static final String VERSION = "version";
    private static final String VERSION_INFO = "VersionInfo";
    private static final String SESSION_INFO = "SessionInfo";

    private static final String ALL = "*";
    private static final String FORBID = "~";
    private static final String WEBSOCKET = "websocket";


    @Autowired
    private AppProperties appProperties;

    @Autowired
    private SessionCache sessionCache;

    @Autowired
    private ReleaseCache releaseCache;

    @Autowired
    private FrequencyCache frequencyCache;

    @Override
    public int getOrder() {
        return 0;
    }

    public abstract ResultInfo preHandle(ServerHttpRequest request);

    public abstract void postHandle(ServerHttpRequest.Builder requestBuilder);

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();

        VersionContext.remove();
        String requestURI = request.getURI().getPath();

        // 静态资源
        if (isStaticResource(requestURI)) {
            VersionContext.set(request.getQueryParams().getFirst(VERSION));
            return chain.filter(exchange);
        }

        // 是否排除资源
        if (isExcludePath(request)) {
            // 检查频率控制
            ResultInfo resultInfo = frequencyCache.checkAccess(requestURI, getRequestIP(request));
            if (!resultInfo.successed()) {
                return responseFailure(response, resultInfo);
            }
            return handleContext(exchange, chain, null);
        }

        // 前置处理
        ResultInfo resultInfo = preHandle(request);
        if (!resultInfo.successed()) {
            return responseFailure(response, resultInfo);
        }

        // 获取令牌
        String token = getToken(request);
        log.debug("requestURI={}, token={}", requestURI, token);
        return sessionCache.get(token).switchIfEmpty(Mono.defer(() -> responseFailure(response, ResultInfo.failure().setCode(HttpStatus.UNAUTHORIZED.value())))).flatMap(data -> {
            SessionInfo sessionInfo = (SessionInfo) data;
            // 检查频率控制
            ResultInfo resInfo = frequencyCache.checkAccess(requestURI, sessionInfo.getUserId());
            if (!resInfo.successed()) {
                return responseFailure(response, resInfo);
            }

            // 检查白名单IP
            Set<String> whitelistIps = sessionInfo.getWhitelistIps();
            if (!whitelistIps.contains(ALL) && !whitelistIps.contains(getRequestIP(request))) {
                return responseFailure(response, ResultInfo.failure().setCode(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE.value()));
            }

            // 检查授权资源
            boolean isAllowed = false;
            Set<String> authResources = sessionInfo.getAuthResources();
            for (String authResource : authResources) {
                if (requestURI.startsWith(FORBID)) {
                    // 禁止访问
                    if (requestURI.startsWith(authResource.substring(1))) {
                        break;
                    }
                } else {
                    // 允许访问
                    if (authResource.equals(ALL) || requestURI.startsWith(authResource)) {
                        isAllowed = true;
                        break;
                    }
                }
            }
            if (!isAllowed) {
                return responseFailure(response, ResultInfo.failure().setCode(HttpStatus.FORBIDDEN.value()));
            }

            return handleContext(exchange, chain, sessionInfo);
        });
    }

    /**
     * 处理上下文
     *
     * @param exchange
     * @param chain
     * @param sessionInfo
     * @return
     */
    private Mono<Void> handleContext(ServerWebExchange exchange, GatewayFilterChain chain, SessionInfo sessionInfo) {
        // 获取版本设置到上下文
        String version = getReleaseVersion(sessionInfo);
        VersionContext.set(version);

        // 支持WebSocket
        if (exchange.getRequest().getURI().getPath().contains(WEBSOCKET)) {
            return chain.filter(exchange);
        }

        // 设置请求头
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpRequest.Builder requestBuilder = request.mutate();
        if (version != null) {
            requestBuilder.header(VERSION_INFO, StringUtils.stripAll(version));
        }
        if (sessionInfo != null) {
            SessionInfo transferSession = new SessionInfo();
            BeanUtils.copyProperties(sessionInfo, transferSession, "whitelistIps", "authResources");
            requestBuilder.header(SESSION_INFO, StringUtils.stripAll(JsonUtils.toJSONString(transferSession)));
            if (sessionInfo.isTraced()) {
                log.info("userId={} requestURI={}", sessionInfo.getUserId(), exchange.getRequest().getURI().getPath());
            }
        }

        // 后置处理
        postHandle(requestBuilder);

        // 处理结束
        ServerWebExchange serverWebExchange = exchange.mutate().request(requestBuilder.build()).build();
        return chainFilter(serverWebExchange, chain, request.getURI().getPath());
    }

    /**
     * 获取请求来源IP
     *
     * @param request
     * @return String
     */
    private String getRequestIP(ServerHttpRequest request) {
        String ip = request.getHeaders().getFirst("X-Forwarded-For");
        if (StringUtils.isEmpty(ip)) {
            ip = request.getHeaders().getFirst("X-Real-IP");
        }
        if (StringUtils.isEmpty(ip)) {
            ip = request.getRemoteAddress().getAddress().getHostAddress();
        } else {
            ip = ip.split(",")[0];
        }
        return ip.trim();
    }

    /**
     * 执行过滤器链
     *
     * @param exchange
     * @param chain
     * @param requestURI
     * @return Mono<Void>
     */
    private Mono<Void> chainFilter(ServerWebExchange exchange, GatewayFilterChain chain, String requestURI) {
        try {
            Route route = exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_ROUTE_ATTR);
            ContextUtil.enter(route.getUri().toString());
            AsyncEntry entry = SphU.asyncEntry(requestURI, EntryType.IN);

            long beginTime = System.currentTimeMillis();
            return chain.filter(exchange).doOnError(error -> {
                Tracer.traceEntry(error, entry);
                handleError(exchange, error);
            }).doFinally(type -> {
                logTime(requestURI, beginTime);
                entry.exit();
            });
        } catch (BlockException ex) {
            log.warn("{} circuit break", requestURI);
            return responseFailure(exchange.getResponse(), ResultInfo.failure().setCode(HttpStatus.SERVICE_UNAVAILABLE.value()));
        }
    }

    private void handleError(ServerWebExchange exchange, Throwable error) {
        boolean isCircuitBreak = false;
        if (error instanceof ResponseStatusException && ((ResponseStatusException) error).getStatus() == HttpStatus.GATEWAY_TIMEOUT) {
            isCircuitBreak = true;
        }
        if (error instanceof SocketException || error instanceof SocketTimeoutException) {
            isCircuitBreak = true;
        }
        if (isCircuitBreak) {
            Route route = exchange.getAttribute(ServerWebExchangeUtils.GATEWAY_ROUTE_ATTR);
            if (!route.getUri().getScheme().equals("lb")) {
                return;
            }
            URI url = exchange.getAttribute(GATEWAY_REQUEST_URL_ATTR);
            Server server = new Server(url.getScheme(), url.getHost(), url.getPort());

            String serviceName =  route.getUri().getHost();
            LoadBalancerStats loadBalancerStats = RibbonBestRule.getInstance(serviceName).getLoadBalancerStats();
            loadBalancerStats.getSingleServerStat(server).incrementSuccessiveConnectionFailureCount();
        }
    }

    private void logTime(String requestURI, long beginTime) {
        long costTime = System.currentTimeMillis() - beginTime;
        if (costTime >= 3000) {
            log.warn("{} ExecuteBlocking={}", requestURI, costTime);
        } else if (costTime >= 500) {
            log.info("{} ExecuteSlowness={}", requestURI, costTime);
        }

        if (log.isDebugEnabled()) {
            log.debug("{} ExecuteTime={}", requestURI, costTime);
        }
    }

    /**
     * 输出响应信息
     *
     * @param response
     * @param resultInfo
     */
    private Mono<Void> responseFailure(ServerHttpResponse response, ResultInfo resultInfo) {
        response.getHeaders().set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
        byte[] bytes = JsonUtils.toJSONString(resultInfo).getBytes(StandardCharsets.UTF_8);
        DataBuffer buffer = response.bufferFactory().wrap(bytes);
        return response.writeWith(Flux.just(buffer));
    }

    /**
     * 是否静态资源
     *
     * @param requestURI
     * @return boolean
     */
    private boolean isStaticResource(String requestURI) {
        if (requestURI.contains(".")) {
            return true;
        }
        return false;
    }

    /**
     * 是否排除校验路径
     *
     * @param request
     * @return boolean
     */
    private boolean isExcludePath(ServerHttpRequest request) {
        String requestURI = request.getURI().getPath();
        if (requestURI.endsWith("register") || requestURI.endsWith("login")) {
            return true;
        }
        List<String> excludePaths = appProperties.getExcludePaths();
        if (excludePaths != null) {
            for (String path : excludePaths) {
                if (requestURI.startsWith(path)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 获取发布版本
     *
     * @param sessionInfo
     * @return String
     */
    private String getReleaseVersion(SessionInfo sessionInfo) {
        List<ReleaseInfo> list = releaseCache.getReleases();
        for (ReleaseInfo releaseInfo : list) {
            String userId = releaseInfo.getUserId();
            String userArea = releaseInfo.getUserArea();
            if (userId.equals(ALL) || userArea.equals(ALL)) {
                return releaseInfo.getVersion();
            }
            if (sessionInfo != null) {
                if (userId.contains(sessionInfo.getUserId())) {
                    return releaseInfo.getVersion();
                }
                if (StringUtils.isNotEmpty(sessionInfo.getUserArea()) && userArea.contains(sessionInfo.getUserArea())) {
                    return releaseInfo.getVersion();
                }
            }
        }
        return null;
    }

    /**
     * 获取令牌
     *
     * @param request
     * @return String
     */
    private String getToken(ServerHttpRequest request) {
        String token = request.getQueryParams().getFirst(TOKEN);
        token = token == null ? request.getHeaders().getFirst(TOKEN) : token;
        if (token == null) {
            HttpCookie cookie = request.getCookies().getFirst(TOKEN);
            if (cookie != null) {
                token = cookie.getValue();
            }
        }
        return token;
    }

}
