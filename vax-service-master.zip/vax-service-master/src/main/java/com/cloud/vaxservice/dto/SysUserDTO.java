package com.cloud.vaxservice.dto;

import java.util.Date;
import lombok.Data;

/**
 * 管理员对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class SysUserDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 用户名
     */
    private String username;

    /**
     * 昵称
     */
    private String nickname;

    /**
     * 密码
     */
    private String password;

    /**
     * 是否可用
     */
    private Integer enabled;

    /**
     * 角色
     */
    private String role;

    /**
     * 登录IP
     */
    private String loginIp;

    /**
     * 登录时间
     */
    private Date loginTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
