package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 订阅实体类
 *
 * @author makejava
 * @since 2024/11/26
 */
@Data
@TableName("t_subscription")
public class Subscription implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 产品
     */
    @TableField("product")
    private String product;

    /**
     * 剩余值
     */
    @TableField("remain_value")
    private Integer remainValue;

    /**
     * 开始时间
     */
    @TableField("begin_time")
    private Date beginTime;

    /**
     * 结束时间
     */
    @TableField("end_time")
    private Date endTime;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String PRODUCT = "product";
    public static final String REMAIN_VALUE = "remain_value";
    public static final String BEGIN_TIME = "begin_time";
    public static final String END_TIME = "end_time";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}
