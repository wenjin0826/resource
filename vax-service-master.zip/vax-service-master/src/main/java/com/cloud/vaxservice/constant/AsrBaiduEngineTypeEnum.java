package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum AsrBaiduEngineTypeEnum {
    // 中文 (1134是8k采样率)
    ZH_CN(1134, 8000),
    // 英文
    EN_US(1737, 16000);

    @Getter
    private int pid;

    @Getter
    private int rate;

    AsrBaiduEngineTypeEnum(int pid, int rate) {
        this.pid = pid;
        this.rate = rate;
    }
}
