package com.cloud.common.akka;

import akka.actor.Actor;
import akka.actor.IndirectActorProducer;
import com.cloud.common.context.AppContext;

public class ActorProducer implements IndirectActorProducer {

    private Class clazz;

    public ActorProducer(Class clazz) {
        this.clazz = clazz;
    }

    @Override
    public Actor produce() {
        return (Actor) AppContext.getBean(clazz);
    }

    @Override
    public Class<? extends Actor> actorClass() {
        return clazz;
    }
}
