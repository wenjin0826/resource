package com.cloud.vaxservice.pay;

import com.cloud.vaxservice.config.AlipayConfig;
import com.yungouos.pay.alipay.AliPay;
import com.yungouos.pay.entity.AliPayH5Biz;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Slf4j
@Component
public class AliPayAdapter {
    private static final String APP_PAY_KEY = "8AC51223C6864BA4B1616B15099FA89B";

    @Autowired
    private AlipayConfig alipayConfig;

    public String appPay(String orderNo, Integer payMoney, String payBody) {
        String totalFee = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100)).toString();
        String resultText = AliPay.appPay(orderNo, totalFee, alipayConfig.getMchId(), payBody, null, null,
                alipayConfig.getNotifyUrl(), null, null, null, null, APP_PAY_KEY);
        log.info("app aliPay result >>> {}", resultText);
        return resultText;
    }

    public String h5Pay(String orderNo, Integer payMoney, String payBody) {
        String totalFee = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100)).toString();
        AliPayH5Biz aliPayH5Biz = AliPay.h5Pay(orderNo, totalFee, alipayConfig.getMchId(), payBody, null, null,
                alipayConfig.getNotifyUrl(), null, null, null, null, null, APP_PAY_KEY);
        log.info("h5 aliPay result >>> {}", aliPayH5Biz);
        return aliPayH5Biz.getUrl();
    }
}
