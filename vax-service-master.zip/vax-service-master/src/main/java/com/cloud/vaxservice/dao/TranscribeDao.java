package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Transcribe;

/**
 * 转录任务数据访问
 *
 * @author feng
 * @since 2021-09-02
 */
public interface TranscribeDao extends BaseMapper<Transcribe> {
}