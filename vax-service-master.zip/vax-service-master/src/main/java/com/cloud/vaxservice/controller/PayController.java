package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.PayChannelEnum;
import com.cloud.vaxservice.constant.PayStatusEnum;
import com.cloud.vaxservice.constant.TradeTypeEnum;
import com.cloud.vaxservice.dto.RechargeDTO;
import com.cloud.vaxservice.dto.RechargeParamDTO;
import com.cloud.vaxservice.dto.YgosPayNotifyDTO;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.adapter.AliPayAdapter;
import com.cloud.vaxservice.service.PaymentService;
import com.cloud.vaxservice.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.Writer;
import java.util.Date;

/**
 * Alipay支付接口
 */
@Slf4j
@RestController
public class PayController {
    @Autowired
    private UserService userService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private AliPayAdapter aliPayAdapter;

    /**
     * 支付充值
     *
     * @param paramDTO 参数
     * @return ResultInfo<RechargeDTO>
     */
    @PostMapping("/pay/recharge")
    public ResultInfo<RechargeDTO> recharge(@Valid @RequestBody RechargeParamDTO paramDTO) {
        // 检查参数
        TradeTypeEnum tradeType = TradeTypeEnum.of(paramDTO.getTradeType());
        PayChannelEnum payChannel = PayChannelEnum.of(paramDTO.getPayChannel());
        if (paramDTO.getMoney().equals(0) || tradeType == null || payChannel != PayChannelEnum.ALI_PAY) {
            return ResultInfo.badRequest();
        }

        // 创建支付单
        User user = userService.getById(SessionContext.getUserId());
        Payment payment = new Payment();
        payment.setUserId(user.getId());
        payment.setOrderNo(DateTimeUtils.timeSequence());
        payment.setTradeType(tradeType.getCode());
        payment.setPayChannel(payChannel.getCode());
        payment.setPayStatus(PayStatusEnum.UNDO.getCode());
        payment.setPayMoney(paramDTO.getMoney());
        payment.setPayTitle(payChannel.getDescription());
        paymentService.save(payment);

        // 结果对象
        RechargeDTO rechargeDTO = new RechargeDTO();
        rechargeDTO.setPaymentId(payment.getId());

        String aliPayData = null;
        if (tradeType == TradeTypeEnum.APP) {
            aliPayData = aliPayAdapter.appPay(payment.getOrderNo(), payment.getPayMoney(), paramDTO.getDescription());
        } else if (tradeType == TradeTypeEnum.H5) {
            aliPayData = aliPayAdapter.h5Pay(payment.getOrderNo(), paramDTO.getMoney(), paramDTO.getDescription());
        }
        rechargeDTO.setAliPayData(aliPayData);
        return ResultInfo.success().setData(rechargeDTO);
    }

    /**
     * 获取充值状态
     *
     * @param paymentId
     * @return
     */
    @PostMapping("/pay/getStatus")
    public ResultInfo<Integer> getStatus(Integer paymentId) {
        if (paymentId == null) {
            return ResultInfo.badRequest();
        }
        Integer status = paymentService.getStatus(paymentId);
        return ResultInfo.success().setData(status);
    }

    /**
     * 支付宝回调通知
     *
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/pay/alipayNotify")
    public void alipayNotify(HttpServletRequest request, HttpServletResponse response) {
        YgosPayNotifyDTO notifyDTO = new YgosPayNotifyDTO();
        notifyDTO.setCode(request.getParameter("code"));
        notifyDTO.setMchId(request.getParameter("mchId"));
        notifyDTO.setOutTradeNo(request.getParameter("outTradeNo"));
        notifyDTO.setOrderNo(request.getParameter("orderNo"));
        notifyDTO.setPayNo(request.getParameter("payNo"));
        log.info("alipayNotify >>> {}", JsonUtils.toJSONString(notifyDTO));

        String result = "FAILURE";
        String orderNo = notifyDTO.getOutTradeNo();
        if (StringUtils.isEmpty(orderNo)) {
            writeResult(response, result);
            return;
        }

        String lockKey = "Lock:Payment:" + orderNo;
        if (!RemoteLock.lock(lockKey, 0)) {
            writeResult(response, result);
            return;
        }

        try {
            Payment payment = paymentService.getByOrderNo(orderNo);
            if (payment == null || payment.getPayStatus() != PayStatusEnum.UNDO.getCode()) {
                writeResult(response, result);
                return;
            }
            payment.setTradeNo(notifyDTO.getPayNo());
            payment.setUpdateTime(new Date());
            if (notifyDTO.getCode().equals(String.valueOf(Constants.OK))) {
                payment.setPayStatus(PayStatusEnum.PAID.getCode());
                paymentService.handlePaid(payment);
            } else {
                payment.setPayStatus(PayStatusEnum.PAID_FAIL.getCode());
                paymentService.updateById(payment);
            }
            result = "SUCCESS";
        } catch (Exception e) {
            log.error("alipay notify handle error", e);
        } finally {
            RemoteLock.unlock(lockKey);
        }
        writeResult(response, result);
    }

    private void writeResult(HttpServletResponse response, String result) {
        try {
            Writer writer = response.getWriter();
            writer.write(result);
            writer.flush();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
