package com.cloud.vaxservice.adapter;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.egzosn.pay.paypal.api.PayPalConfigStorage;
import com.egzosn.pay.paypal.v2.api.PayPalPayService;
import com.egzosn.pay.paypal.v2.bean.PayPalOrder;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Slf4j
@Component
public class PayPalAdapter {
    private PayPalPayService payService;

    @PostConstruct
    public void init() {
        PayPalConfigStorage storage = new PayPalConfigStorage();
        storage.setClientID("ARs06t7P5Y7S9GqP5pqXfnoKRhh5wiV3yZocmVVr6woa9w79jEpeH70UfPYyDiNmbWaOxJinSlU6Vmnh");
        storage.setClientSecret("EJ_6jUTx2txieAe65Nenwv1hbO4bJVXTNym4l09_PZSNB36I6RrlyL7z8M0h9OZwbSVeRmldVo2fpaJF");
        storage.setTest(true);
        //发起付款后的页面转跳地址
        storage.setReturnUrl("http://www.egzosn.com/payPal/payBack.json");
        // 注意：这里不是异步回调的通知 IPN 地址设置的路径：https://developer.paypal.com/developer/ipnSimulator/
        //取消按钮转跳地址,
        storage.setCancelUrl("http://www.egzosn.com/pay/cancel");
        payService = new PayPalPayService(storage);
    }

    public String h5Pay(String orderNo, BigDecimal payMoney, String brandName, String payBody) {
        // 及时收款
        PayPalOrder order = new PayPalOrder();
        order.setPrice(payMoney);
        order.setCustomId(orderNo);
        order.setBrandName(brandName);
        order.setDescription(payBody);
        order.setReturnUrl("https://www.daway.net/vax-admin-web?status=success");
        order.setCancelUrl("https://www.daway.net/vax-admin-web?status=cancel");
        String toPayResult = payService.toPay(order);
        String result = Jsoup.parse(toPayResult).select("script").get(0).html();
        if (result.contains("https")) {
            result = result.substring(result.indexOf("https")).replace("\"", "");
        } else {
            result = "";
        }
        return result;
    }

    public String ordersCapture(String tradeNo) {
        JSONObject ordersCaptureInfo = (JSONObject) payService.ordersCapture(tradeNo);
        JSONArray purchaseUnits = ordersCaptureInfo.getJSONArray("purchase_units");
        if (purchaseUnits != null) {
            return purchaseUnits.getJSONObject(0).getJSONObject("payments").getJSONArray("captures").getJSONObject(0).getString("id");
        }
        return null;
    }

}
