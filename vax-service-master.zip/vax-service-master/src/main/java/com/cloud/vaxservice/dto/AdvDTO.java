package com.cloud.vaxservice.dto;

import lombok.Data;

@Data
public class AdvDTO {
    /**
     * 激励广告点击是否启用
     */
    private boolean inspireClickEnable;

    /**
     * 激励广告点击百分率
     */
    private int inspireClickPercent;

    /**
     * 激励广告查看数
     */
    private int inspireViewCount;
}
