package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.vaxservice.dao.TetrisPlaylogDao;
import com.cloud.vaxservice.dto.TetrisPlaylogQueryParamDTO;
import com.cloud.vaxservice.entity.TetrisPlaylog;
import com.cloud.vaxservice.service.TetrisPlaylogService;
import com.cloud.common.bean.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * 俄罗斯方块游戏日志服务实现类
 *
 * @author feng
 * @since 2022/09/23
 */
@Slf4j
@Service
public class TetrisPlaylogServiceImpl extends ServiceImpl<TetrisPlaylogDao, TetrisPlaylog> implements TetrisPlaylogService {
    @Override
    public PageInfo<TetrisPlaylog> query(TetrisPlaylogQueryParamDTO paramDTO) {
        QueryWrapper<TetrisPlaylog> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.likeLeft(TetrisPlaylog.USER_ID, paramDTO.getUserId());
        }
        wrapper.orderByDesc(TetrisPlaylog.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Async
    @Override
    public void insert(TetrisPlaylog entity) {
        super.save(entity);
    }
}
