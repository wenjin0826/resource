package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.cache.UserReadCache;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.dto.ArticleDTO;
import com.cloud.vaxservice.dto.ArticleQueryParamDTO;
import com.cloud.vaxservice.entity.Article;
import com.cloud.vaxservice.service.ArticleService;
import com.cloud.vaxservice.service.ShareService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 文章接口
 *
 * @author feng
 * @since 2021-09-24
 */
@Slf4j
@RestController
public class ArticleController {
    @Autowired
    private ArticleService articleService;

    @Autowired
    private ShareService shareService;

    @Autowired
    private UserReadCache userReadCache;

    /**
     * 根据ID查询
     *
     * @param id 文章ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/article/get")
    public ResultInfo<ArticleDTO> getArticle(Integer id) {
        Article article = articleService.getById(id);
        if (article == null) {
            return ResultInfo.success().setData(null);
        }
        ArticleDTO articleDTO = ObjectUtils.copy(article, ArticleDTO.class);
        return ResultInfo.success().setData(articleDTO);
    }

    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/article/query")
    public ResultInfo<PageInfo<ArticleDTO>> queryArticle(@Valid @RequestBody ArticleQueryParamDTO paramDTO) {
        paramDTO.setStatus(Constants.OK);
        PageInfo<Article> pageInfo = articleService.query(paramDTO);

        List<ArticleDTO> list = new ArrayList<>(pageInfo.getRows().size());
        for (Article article : pageInfo.getRows()) {
            article.setContent(null);
            ArticleDTO articleDTO = ObjectUtils.copy(article, ArticleDTO.class);
            list.add(articleDTO);
        }
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 查看文章
     *
     * @param id          文章ID
     * @param shareUserId 分享用户ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/article/view")
    public ResultInfo<ArticleDTO> viewArticle(Integer id, Long shareUserId) {
        Article article = articleService.getById(id);
        if (article == null) {
            return ResultInfo.success().setData(null);
        }
        String viewKey = id + "@" + RequestContext.getRequestIP() + "@" + Math.abs(RequestContext.getUserAgent().hashCode());
        if (userReadCache.add(viewKey)) {
            article.setViewCount(article.getViewCount() + 1);
            article.setUpdateTime(new Date());
            articleService.updateById(article);
            if (shareUserId != null) {
                shareService.incrViewCount(shareUserId, id);
            }
        }
        log.info("ArticleView id={} shareUserId={}", id, shareUserId);
        return ResultInfo.success().setData(ObjectUtils.copy(article, ArticleDTO.class));
    }
}