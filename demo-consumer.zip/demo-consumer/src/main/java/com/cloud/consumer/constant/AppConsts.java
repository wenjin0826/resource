package com.cloud.consumer.constant;

public class AppConsts {

    public static final String OSS_FILEPATH = "demo/";

}
