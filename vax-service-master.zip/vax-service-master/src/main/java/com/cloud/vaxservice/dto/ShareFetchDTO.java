package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * 分享获取
 *
 * @author fengwenjin
 * @since 2022/6/14
 */
@Data
public class ShareFetchDTO {
    private String shareUrl;
    private String shareTip;
    private String shareTicket;
    private String description;
    private ArticleDTO article;
}
