package com.cloud.common.validator;

import org.apache.commons.lang3.ObjectUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * 枚举类型校验逻辑
 *
 * @author fengwenjin
 */
public class EnumValidator implements ConstraintValidator<EnumCheck, Object> {
    private EnumCheck annotation;

    @Override
    public void initialize(EnumCheck constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (ObjectUtils.isEmpty(value)) {
            return true;
        }
        String[] values = annotation.values().split(",");
        for (String enumValue : values) {
            if (enumValue.equals(value.toString())) {
                return true;
            }
        }
        return false;
    }
}
