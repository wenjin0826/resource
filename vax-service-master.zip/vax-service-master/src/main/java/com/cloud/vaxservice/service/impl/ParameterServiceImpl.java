package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.dao.ParameterDao;
import com.cloud.vaxservice.entity.Parameter;
import com.cloud.vaxservice.service.ParameterService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * 参数服务实现类
 *
 * @author feng
 * @since 2024/03/14
 */
@Slf4j
@Service
public class ParameterServiceImpl extends ServiceImpl<ParameterDao, Parameter> implements ParameterService {
    @Override
    public PageInfo<Parameter> query(ParameterQueryParamDTO paramDTO) {
        QueryWrapper<Parameter> wrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(paramDTO.getParamKey())) {
            wrapper.like(Parameter.PARAM_KEY, paramDTO.getParamKey());
        }
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Parameter getByKey(String key) {
        QueryWrapper<Parameter> wrapper = new QueryWrapper<>();
        wrapper.eq(Parameter.PARAM_KEY, key);
        return getOne(wrapper, false);
    }
}
