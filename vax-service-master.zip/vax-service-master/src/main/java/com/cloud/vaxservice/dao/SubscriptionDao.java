package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Subscription;

/**
 * 订阅数据访问
 *
 * @author makejava
 * @since 2024/11/26
 */
public interface SubscriptionDao extends BaseMapper<Subscription> {
}
