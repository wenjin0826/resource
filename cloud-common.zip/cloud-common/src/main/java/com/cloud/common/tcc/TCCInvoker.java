package com.cloud.common.tcc;

import com.cloud.common.bean.ResultInfo;

public interface TCCInvoker {
    ResultInfo execute(TCCRequest request);
}
