package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class ShareCache {
    private static final String TICKET_KEY_PREFIX = "ShareTicket:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public String getTicket(Long userId) {
        return (String) redisTemplate.opsForValue().get(TICKET_KEY_PREFIX + userId);
    }

    public void saveTicket(Long userId, String ticket) {
        redisTemplate.opsForValue().set(TICKET_KEY_PREFIX + userId, ticket, 12, TimeUnit.HOURS);
    }
}
