package com.cloud.vaxservice.cache;

import com.cloud.vaxservice.dto.TetrisScoreDTO;
import com.cloud.common.util.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
public class TetrisCache {
    private static final String TETRIS_PLAY_COUNT_PREFIX = "TetrisPlayCount:";
    private static final String TETRIS_TICKET_PREFIX = "TetrisTicket:";
    private static final String TETRIS_RANK_TOP = "TetrisRankTop";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public void saveTicket(Long userId, String ticket) {
        String key = TETRIS_TICKET_PREFIX + userId;
        redisTemplate.opsForValue().set(key, ticket, 3, TimeUnit.MINUTES);
    }

    public void removeTicket(Long userId) {
        String key = TETRIS_TICKET_PREFIX + userId;
        redisTemplate.delete(key);
    }

    public String getTicket(Long userId) {
        String key = TETRIS_TICKET_PREFIX + userId;
        Object value = redisTemplate.opsForValue().get(key);
        return value != null ? value.toString() : "";
    }

    public List<TetrisScoreDTO> getRankTop() {
        return (List<TetrisScoreDTO>) redisTemplate.opsForValue().get(TETRIS_RANK_TOP);
    }

    public void saveRankTop(List<TetrisScoreDTO> list) {
        redisTemplate.opsForValue().set(TETRIS_RANK_TOP, list, 180, TimeUnit.SECONDS);
    }

    public void incrTodayPlayCount(Long userId) {
        String key = TETRIS_PLAY_COUNT_PREFIX + DateTimeUtils.toDateString(new Date()) + ":" + userId;
        redisTemplate.opsForValue().increment(key);
        redisTemplate.expire(key, 24, TimeUnit.HOURS);
    }

    public int getTodayPlayCount(Long userId) {
        String key = TETRIS_PLAY_COUNT_PREFIX + DateTimeUtils.toDateString(new Date()) + ":" + userId;
        Integer count = (Integer) redisTemplate.opsForValue().get(key);
        return count == null ? 0 : count;
    }
}
