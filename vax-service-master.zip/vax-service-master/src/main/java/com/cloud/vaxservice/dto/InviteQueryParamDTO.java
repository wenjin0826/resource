package com.cloud.vaxservice.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * 邀请查询参数
 *
 * @author feng
 * @since 2022/09/24
 */
@Data
public class InviteQueryParamDTO {
    /**
     * 邀请人ID
     */
    private Long inviterId;

    /**
     * 页码（1~100之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 100, message = "页码（1~100之间）")
    private Integer pageNo;

    /**
     * 分页大小（1~100之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 1, max = 100, message = "分页大小（1~100之间）")
    private Integer pageSize;
}
