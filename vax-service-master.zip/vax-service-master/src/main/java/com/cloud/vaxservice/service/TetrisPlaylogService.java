package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.TetrisPlaylog;

/**
 * 俄罗斯方块游戏日志服务接口
 *
 * @author feng
 * @since 2022/09/23
 */
public interface TetrisPlaylogService extends IService<TetrisPlaylog> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<TetrisPlaylog> query(TetrisPlaylogQueryParamDTO paramDTO);

    void insert(TetrisPlaylog playlog);
}
