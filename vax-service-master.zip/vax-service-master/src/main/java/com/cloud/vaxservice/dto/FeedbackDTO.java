package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 反馈对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class FeedbackDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 创建时间
     */
    private Date createTime;

}
