package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Feedback;

/**
 * 反馈数据访问
 *
 * @author feng
 * @since 2021-09-25
 */
public interface FeedbackDao extends BaseMapper<Feedback> {
}