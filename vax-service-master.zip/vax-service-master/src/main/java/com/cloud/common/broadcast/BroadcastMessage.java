package com.cloud.common.broadcast;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 广播消息
 *
 * @author fengwenjin
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BroadcastMessage<T> {
    private String key;
    private T data;
}
