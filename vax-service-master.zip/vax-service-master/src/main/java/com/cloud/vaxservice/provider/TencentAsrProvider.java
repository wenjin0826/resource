package com.cloud.vaxservice.provider;

import com.cloud.vaxservice.constant.AsrTencentEngineTypeEnum;
import com.cloud.vaxservice.provider.dto.TencentCreateTranscribeParamDTO;
import com.tencentcloudapi.asr.v20190614.AsrClient;
import com.tencentcloudapi.asr.v20190614.models.CreateRecTaskRequest;
import com.tencentcloudapi.asr.v20190614.models.DescribeTaskStatusRequest;
import com.tencentcloudapi.asr.v20190614.models.Task;
import com.tencentcloudapi.asr.v20190614.models.TaskStatus;
import com.tencentcloudapi.common.Credential;
import com.tencentcloudapi.common.profile.ClientProfile;
import com.tencentcloudapi.common.profile.HttpProfile;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 腾讯ASR提供者
 *
 * @author fengwenjin
 * @since 2021/12/31
 */
@Slf4j
@Component
public class TencentAsrProvider {
    @Value("${tencent.secretId}")
    private String secretId;

    @Value("${tencent.secretKey}")
    private String secretKey;

    @Value("${tencent.asrNotifyUrl}")
    private String asrNotifyUrl;

    public String createRecTask(TencentCreateTranscribeParamDTO paramDTO) {
        try {
            CreateRecTaskRequest request = new CreateRecTaskRequest();
            request.setEngineModelType(paramDTO.getEngineModelType());
            request.setUrl(paramDTO.getAudioUrl());
            request.setSourceType(0L);
            request.setChannelNum(1L);
            request.setResTextFormat(0L);
            request.setFilterModal(1L);
            request.setCallbackUrl(asrNotifyUrl);

            Task task = getAsrClient().CreateRecTask(request).getData();
            if (task != null) {
                return task.getTaskId().toString();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public TaskStatus queryRecTask(Long taskId) {
        try {
            DescribeTaskStatusRequest request = new DescribeTaskStatusRequest();
            request.setTaskId(taskId);
            return getAsrClient().DescribeTaskStatus(request).getData();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    public String getTaskResult(String text, String locale) {
        StringBuilder result = new StringBuilder();
        text = text.replace("\n", "@@@");
        String[] values = text.split("@@@");
        for (String s : values) {
            int index = s.indexOf("]");
            result.append(s.substring(index + 1).trim());
            if (AsrTencentEngineTypeEnum.EN_US.name().equals(locale)) {
                result.append(" ");
            }
        }
        return result.toString();
    }

    private AsrClient getAsrClient() {
        HttpProfile httpProfile = new HttpProfile();
        httpProfile.setConnTimeout(30);

        ClientProfile clientProfile = new ClientProfile();
        clientProfile.setHttpProfile(httpProfile);

        Credential cred = new Credential(secretId, secretKey);
        return new AsrClient(cred, "", clientProfile);
    }
}
