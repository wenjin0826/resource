package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.vaxservice.dao.SubscriptionDao;
import com.cloud.vaxservice.entity.Subscription;
import com.cloud.vaxservice.service.SubscriptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 订阅服务实现类
 *
 * @author makejava
 * @since 2024/11/26
 */
@Slf4j
@Service
public class SubscriptionServiceImpl extends ServiceImpl<SubscriptionDao, Subscription> implements SubscriptionService {

    @Override
    public Subscription getSubscription(Long userId, String product) {
        QueryWrapper<Subscription> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(Subscription.USER_ID, userId);
        queryWrapper.eq(Subscription.PRODUCT, product);
        return getOne(queryWrapper, false);
    }
}
