package com.cloud.vaxservice.dto;

import java.util.Date;
import lombok.Data;

/**
 * 广告对象
 *
 * @author feng
 * @since 2022/06/13
 */
@Data
public class AdvertiseDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 状态：1表示可用 0表示不可用
     */
    private Integer status;

    /**
     * 图片地址
     */
    private String imgUrl;

    /**
     * 查看地址
     */
    private String viewUrl;

    /**
     * 跳转地址
     */
    private String redirectUrl;

    /**
     * 排序值
     */
    private Integer sortIndex;

    /**
     * 阅读数
     */
    private Integer viewCount;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}