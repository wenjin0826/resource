package com.cloud.vaxservice.support;

import com.cloud.common.bean.SessionInfo;
import com.cloud.common.support.SessionCache;
import com.cloud.common.util.TokenUtils;
import com.cloud.vaxservice.dto.UserSessionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 功能描述
 *
 * @author fengwenjin
 * @since 2021/11/21
 */
@Component
public class SessionHelper {
    @Autowired
    private SessionCache sessionCache;

    public UserSessionDTO create(Long userId, String nickName, String secret, String appName) {
        // 创建会话
        SessionInfo sessionInfo = new SessionInfo();
        sessionInfo.setUserId(userId);
        sessionInfo.setNickName(nickName);
        sessionInfo.setSecret(secret);
        sessionInfo.setAppName(appName);
        sessionCache.save(sessionInfo, 24 * 3600);

        // 创建Token
        String accessToken = TokenUtils.build(appName, String.valueOf(userId), secret);

        // 返回结果
        UserSessionDTO sessionDTO = new UserSessionDTO();
        sessionDTO.setAccessToken(accessToken);
        sessionDTO.setUserId(userId);
        sessionDTO.setNickName(nickName);
        return sessionDTO;
    }

    public void remove(SessionInfo sessionInfo) {
        if (sessionInfo != null) {
            sessionCache.remove(sessionInfo.getAppName(), sessionInfo.getUserId());
        }
    }
}
