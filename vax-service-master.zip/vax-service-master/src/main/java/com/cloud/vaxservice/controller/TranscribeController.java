package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.vaxservice.config.ShareConfig;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.*;
import com.cloud.vaxservice.dto.TranscribeCreateParamDTO;
import com.cloud.vaxservice.dto.TranscribeCreateResultDTO;
import com.cloud.vaxservice.dto.TranscribeQueryParamDTO;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.entity.UserTask;
import com.cloud.vaxservice.provider.TencentAsrProvider;
import com.cloud.vaxservice.provider.dto.TencentCreateTranscribeParamDTO;
import com.cloud.vaxservice.service.TranscribeService;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.service.UserTaskService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 转录接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Controller
public class TranscribeController {
    @Autowired
    private TranscribeService transcribeService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserTaskService userTaskService;

    @Autowired
    private TencentAsrProvider tencentAsrProvider;

    @Autowired
    private VaxConfig vaxConfig;

    @Autowired
    private ShareConfig shareConfig;

    /**
     * 根据任务ID获取查看链接
     *
     * @param taskId 任务ID
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/getViewUrl")
    public ResultInfo<String> getViewUrl(String taskId) {
        String viewUrl = shareConfig.getViewDomains().get(0);
        viewUrl = viewUrl + RequestContext.getRequest().getContextPath() + "/transcribe/view/" + taskId;
        return ResultInfo.success().setData(viewUrl);
    }

    /**
     * 根据任务ID查看详情
     *
     * @param taskId 任务ID
     * @return String 响应结果
     */
    @GetMapping("/transcribe/view/{taskId}")
    public String view(@PathVariable("taskId") String taskId, Model model) {
        Transcribe transcribe = transcribeService.getByTaskId(taskId);
        String result = transcribe != null ? transcribe.getTaskResult() : "";
        model.addAttribute("result", result);
        return "task";
    }

    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/query")
    public ResultInfo<PageInfo<Transcribe>> query(@Valid @RequestBody TranscribeQueryParamDTO paramDTO) {
        paramDTO.setUserId(SessionContext.getUserId());
        PageInfo<Transcribe> pageInfo = transcribeService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }

    /**
     * 删除
     *
     * @param id
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/delete")
    public ResultInfo<String> delete(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        transcribeService.removeById(id);
        return ResultInfo.success();
    }

    /**
     * 创建数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/create")
    @Limit(limitMode = 1, limitCount = 30, durationSeconds = 3600)
    public ResultInfo<TranscribeCreateResultDTO> create(@Valid @RequestBody TranscribeCreateParamDTO paramDTO) {
        Long userId = SessionContext.getUserId();

        // 判断是否有正在处理中
        if (transcribeService.existRunning(userId)) {
            return ErrorEnum.EXTRACT_RUNNING.result();
        }

        // 转换为分钟
        int audioMinutes = paramDTO.getAudioSeconds() / 60;
        if (paramDTO.getAudioSeconds() % 60 > 0) {
            audioMinutes++;
        }

        // 查询用户数据
        int todayFreeCount = transcribeService.getTodayFreeCount(userId);
        User user = userService.getById(userId);
        int userScore = user.getScore();

        if (audioMinutes <= vaxConfig.getFreeMinutes()) {
            // 判断免费提取的次数
            if (todayFreeCount >= vaxConfig.getFreeLimitCount() && userScore < audioMinutes) {
                TranscribeCreateResultDTO resultDTO = buildFailureResult(userScore, audioMinutes);
                return ErrorEnum.TODAY_FREE_LIMITED.result().setData(resultDTO);
            }
        } else if (userScore < audioMinutes){
            TranscribeCreateResultDTO resultDTO = buildFailureResult(userScore, audioMinutes);
            return ErrorEnum.USER_SCORE_NOT_ENOUGH.result().setData(resultDTO);
        }

        String taskId = tencentCreateTask(paramDTO);
        if (StringUtils.isEmpty(taskId)) {
            return ResultInfo.failure();
        }
        Transcribe transcribe = new Transcribe();
        transcribe.setTaskId(taskId);
        transcribe.setLocale(paramDTO.getLocale());
        transcribe.setProvider(CloudProviderEnum.TENCENT.name());
        transcribe.setTaskStatus(StatusEnum.RUNNING.getStatus());
        transcribe.setAudioUrl(paramDTO.getAudioUrl());
        transcribe.setCreateUser(userId);
        transcribe.setCreateTime(new Date());
        transcribeService.save(transcribe);

        UserTask userTask = new UserTask();
        userTask.setTaskId(taskId);
        userTask.setTaskType(TaskTypeEnum.TEXT_EXTRACT.getCode());
        userTask.setTaskStatus(TaskStatusEnum.RUNNING.getCode());
        userTask.setTaskTitle(paramDTO.getTaskTitle());
        userTask.setCreateUser(userId);
        userTask.setCreateTime(new Date());
        userTaskService.save(userTask);

        // 返回结果
        TranscribeCreateResultDTO createResultDTO = new TranscribeCreateResultDTO();
        createResultDTO.setTaskId(taskId);
        if (todayFreeCount + 1 >= vaxConfig.getFreeLimitCount()) {
            createResultDTO.setFreeLimited(true);
        } else {
            createResultDTO.setFreeLimited(false);
        }
        return ResultInfo.success().setData(createResultDTO);
    }

    private TranscribeCreateResultDTO buildFailureResult(int userScore, int audioMinutes) {
        TranscribeCreateResultDTO resultDTO = new TranscribeCreateResultDTO();
        StringBuilder payTipBuilder = new StringBuilder();
        int payScore = audioMinutes;
        if (audioMinutes <= vaxConfig.getFreeMinutes()) {
            payTipBuilder.append("每天免费" + vaxConfig.getFreeLimitCount() + "次" + vaxConfig.getFreeMinutes() + "分钟已经用完，");
            resultDTO.setFreeLimited(true);
        } else {
            payTipBuilder.append("时长超" + vaxConfig.getFreeMinutes() + "分钟不属于免费范围，");
            resultDTO.setFreeLimited(false);
        }
        payTipBuilder.append("每分钟要0.1元，");
        if (userScore > 0) {
            payScore = audioMinutes - userScore;

            String remainMoney = new BigDecimal(userScore).multiply(new BigDecimal("0.1")).toString();
            payTipBuilder.append("上次剩余" + remainMoney + "元，");
        }
        String pay = new BigDecimal(payScore).multiply(new BigDecimal("0.1")).toString();
        payTipBuilder.append("本次支付" + pay + "元。");

        resultDTO.setPayTip(payTipBuilder.toString());
        resultDTO.setPayMoney((payScore * 10));
        return resultDTO;
    }

    private String tencentCreateTask(TranscribeCreateParamDTO paramDTO) {
        AsrTencentEngineTypeEnum engineType = AsrTencentEngineTypeEnum.valueOf(paramDTO.getLocale());
        TencentCreateTranscribeParamDTO transcribeParamDTO = new TencentCreateTranscribeParamDTO();
        transcribeParamDTO.setEngineModelType(engineType.getCode());
        transcribeParamDTO.setAudioUrl(paramDTO.getAudioUrl());
        return tencentAsrProvider.createRecTask(transcribeParamDTO);
    }
}