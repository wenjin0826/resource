package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.bean.SessionInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.util.RSAUtils;
import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.constant.RSAWeAppKeyEnum;
import com.cloud.vaxservice.dto.SecretLoginParamDTO;
import com.cloud.vaxservice.dto.UserSessionDTO;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.support.SessionHelper;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private SessionHelper sessionHelper;

    /**
     * 获取用户信息
     *
     * @return ResultInfo<User>
     */
    @PostMapping("/user/getUserInfo")
    public ResultInfo<User> getUserInfo() {
        User user = userService.getById(SessionContext.getUserId());
        return ResultInfo.success().setData(user);
    }

    /**
     * 注销账号
     *
     * @return
     */
    @PostMapping("/user/destroy")
    public ResultInfo<String> destroyUser() {
        Long userId = SessionContext.getUserId();
        userService.removeById(userId);
        return ResultInfo.success();
    }

    /**
     * 退出登录
     *
     * @return
     */
    @PostMapping("/user/logout")
    public ResultInfo<String> userLogout() {
        SessionInfo sessionInfo = SessionContext.get();
        sessionHelper.remove(sessionInfo);
        return ResultInfo.success();
    }

    /**
     * 密钥登录
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/user/secretLogin")
    public ResultInfo<UserSessionDTO> secretLogin(@Valid @RequestBody SecretLoginParamDTO paramDTO) throws Exception {
        Long userId = paramDTO.getUserId();
        String secret = paramDTO.getSecret();
        if (userId == null || StringUtils.isEmpty(secret)) {
            return ResultInfo.badRequest();
        }
        User user = userService.getById(userId);
        if (user == null) {
            log.warn("login failure user not exist, requestIP=" + RequestContext.getRequestIP());
            return ResultInfo.failure();
        }
        if (user.getStatus() == Constants.NO) {
            log.warn("login failure user disable, userId=" + userId);
            throw ErrorEnum.USER_DISABLE.exception();
        }

        secret = RSAUtils.decryptByPrivateKey(RSAWeAppKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getSecret());
        if (!user.getSecret().equals(secret)) {
            log.warn("login failure secret error, userId=" + userId);
            throw ErrorEnum.LOGIN_FAILURE.exception();
        }

        UserSessionDTO sessionDTO = sessionHelper.create(user.getId(), user.getNickName(), user.getSecret(), AppEnum.APP_WEB.name());
        return ResultInfo.success().setData(sessionDTO);
    }
}