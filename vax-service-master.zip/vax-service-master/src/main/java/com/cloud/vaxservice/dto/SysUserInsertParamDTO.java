package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 系统用户添加参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class SysUserInsertParamDTO {
    /**
     * 用户名
     */
    @NotEmpty(message = "用户名不能为空")
    private String username;

    /**
     * 昵称
     */
    @NotEmpty(message = "昵称不能为空")
    private String nickname;

    /**
     * 密码
     */
    @NotEmpty(message = "密码不能为空")
    private String password;

    /**
     * 角色
     */
    @NotEmpty(message = "角色不能为空")
    private String role;

    /**
     * 是否可用
     */
    @NotNull(message = "是否可用不能为空")
    private Integer enabled;
}