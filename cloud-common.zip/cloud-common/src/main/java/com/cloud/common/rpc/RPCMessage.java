package com.cloud.common.rpc;

import lombok.Data;

@Data
public class RPCMessage {

    //序号
    private int sequence;
    //数据体大小
    private int bodySize;
    //数据体的值
    private String bodyData;

    public RPCMessage() {
    }

    public RPCMessage(String bodyData) {
        this.bodyData = bodyData;
        this.sequence = Sequence.next();
    }

    public RPCMessage(int sequence, int bodySize, String bodyData) {
        this.sequence = sequence;
        this.bodySize = bodySize;
        this.bodyData = bodyData;
    }

}
