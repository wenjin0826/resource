package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum FunctionCodeEnum {
    SEARCH_DOWNLOAD(1001, "搜索下载"),
    VIDEO_DOWNLOAD(1002, "视频下载"),
    VIDEO_TEXT_EXTRACT(1003, "视频文字提取"),
    AUDIO_TEXT_EXTRACT(1004, "音频文字提取"),
    VIDEO_ERASE_WATERMARK(1005, "视频去除水印"),
    VIDEO_COMPRESS(1006, "视频压缩"),
    VIEW_ARTICLE(1007, "查看文章");

    @Getter
    private int code;

    @Getter
    private String name;

    FunctionCodeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static FunctionCodeEnum of(Integer code) {
        if (code != null) {
            for (FunctionCodeEnum codeEnum : values()) {
                if (codeEnum.code == code.intValue()) {
                    return codeEnum;
                }
            }
        }
        return null;
    }
}
