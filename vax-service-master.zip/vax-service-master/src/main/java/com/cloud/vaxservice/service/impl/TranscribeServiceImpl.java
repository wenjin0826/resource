package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.StatusEnum;
import com.cloud.vaxservice.constant.TaskStatusEnum;
import com.cloud.vaxservice.dao.TranscribeDao;
import com.cloud.vaxservice.dto.TranscribeQueryParamDTO;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.entity.UserTask;
import com.cloud.vaxservice.service.TranscribeService;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.service.UserTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 转录任务服务实现类
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Service
public class TranscribeServiceImpl extends ServiceImpl<TranscribeDao, Transcribe> implements TranscribeService {
    @Autowired
    private UserTaskService userTaskService;

    @Autowired
    private UserService userService;

    @Autowired
    private VaxConfig vaxConfig;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean save(Transcribe entity) {
        super.save(entity);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateById(Transcribe entity) {
        super.updateById(entity);
        return true;
    }

    @Override
    public PageInfo<Transcribe> query(TranscribeQueryParamDTO paramDTO) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(Transcribe.CREATE_USER, paramDTO.getUserId());
        }
        wrapper.orderByDesc(Transcribe.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public Transcribe getByTaskId(String taskId) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.TASK_ID, taskId);
        return getOne(wrapper, false);
    }

    @Override
    public List<Transcribe> getByTaskIds(List<String> taskIds) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.in(Transcribe.TASK_ID, taskIds);
        return list(wrapper);
    }

    @Override
    public List<Transcribe> getRunnings() {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.TASK_STATUS, StatusEnum.RUNNING.getStatus());
        return list(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateResult(StatusEnum statusEnum, Transcribe transcribe) {
        int payScore = 0;
        TaskStatusEnum taskStatusEnum = TaskStatusEnum.FAILURE;
        String taskFailureMsg = taskStatusEnum.getDescription();
        if (statusEnum == StatusEnum.FINISH) {
            taskStatusEnum = TaskStatusEnum.FINISH;
            payScore = getPayScore(transcribe);
            if (payScore > 0) {
                // 更新用户积分
                User user = userService.getById(transcribe.getCreateUser());
                int remainScore = user.getScore() - payScore;
                if (remainScore < 0) {
                    taskStatusEnum = TaskStatusEnum.FAILURE;
                    taskFailureMsg = "该任务未充值异常";
                    log.warn("userId={} remainScore={}", user.getId(), remainScore);
                }
                user.setScore(remainScore);
                user.setUpdateTime(new Date());
                userService.updateById(user);
            }
        }
        transcribe.setPayScore(payScore);
        transcribe.setTaskStatus(statusEnum.getStatus());
        transcribe.setUpdateTime(new Date());
        updateById(transcribe);

        // 更新用户任务记录
        UserTask userTask = userTaskService.getByTaskId(transcribe.getTaskId());
        if (userTask != null) {
            if (taskStatusEnum == TaskStatusEnum.FINISH) {
                userTask.setTaskResult(transcribe.getTaskResult());
            } else {
                userTask.setTaskResult(taskFailureMsg);
            }
            userTask.setTaskStatus(taskStatusEnum.getCode());
            userTask.setPayScore(payScore);
            userTask.setUpdateTime(new Date());
            userTaskService.updateById(userTask);
        }
    }

    private int getPayScore(Transcribe transcribe) {
        // 计算分钟数
        int timeSeconds = (int) (transcribe.getAudioDuration() / 1000);
        int totalMinutes = timeSeconds / 60;
        if (timeSeconds % 60 > 0) {
            totalMinutes++;
        }

        // 计算需要支付的积分
        int payScore = 0;
        int freeMinutes = vaxConfig.getFreeMinutes();
        if (totalMinutes > freeMinutes) {
            payScore = totalMinutes;
        } else {
            int todayFreeCount = getTodayFreeCount(transcribe.getCreateUser());
            if (todayFreeCount > vaxConfig.getFreeLimitCount()) {
                payScore = totalMinutes;
            }
        }
        return payScore;
    }

    @Override
    public void cleanExpired(Date dateTime) {
        QueryWrapper<Transcribe> queryWrapper = new QueryWrapper<>();
        queryWrapper.lt(Transcribe.CREATE_TIME, dateTime);
        remove(queryWrapper);
    }

    @Override
    public int getTodayFreeCount(Long userId) {
        Date beginTime = DateTimeUtils.asDate(LocalDate.now());
        Date endTime = DateTimeUtils.asDate(LocalDate.now().plusDays(1));
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.CREATE_USER, userId);
        wrapper.eq(Transcribe.PAY_SCORE, 0);
        wrapper.gt(Transcribe.CREATE_TIME, beginTime);
        wrapper.lt(Transcribe.CREATE_TIME, endTime);
        wrapper.select(Transcribe.TASK_ID);
        return list(wrapper).size();
    }

    /**
     * 是否存在正在运行的转录
     *
     * @param userId
     * @return boolean
     */
    @Override
    public boolean existRunning(Long userId) {
        QueryWrapper<Transcribe> wrapper = new QueryWrapper<>();
        wrapper.eq(Transcribe.CREATE_USER, userId);
        wrapper.eq(Transcribe.TASK_STATUS, StatusEnum.RUNNING.getStatus());
        return list(wrapper).size() > 0;
    }
}