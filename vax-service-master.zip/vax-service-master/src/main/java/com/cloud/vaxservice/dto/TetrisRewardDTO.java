package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 俄罗斯方块中奖对象
 *
 * @author feng
 * @since 2022/09/23
 */
@Data
public class TetrisRewardDTO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户昵称
     */
    private String nickName;

    /**
     * 应用类型
     */
    private String appType;

    /**
     * 游戏分数
     */
    private Integer gameScore;

    /**
     * 奖励级别
     */
    private Integer rewardLevel;

    /**
     * 是否付款：0未支付 1已支付
     */
    private Integer paid;

    /**
     * 备注描述
     */
    private String description;

    /**
     * 创建时间
     */
    private Date createTime;

}
