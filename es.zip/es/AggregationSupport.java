package com.cloud.consumer.es;

import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedTerms;
import org.elasticsearch.search.aggregations.metrics.*;
import org.springframework.data.domain.PageRequest;

import java.util.*;

public class AggregationSupport {
    public static final int AGGREGATION_SIZE = 100;

    /**
     * 聚合分析的分页对象，用于控制不返回搜索的数据
     *
     * @return PageRequest
     */
    public static PageRequest aggregationPage() {
        return PageRequest.of(0, 1);
    }

    /**
     * 分组聚合分析时，同时返回命中数据的其他字段，所以返回数量1条就满足了
     *
     * @param fieldNames
     * @return TopHitsAggregationBuilder
     */
    public static TopHitsAggregationBuilder topHitsBuilder(String[] fieldNames) {
        return AggregationBuilders.topHits("fetch_field_hits")
                .fetchSource(fieldNames, null)
                .size(1);
    }

    public static BucketResult parse(List<Aggregation> aggList) {
        BucketResult bucketResult = new BucketResult();
        aggList.forEach(aggregation -> {
            if (aggregation instanceof ParsedTerms == false) {
                return;
            }
            ParsedTerms terms = (ParsedTerms) aggregation;
            terms.getBuckets().forEach(bucket -> {
                BucketMetric bucketMetric = new BucketMetric();
                bucketMetric.setKey(bucket.getKeyAsString());
                bucketMetric.setCount(bucket.getDocCount());
                bucketResult.addBucketMetric(bucketMetric);

                bucket.getAggregations().asList().forEach(agg -> {
                    // 获取字段属性
                    if (agg instanceof ParsedTopHits) {
                        ParsedTopHits topHits = (ParsedTopHits) agg;
                        SearchHit documentFields = Arrays.stream(topHits.getHits().getHits()).findFirst().orElse(null);
                        bucketResult.setFieldJSONString(documentFields.getSourceAsString());
                        return;
                    }
                    parseSubAggregation(agg, bucketMetric);
                });
            });
        });
        return bucketResult;
    }

    private static void parseSubAggregation(Aggregation agg, BucketMetric bucketMetric) {
        if (agg instanceof ParsedTerms) {
            List<BucketMetric> subBucketMetricList = new ArrayList<>();
            Map<BucketMetric, List<Aggregation>> bucketMetricMap = new HashMap<>();

            ParsedTerms terms = (ParsedTerms) agg;
            terms.getBuckets().forEach(bucket -> {
                BucketMetric subBucketMetric = new BucketMetric();
                subBucketMetric.setKey(bucket.getKeyAsString());
                subBucketMetric.setCount(bucket.getDocCount());
                subBucketMetricList.add(subBucketMetric);
                bucketMetricMap.put(subBucketMetric, bucket.getAggregations().asList());
            });
            bucketMetric.setSubBucketMetrics(subBucketMetricList);

            // 递归处理
            bucketMetricMap.entrySet().forEach(bucketEntry -> {
                List<Aggregation> aggList = bucketEntry.getValue();
                for (Aggregation subAgg : aggList) {
                    parseSubAggregation(subAgg, bucketEntry.getKey());
                }
            });
        } else if (agg instanceof ParsedSum) {
            ParsedSum parsedSum = (ParsedSum) agg;
            bucketMetric.setSum(parsedSum.getValue());
        } else if (agg instanceof ParsedAvg) {
            ParsedAvg parsedAvg = (ParsedAvg) agg;
            bucketMetric.setAvg(parsedAvg.getValue());
        } else if (agg instanceof ParsedMin) {
            ParsedMin parsedMin = (ParsedMin) agg;
            bucketMetric.setMin(parsedMin.getValue());
        } else if (agg instanceof ParsedMax) {
            ParsedMax parsedMax = (ParsedMax) agg;
            bucketMetric.setMax(parsedMax.getValue());
        }
    }
}
