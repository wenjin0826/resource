package com.cloud.common.support;

import com.cloud.common.context.RequestContext;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

/**
 * 手机号脱敏序列化
 *
 * @author fengwenjin
 */
public class JsonPhoneSerializer extends JsonSerializer {
    @Override
    public void serialize(Object value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        if (RequestContext.isMaskData() && value != null && value instanceof String) {
            String valueStr = value.toString();
            if (valueStr.length() > 7) {
                String phone = valueStr.substring(0, 3) + "****" + valueStr.substring(valueStr.length() - 4);
                gen.writeString(phone);
                return;
            }
        }
        gen.writeObject(value);
    }
}
