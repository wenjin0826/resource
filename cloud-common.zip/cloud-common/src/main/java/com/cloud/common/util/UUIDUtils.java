package com.cloud.common.util;

import java.util.UUID;

public class UUIDUtils {

    public static String get() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

}
