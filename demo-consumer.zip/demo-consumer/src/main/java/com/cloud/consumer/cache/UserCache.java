package com.cloud.consumer.cache;

import com.cloud.common.sentinel.SentinelResource;
import com.cloud.consumer.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
@SentinelResource
public class UserCache {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public User getById(String userId) {
        return (User) redisTemplate.opsForValue().get(userId);
    }

}
