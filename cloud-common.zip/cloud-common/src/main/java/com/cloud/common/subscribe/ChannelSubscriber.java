package com.cloud.common.subscribe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;

import java.util.HashMap;
import java.util.Map;

/**
 * 消息订阅管理
 */
@Configuration
public class ChannelSubscriber {

    private static final String topic = "ChannelTopic";
    private static final Map<String, MessageHandler> handlerMap = new HashMap<>();

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Bean
    public RedisMessageListenerContainer redisMessageListenerContainer(RedisConnectionFactory connectionFactory) {
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.addMessageListener(new RedisMessageListener(), new ChannelTopic(topic));
        return container;
    }

    /**
     * 发布消息
     * @param message
     */
    public void publish(ChannelMessage message) {
        redisTemplate.convertAndSend(topic, message);
    }

    /**
     * 订阅消息
     * @param type
     * @param handler
     */
    public void subscribe(String type, MessageHandler handler) {
        handlerMap.put(type, handler);
    }

    /**
     * 取消订阅
     * @param type
     */
    public void unsubscribe(String type) {
        handlerMap.remove(type);
    }

    /**
     * 消息处理内部类
     */
    class RedisMessageListener implements MessageListener {
        @Override
        public void onMessage(Message message, byte[] pattern) {
            ChannelMessage channelMessage = (ChannelMessage) redisTemplate.getValueSerializer().deserialize(message.getBody());
            MessageHandler handler = handlerMap.get(channelMessage.getType());
            if (handler != null) {
                handler.handle(channelMessage);
            }
        }
    }

}
