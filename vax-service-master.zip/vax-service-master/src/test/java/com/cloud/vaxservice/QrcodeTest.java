package com.cloud.vaxservice;

import com.cloud.vaxservice.util.QrcodeUtils;
import org.junit.Test;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/10/02
 */
public class QrcodeTest {
    @Test
    public void genGrcode() throws Exception {
        String text = "http://www.baidu.com";
        QrcodeUtils.generateQrCodeImage(text, 200, 200, "D:/Download/qrcode.png");
    }
}
