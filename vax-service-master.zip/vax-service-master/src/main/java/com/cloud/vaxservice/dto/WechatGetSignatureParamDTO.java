package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 功能描述
 *
 * @author feng
 * @since 2022/08/27
 */
@Data
public class WechatGetSignatureParamDTO {
    @NotEmpty(message = "url不能为空")
    private String url;
}
