package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 广告实体类
 *
 * @author feng
 * @since 2022/07/05
 */
@Data
@TableName("t_advertise")
public class Advertise implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 标题
     */
    @TableField("title")
    private String title;

    /**
     * 内容
     */
    @TableField("content")
    private String content;

    /**
     * 状态：1表示可用 0表示不可用
     */
    @TableField("status")
    private Integer status;

    /**
     * 图片地址
     */
    @TableField("img_url")
    private String imgUrl;

    /**
     * 查看地址
     */
    @TableField("view_url")
    private String viewUrl;

    /**
     * 跳转地址
     */
    @TableField("redirect_url")
    private String redirectUrl;

    /**
     * 排序值
     */
    @TableField("sort_index")
    private Integer sortIndex;

    /**
     * 阅读数
     */
    @TableField("view_count")
    private Integer viewCount;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String TITLE = "title";
    public static final String CONTENT = "content";
    public static final String STATUS = "status";
    public static final String IMG_URL = "img_url";
    public static final String VIEW_URL = "view_url";
    public static final String REDIRECT_URL = "redirect_url";
    public static final String SORT_INDEX = "sort_index";
    public static final String VIEW_COUNT = "view_count";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}