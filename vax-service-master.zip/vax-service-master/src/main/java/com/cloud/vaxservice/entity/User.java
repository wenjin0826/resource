package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户实体类
 *
 * @author feng
 * @since 2021-12-30
 */
@Data
@TableName("t_user")
public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * 手机号
     */
    @TableField("phone")
    private String phone;

    /**
     * 邮箱
     */
    @TableField("email")
    private String email;

    /**
     * 密钥
     */
    @TableField("secret")
    private String secret;

    /**
     * 昵称
     */
    @TableField("nick_name")
    private String nickName;

    /**
     * 头像地址
     */
    @TableField("headimg_url")
    private String headimgUrl;

    /**
     * 微信Openid
     */
    @TableField("wx_open_id")
    private String wxOpenId;

    /**
     * VIP用户
     */
    @TableField("vip")
    private Integer vip;

    /**
     * 积分
     */
    @TableField("score")
    private Integer score;

    /**
     * 状态：1表示可用 0表示不可用
     */
    @TableField("status")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String PHONE = "phone";
    public static final String EMAIL = "email";
    public static final String SECRET = "secret";
    public static final String NICK_NAME = "nick_name";
    public static final String HEADIMG_URL = "headimg_url";
    public static final String WX_OPEN_ID = "wx_open_id";
    public static final String VIP = "vip";
    public static final String SCORE = "score";
    public static final String STATUS = "status";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}