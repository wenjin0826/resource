package com.cloud.vaxservice.dto;

import lombok.Data;

@Data
public class WechatUserInfoDTO {
    private String openId;
    private String nickName;
    private String headimgUrl;
}
