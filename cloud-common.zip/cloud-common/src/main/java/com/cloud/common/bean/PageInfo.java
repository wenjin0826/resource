package com.cloud.common.bean;

import com.baomidou.mybatisplus.core.metadata.IPage;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class PageInfo<T> {

    /**
     * 总记录数
     */
    private int total;

    /**
     * 页数
     */
    private int count;

    /**
     * 当前页
     */
    private int current;

    /**
     * 每页大小
     */
    private int size;

    /**
     * 每页数据行
     */
    private List<T> rows;


    public PageInfo(IPage page) {
        rows = page.getRecords();
        size = (int) page.getSize();
        total = (int) page.getTotal();
        current = (int) page.getCurrent();
        count = (total + size - 1) / size;
    }

}