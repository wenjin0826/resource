package com.cloud.common.support;

import com.baomidou.mybatisplus.core.incrementer.IdentifierGenerator;
import com.cloud.common.util.IDUtils;
import org.springframework.stereotype.Component;

/**
 * 数据库ID生成器
 *
 * @author fengwenjin
 */
@Component
public class DefaultIdGenerator implements IdentifierGenerator {
    /**
     * 获取ID
     *
     * @param entity
     * @return
     */
    @Override
    public Long nextId(Object entity) {
        return IDUtils.nextId();
    }
}
