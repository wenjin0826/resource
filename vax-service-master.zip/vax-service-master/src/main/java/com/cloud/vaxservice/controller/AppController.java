package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.dto.AppConfigDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;

/**
 * 应用接口
 */
@Slf4j
@Controller
public class AppController {
    @Autowired
    private VaxConfig vaxConfig;

    /**
     * 获取应用配置
     *
     * @return ResultInfo
     */
    @ResponseBody
    @PostMapping("/app/getConfig")
    public ResultInfo<AppConfigDTO> getConfig() {
        AppConfigDTO appConfigDTO = new AppConfigDTO();
        appConfigDTO.setNoticeTip(vaxConfig.getNoticeTip());
        appConfigDTO.setFreeMinutes(vaxConfig.getFreeMinutes());
        appConfigDTO.setFreeLimitCount(vaxConfig.getFreeLimitCount());
        appConfigDTO.setMaxAudioSize(vaxConfig.getMaxAudioSize());
        appConfigDTO.setMaxAudioMinutes(vaxConfig.getMaxAudioMinutes());
        appConfigDTO.setVersionCode(vaxConfig.getVersionCode());
        appConfigDTO.setVersionUrl(vaxConfig.getVersionUrl());
        appConfigDTO.setBuildTime(vaxConfig.getBuildTime());
        return ResultInfo.success().setData(appConfigDTO);
    }

    @RequestMapping("/app/open/{page}")
    public String open(@PathVariable("page") String page, Model model, HttpServletResponse response) throws Exception {
        if (RequestContext.getUserAgent().contains("MicroMessenger")) {
            response.setContentType("application/pdf");
            model.addAttribute("result", "请打开浏览器下载");
            return "task";
        }
        response.sendRedirect(vaxConfig.getSiteUrl() + "/vax-web/" + page);
        return null;
    }
}
