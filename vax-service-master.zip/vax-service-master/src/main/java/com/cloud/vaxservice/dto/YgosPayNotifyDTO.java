package com.cloud.vaxservice.dto;

import lombok.Data;

/**
 * Ygos支付通知对象
 *
 * @author feng
 * @since 2023/03/05
 */
@Data
public class YgosPayNotifyDTO {
    private String code;
    private String mchId;
    private String outTradeNo;
    private String orderNo;
    private String payNo;
}
