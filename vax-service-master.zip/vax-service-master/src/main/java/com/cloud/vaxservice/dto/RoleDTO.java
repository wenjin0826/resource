package com.cloud.vaxservice.dto;

import java.util.Date;
import lombok.Data;

/**
 * 角色对象
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class RoleDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 角色名
     */
    private String name;

    /**
     * 访问路径
     */
    private String accessPath;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
