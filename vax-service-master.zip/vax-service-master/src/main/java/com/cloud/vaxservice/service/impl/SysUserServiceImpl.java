package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dao.SysUserDao;
import com.cloud.vaxservice.dto.SysUserQueryParamDTO;
import com.cloud.vaxservice.entity.SysUser;
import com.cloud.vaxservice.service.SysUserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserDao, SysUser> implements SysUserService {
    @Override
    public boolean checkNameExist(String username, Integer ignoreId) {
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq(SysUser.USERNAME, username);
        if (ignoreId != null) {
            wrapper.ne(SysUser.ID, ignoreId);
        }
        if (CollectionUtils.isEmpty(list(wrapper))) {
            return false;
        }
        return true;
    }

    @Override
    public SysUser getByUsername(String username) {
        QueryWrapper query = new QueryWrapper();
        query.eq(SysUser.USERNAME, username);
        return getOne(query);
    }

    @Override
    public PageInfo<SysUser> query(SysUserQueryParamDTO paramDTO) {
        QueryWrapper query = new QueryWrapper();
        if (StringUtils.isNotEmpty(paramDTO.getUsername())) {
            query.like(SysUser.USERNAME, paramDTO.getUsername());
        }
        query.orderByDesc(SysUser.ID);
        IPage page =  page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), query);
        return new PageInfo(page);
    }
}
