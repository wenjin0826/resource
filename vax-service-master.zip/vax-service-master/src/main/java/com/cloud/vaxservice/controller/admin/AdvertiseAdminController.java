package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import com.cloud.vaxservice.dto.AdvertiseDTO;
import com.cloud.vaxservice.dto.AdvertiseInsertParamDTO;
import com.cloud.vaxservice.dto.AdvertiseQueryParamDTO;
import com.cloud.vaxservice.dto.AdvertiseUpdateParamDTO;
import com.cloud.vaxservice.entity.Advertise;
import com.cloud.vaxservice.service.AdvertiseService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;

/**
 * 广告接口
 *
 * @author feng
 * @since 2022/06/13
 */
@Slf4j
@RestController
public class AdvertiseAdminController {
    @Autowired
    private AdvertiseService advertiseService;

    /**
     * 根据主键ID获取
     *
     * @param id 主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/advertise/get")
    public ResultInfo<AdvertiseDTO> getAdvertise(Integer id) {
        if (id == null) {
            return ResultInfo.badRequest();
        }
        Advertise advertise = advertiseService.getById(id);
        return ResultInfo.success().setData(ObjectUtils.copy(advertise, AdvertiseDTO.class));
    }
    
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/advertise/query")
    public ResultInfo<PageInfo<AdvertiseDTO>> queryAdvertise(@Valid @RequestBody AdvertiseQueryParamDTO paramDTO) {
        PageInfo<Advertise> pageInfo = advertiseService.query(paramDTO);
        List<AdvertiseDTO> list = ObjectUtils.copy(pageInfo.getRows(), AdvertiseDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 新增
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/advertise/insert")
    public ResultInfo<String> insertAdvertise(@Valid @RequestBody AdvertiseInsertParamDTO paramDTO) {
        Advertise advertise = ObjectUtils.copy(paramDTO, Advertise.class);
        advertiseService.save(advertise);
        return ResultInfo.success();
    }

    /**
     * 更新
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/advertise/update")
    public ResultInfo<String> updateAdvertise(@Valid @RequestBody AdvertiseUpdateParamDTO paramDTO) {
        Advertise advertise = ObjectUtils.copy(paramDTO, Advertise.class);
        advertiseService.updateById(advertise);
        return ResultInfo.success();
    }
    
    /**
     * 根据主键ID批量删除
     *
     * @param ids 批量主键ID
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/advertise/delete")
    public ResultInfo<String> deleteAdvertise(@RequestBody List<Integer> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ResultInfo.badRequest();
        }
        advertiseService.removeByIds(ids);
        return ResultInfo.success();
    }
}