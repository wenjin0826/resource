package com.cloud.common.exception;

import com.alibaba.csp.sentinel.Tracer;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.cloud.common.bean.ResultInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Slf4j
@ResponseBody
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 内部错误
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(Exception.class)
    public ResultInfo handleException(HttpServletRequest request, Exception exception) {
        String message = "requestURI=" + request.getRequestURI() + " " + exception.getMessage();
        log.error(message, exception);
        Tracer.trace(exception);

        return new ResultInfo().setCode(HttpStatus.INTERNAL_SERVER_ERROR.value()).setMessage(exception.getMessage());
    }

    /**
     * 熔断错误
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(BlockException.class)
    public ResultInfo handleBlockException(HttpServletRequest request) {
        log.warn("requestURI={} circuit break", request.getRequestURI());
        return new ResultInfo().setCode(HttpStatus.SERVICE_UNAVAILABLE.value());
    }

    /**
     * 参数错误
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(ParameterException.class)
    public ResultInfo handleParameterException(ParameterException exception) {
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(exception.getMessage());
    }

    /**
     * 参数匹配错误
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResultInfo handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException exception) {
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(exception.getMessage());
    }

    /**
     * 参数验证错误
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResultInfo handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        StringBuilder message = new StringBuilder();
        List<FieldError> fieldErrorList = exception.getBindingResult().getFieldErrors();
        for (FieldError fieldError : fieldErrorList) {
            message.append(fieldError.getDefaultMessage()).append(",");
        }
        message.deleteCharAt(message.length() - 1);
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(message.toString());
    }

    /**
     * 错误请求
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResultInfo handleNotReadableException(HttpMessageNotReadableException exception) {
        return new ResultInfo().setCode(HttpStatus.BAD_REQUEST.value()).setMessage(exception.getMessage());
    }

    /**
     * 请求方法不支持
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResultInfo handleRequestMethodNotSupportedException() {
        return new ResultInfo().setCode(HttpStatus.METHOD_NOT_ALLOWED.value());
    }

    /**
     * 请求路径不存在
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResultInfo handleNoHandlerFoundException() {
        return new ResultInfo().setCode(HttpStatus.NOT_FOUND.value());
    }

}