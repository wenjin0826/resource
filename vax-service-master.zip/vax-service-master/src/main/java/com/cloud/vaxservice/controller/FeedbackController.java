package com.cloud.vaxservice.controller;

import com.cloud.vaxservice.dto.FeedbackInsertParamDTO;
import com.cloud.vaxservice.entity.Feedback;
import com.cloud.vaxservice.service.FeedbackService;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 反馈接口
 *
 * @author feng
 * @since 2021-09-25
 */
@Slf4j
@RestController
public class FeedbackController {
    @Autowired
    private FeedbackService feedbackService;

    /**
     * 新增反馈
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/feedback/insert")
    @Limit(limitMode = 1, limitCount = 10, durationSeconds = 30)
    public ResultInfo<String> insert(@Valid @RequestBody FeedbackInsertParamDTO paramDTO) {
        Feedback feedback = ObjectUtils.copy(paramDTO, Feedback.class);
        feedback.setUserId(SessionContext.getUserId());
        feedbackService.save(feedback);
        return ResultInfo.success();
    }
}