package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.context.AppContext;
import com.cloud.vaxservice.constant.PayStatusEnum;
import com.cloud.vaxservice.dao.TransferPaymentDao;
import com.cloud.vaxservice.entity.TransferPayment;
import com.cloud.vaxservice.pay.WxappPayAdapter;
import com.cloud.vaxservice.service.TransferPaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * 企业付款单服务实现类
 *
 * @author feng
 * @since 2022/09/26
 */
@Slf4j
@Service
public class TransferPaymentServiceImpl extends ServiceImpl<TransferPaymentDao, TransferPayment> implements TransferPaymentService {
    @Override
    public boolean doPay(TransferPayment payment, String openid) {
        WxappPayAdapter payAdapter = AppContext.getBean(WxappPayAdapter.class);
        boolean paySuccess = payAdapter.transfer(payment.getPayMoney(), payment.getOrderNo(), openid, payment.getPayRemark());

        if (paySuccess) {
            payment.setPayStatus(PayStatusEnum.PAID.getCode());
        } else {
            payment.setPayStatus(PayStatusEnum.PAID_FAIL.getCode());
        }
        payment.setCreateTime(new Date());
        save(payment);
        return paySuccess;
    }
}
