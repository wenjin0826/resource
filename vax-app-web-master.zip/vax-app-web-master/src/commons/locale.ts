export function getText(key: string): string {
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
        let suffix = navigator.language == "zh-CN" ? "zh-CN" : "en-US";
        return textMap.get(key + "_" + suffix);
    }
    return textMap.get(key + "_" + "en-US");
}

const textMap = new Map();
textMap.set("aiaitou_en-US", "AIAI-To-You");
textMap.set("aiaitou_zh-CN", "AI产品服务你");

textMap.set("aiaitou_description_en-US", "This is AI product to you");
textMap.set("aiaitou_description_zh-CN", "这是你的人工智能AI产品");

textMap.set("crypto_monitoring_en-US", "Crypto-Monitoring");
textMap.set("crypto_monitoring_zh-CN", "加密货币监控");

textMap.set("speech_to_text_en-US", "Speech-To-Text");
textMap.set("speech_to_text_zh-CN", "语音提取文字");

textMap.set("login_en-US", "Login");
textMap.set("login_zh-CN", "登录");

textMap.set("logout_en-US", "Logout");
textMap.set("logout_zh-CN", "退出登录");

textMap.set("fail_en-US", "Fail");
textMap.set("fail_zh-CN", "失败");

textMap.set("chinese_en-US", "Chinese");
textMap.set("chinese_zh-CN", "中文");

textMap.set("english_en-US", "English");
textMap.set("english_zh-CN", "英文");

textMap.set("preview_en-US", "Preview");
textMap.set("preview_zh-CN", "预览");

textMap.set("please_input_email_en-US", "Please input email");
textMap.set("please_input_email_zh-CN", "请输入邮箱");

textMap.set("please_input_verify_code_en-US", "Please input verify code");
textMap.set("please_input_verify_code_zh-CN", "请输入验证码");

textMap.set("get_verify_code_en-US", "Get Code");
textMap.set("get_verify_code_zh-CN", "获取验证码");

textMap.set("verify_code_sent_en-US", "Verify Code Sent Successfully");
textMap.set("verify_code_sent_zh-CN", "验证码已发送");

textMap.set("verify_code_count_down_en-US", "Seconds");
textMap.set("verify_code_count_down_zh-CN", "秒可重发");

textMap.set("transcribe_support_media_en-US", "Support Media：MP4/MP3/M4A/WAV");
textMap.set("transcribe_support_media_zh-CN", "支持的媒体：MP4/MP3/M4A/WAV");

textMap.set("transcribe_file_too_small_en-US", "File duration cannot be less than 10 seconds");
textMap.set("transcribe_file_too_small_zh-CN", "文件时长不能小于10秒");

textMap.set("transcribe_file_too_big_en-US", "File duration cannot be greater than 3 hours");
textMap.set("transcribe_file_too_big_zh-CN", "文件时长不能大于3小时");

textMap.set("please_choose_file_en-US", "Please click and choose a file");
textMap.set("please_choose_file_zh-CN", "请点击选择要提取的文件");

textMap.set("please_choose_en-US", "Please Choose");
textMap.set("please_choose_zh-CN", "请选择");

textMap.set("browser_not_support_en-US", "Current browser compatibility problem, please use Chrome browser");
textMap.set("browser_not_support_zh-CN", "当前浏览器兼容问题，请使用Chrome浏览器");

textMap.set("preview_selected_file_en-US", "Preview Selected File");
textMap.set("preview_selected_file_zh-CN", "预览选择的文件");

textMap.set("extract_text_en-US", "Extract Text");
textMap.set("extract_text_zh-CN", "提取文字");

textMap.set("processing_en-US", "Processing");
textMap.set("processing_zh-CN", "正在处理");