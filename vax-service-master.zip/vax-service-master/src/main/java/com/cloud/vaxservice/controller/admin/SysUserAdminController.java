package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.bean.SessionInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.support.SessionCache;
import com.cloud.common.util.ObjectUtils;
import com.cloud.common.util.TokenUtils;
import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.Role;
import com.cloud.vaxservice.entity.SysUser;
import com.cloud.vaxservice.service.RoleService;
import com.cloud.vaxservice.service.SysUserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 系统用户接口
 */
@Slf4j
@RestController
public class SysUserAdminController {

    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private SessionCache sessionCache;

    /**
     * 分页查询系统用户
     *
     * @param paramDTO 参数对象
     * @return ResultInfo
     */
    @PostMapping("/admin/sysUser/query")
    public ResultInfo<PageInfo<SysUserDTO>> querySysUser(@Valid @RequestBody SysUserQueryParamDTO paramDTO) {
        PageInfo pageInfo = sysUserService.query(paramDTO);
        List<SysUserDTO> list = ObjectUtils.copy(pageInfo.getRows(), SysUserDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }

    /**
     * 系统用户登录
     *
     * @param paramDTO 参数对象
     * @return
     * @throws Exception
     */
    @PostMapping("/admin/sysUser/login")
    @Limit(limitMode = 0, limitCount = 10, durationSeconds = 3600)
    public ResultInfo<String> sysUserLogin(@Valid @RequestBody SysUserLoginParamDTO paramDTO) throws Exception {
        SysUser sysUser = sysUserService.getByUsername(paramDTO.getUsername());
        if (sysUser == null) {
            throw ErrorEnum.USER_NOTEXIST.exception();
        }
        if (sysUser.getEnabled() != Constants.OK) {
            throw ErrorEnum.USER_DISABLE.exception();
        }
        if (!sysUser.getPassword().equals(paramDTO.getPassword())) {
            throw ErrorEnum.PASSWORD_ERROR.exception();
        }
        sysUser.setLoginTime(new Date());
        sysUser.setLoginIp(RequestContext.getRequestIP());
        sysUserService.updateById(sysUser);

        Set<String> authResources = new HashSet();
        if (sysUser.getUsername().equals(Constants.ADMIN)) {
            authResources.add("/");
        } else {
            Role role = roleService.getByName(sysUser.getRole());
            if (role != null) {
                String[] accessPaths = role.getAccessPath().split(Constants.SEPARATOR);
                for (String path : accessPaths) {
                    authResources.add(path.trim());
                }
            }
        }
        if (CollectionUtils.isEmpty(authResources)) {
            throw ErrorEnum.NO_PERMISSION.exception();
        }

        // 创建会话
        SessionInfo sessionInfo = new SessionInfo();
        sessionInfo.setSecret(RandomStringUtils.randomAlphanumeric(16));
        sessionInfo.setAppName(AppEnum.ADMIN_WEB.name());
        sessionInfo.setUserId(sysUser.getId().longValue());
        sessionInfo.setAuthResources(authResources);
        sessionCache.save(sessionInfo, 24 * 3600);

        String token = TokenUtils.build(sessionInfo.getAppName(), sessionInfo.getUserId(), sessionInfo.getSecret());
        return ResultInfo.success().setData(token);
    }

    /**
     * 系统用户退出
     *
     * @return
     */
    @PostMapping("/admin/sysUser/logout")
    public ResultInfo<String> sysUserLogout() {
        SessionInfo sessionInfo = SessionContext.get();
        if (sessionInfo != null) {
            sessionCache.remove(sessionInfo.getAppName(), sessionInfo.getUserId());
        }
        return ResultInfo.success();
    }

    /**
     * 获取我的信息
     *
     * @return
     */
    @PostMapping("/admin/sysUser/getMe")
    public ResultInfo<SysUser> getMe() {
        SysUser sysUser = sysUserService.getById(SessionContext.getUserId());
        return ResultInfo.success().setData(sysUser);
    }

    /**
     * 添加系统用户
     *
     * @param paramDTO 参数对象
     * @return
     */
    @PostMapping("/admin/sysUser/insert")
    public ResultInfo insertSysUser(@Valid @RequestBody SysUserInsertParamDTO paramDTO) {
        if (sysUserService.checkNameExist(paramDTO.getUsername(), null)) {
            throw ErrorEnum.USERNAME_EXIST.exception();
        }
        SysUser sysUser = ObjectUtils.copy(paramDTO, SysUser.class);
        sysUser.setCreateTime(new Date());
        sysUser.setUpdateTime(new Date());
        sysUser.setPassword(sysUser.getPassword());
        sysUserService.save(sysUser);
        return ResultInfo.success();
    }

    /**
     * 更新系统用户
     *
     * @param paramDTO 参数对象
     * @return
     */
    @PostMapping("/admin/sysUser/update")
    public ResultInfo updateSysUser(@Valid @RequestBody SysUserUpdateParamDTO paramDTO) {
        if (sysUserService.checkNameExist(paramDTO.getUsername(), paramDTO.getId())) {
            throw ErrorEnum.USERNAME_EXIST.exception();
        }
        SysUser sysUser = ObjectUtils.copy(paramDTO, SysUser.class);
        if (StringUtils.isNotEmpty(sysUser.getPassword())) {
            sysUser.setPassword(sysUser.getPassword());
        }
        sysUser.setUpdateTime(new Date());
        sysUserService.updateById(sysUser);
        return ResultInfo.success();
    }

    /**
     * 删除系统用户
     *
     * @param ids ID列表
     * @return
     */
    @PostMapping("/admin/sysUser/delete")
    public ResultInfo deleteSysUser(@RequestBody List<Integer> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return ResultInfo.badRequest();
        }
        sysUserService.removeByIds(ids);
        return ResultInfo.success();
    }
}
