package com.cloud.gateway.support;

public class VersionContext {

    private static final ThreadLocal<String> holder = new ThreadLocal();

    public static void set(String version) {
        holder.set(version);
    }

    public static String get() {
        return holder.get();
    }

    public static void remove() {
        holder.remove();
    }

}
