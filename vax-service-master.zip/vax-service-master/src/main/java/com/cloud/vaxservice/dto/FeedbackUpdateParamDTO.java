package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 反馈更新参数
 *
 * @author feng
 * @since 2022/11/10
 */
@Data
public class FeedbackUpdateParamDTO {
    /**
     * 主键
     */
    @NotNull(message = "主键不能为空")
    private Integer id;

    /**
     * 标题
     */
    @NotEmpty(message = "标题不能为空")
    private String title;

    /**
     * 内容
     */
    @NotEmpty(message = "内容不能为空")
    private String content;

    /**
     * 用户ID
     */
    @NotNull(message = "用户ID不能为空")
    private Long userId;

}
