package com.cloud.common.feign;

import java.lang.annotation.*;

@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface FeignInvoke {

    boolean async() default false;

    boolean rpc() default false;

    int timeout() default 15000;
}
