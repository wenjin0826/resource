// @ts-ignore
/* eslint-disable */
import request from "@/commons/request";

/** 此处后端没有提供注释 GET /alipay/notify */
export async function notify(options?: { [key: string]: any }) {
  return request<any>("/alipay/notify", {
    method: "GET",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 PUT /alipay/notify */
export async function notify3(options?: { [key: string]: any }) {
  return request<any>("/alipay/notify", {
    method: "PUT",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /alipay/notify */
export async function notify2(options?: { [key: string]: any }) {
  return request<any>("/alipay/notify", {
    method: "POST",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 DELETE /alipay/notify */
export async function notify5(options?: { [key: string]: any }) {
  return request<any>("/alipay/notify", {
    method: "DELETE",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 PATCH /alipay/notify */
export async function notify4(options?: { [key: string]: any }) {
  return request<any>("/alipay/notify", {
    method: "PATCH",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /alipay/recharge */
export async function recharge1(
  body: API.RechargeParamDTO,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoRechargeDTO>("/alipay/recharge", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /alipay/status */
export async function status(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.statusParams,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoInteger>("/alipay/status", {
    method: "POST",
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
