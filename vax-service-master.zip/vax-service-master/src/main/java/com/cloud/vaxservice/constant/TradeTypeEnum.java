package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum TradeTypeEnum {
    H5(1, "H5支付"),
    APP(2,"APP支付");

    @Getter
    private int code;

    @Getter
    private String description;

    TradeTypeEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static TradeTypeEnum of(int code) {
        for (TradeTypeEnum typeEnum : values()) {
            if (typeEnum.code == code) {
                return typeEnum;
            }
        }
        return null;
    }

}
