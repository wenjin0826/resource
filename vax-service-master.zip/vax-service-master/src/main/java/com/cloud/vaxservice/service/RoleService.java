package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.RoleQueryParamDTO;
import com.cloud.vaxservice.entity.Role;

public interface RoleService extends IService<Role> {
    /**
     * 检查名称是否存在
     *
     * @param name
     * @param ignoreId
     * @return
     */
    boolean checkNameExist(String name, Integer ignoreId);

    /**
     * 根据名称查询
     *
     * @param namne
     * @return
     */
    Role getByName(String namne);

    /**
     * 分页查询
     *
     * @param paramDTO
     * @return
     */
    PageInfo<Role> query(RoleQueryParamDTO paramDTO);

}
