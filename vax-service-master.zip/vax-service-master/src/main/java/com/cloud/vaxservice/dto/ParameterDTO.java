package com.cloud.vaxservice.dto;

import java.util.Date;
import lombok.Data;

/**
 * 参数对象
 *
 * @author feng
 * @since 2024/03/14
 */
@Data
public class ParameterDTO {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 参数key
     */
    private String paramKey;

    /**
     * 参数值
     */
    private String paramValue;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

}
