package com.cloud.gateway.ribbon;

import com.cloud.gateway.support.AppContext;
import com.cloud.gateway.support.VersionContext;
import com.cloud.gateway.util.ObjectUtils;
import com.netflix.config.CachedDynamicIntProperty;
import com.netflix.loadbalancer.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Data
@Slf4j
public class RibbonBestRule extends ClientConfigEnabledRoundRobinRule {

    private static final String VERSION_KEY = "version";
    private static final Map<String, RibbonBestRule> ruleMap = new HashMap<>();
    private LoadBalancerStats loadBalancerStats;

    public static RibbonBestRule getInstance(String serviceName) {
        return ruleMap.get(serviceName);
    }

    @Override
    public void setLoadBalancer(ILoadBalancer lb) {
        super.setLoadBalancer(lb);
        if (lb instanceof AbstractLoadBalancer) {
            loadBalancerStats = ((AbstractLoadBalancer) lb).getLoadBalancerStats();
            if (loadBalancerStats != null) {
                ruleMap.put(loadBalancerStats.getName(), this);
                try {
                    ObjectUtils.set(loadBalancerStats, "connectionFailureThreshold", new CachedDynamicIntProperty("ribbon.connectionFailureCountThreshold", 1));
                    ObjectUtils.set(loadBalancerStats, "circuitTrippedTimeoutFactor", new CachedDynamicIntProperty("ribbon.circuitTripTimeoutFactorSeconds", 30));
                    ObjectUtils.set(loadBalancerStats, "maxCircuitTrippedTimeout", new CachedDynamicIntProperty("ribbon.circuitTripMaxTimeoutSeconds", 60));
                } catch (Exception e) {
                    log.error("LoadBalancerStats set default value error", e);
                }
            }
        }
    }

    @Override
    public Server choose(Object key) {
        List<Server> serverList = getLoadBalancer().getAllServers();
        if (CollectionUtils.isEmpty(serverList)) {
            return null;
        }
        String serviceName = serverList.stream().findFirst().get().getMetaInfo().getAppName().toLowerCase();

        // 获取指定服务器
        final String serverHost = System.getenv(serviceName);
        if (!StringUtils.isEmpty(serverHost)) {
            Optional<Server> optionalServer = serverList.stream().filter(server -> server.getHost().equals(serverHost)).findFirst();
            if (optionalServer.isPresent()) {
                return optionalServer.get();
            }
        }

        return doChoose(serviceName, null);
    }

    /**
     * 选择服务器实例
     *
     * @param serviceName
     * @param key
     * @return Server
     */
    public Server doChoose(String serviceName, Object key) {
        List<ServiceInstance> instanceList = AppContext.getBean(DiscoveryClient.class).getInstances(serviceName);
        if (CollectionUtils.isEmpty(instanceList)) {
            return null;
        }

        String version = VersionContext.get();
        List<Server> serverList = getLoadBalancer().getAllServers();
        Map<String, List<ServiceInstance>> versionMap = instanceList.stream().collect(Collectors.groupingBy(serviceInstance -> serviceInstance.getMetadata().get(VERSION_KEY)));
        if (versionMap.size() > 1 && version != null) {
            // 按版本号从高到低排序，匹配小于或等于指定的版本
            List<ServiceInstance> matchList = Collections.EMPTY_LIST;
            List<String> versionList = versionMap.keySet().stream().sorted(Comparator.comparing(String::toString).reversed()).collect(Collectors.toList());
            for (String instanceVersion : versionList) {
                if (instanceVersion.compareTo(version) <= 0) {
                    matchList = versionMap.get(instanceVersion);
                    break;
                }
            }
            serverList = matchList.stream().map(serviceInstance -> new Server(serviceInstance.getScheme(), serviceInstance.getHost(), serviceInstance.getPort())).collect(Collectors.toList());
        }
        return bestChoose(serverList, key);
    }

    /**
     * 按最少请求数选择
     *
     * @param serverList
     * @param key
     * @return
     */
    private Server bestChoose(List<Server> serverList, Object key) {
        if (loadBalancerStats == null || CollectionUtils.isEmpty(serverList)) {
            return super.choose(key);
        }
        if (key != null) {
            int index = Math.abs(key.hashCode()) % serverList.size();
            return serverList.get(index);
        }
        Server chooseServer = null;
        long currentTime = System.currentTimeMillis();
        int minimalConcurrentConnections = Integer.MAX_VALUE;
        for (Server server : serverList) {
            ServerStats serverStats = loadBalancerStats.getSingleServerStat(server);
            if (serverStats.isCircuitBreakerTripped(currentTime)) {
                continue;
            }
            int concurrentConnections = serverStats.getActiveRequestsCount(currentTime);
            if (concurrentConnections < minimalConcurrentConnections) {
                minimalConcurrentConnections = concurrentConnections;
                chooseServer = server;
            }
        }
        return chooseServer != null ? chooseServer : super.choose(key);
    }

}
