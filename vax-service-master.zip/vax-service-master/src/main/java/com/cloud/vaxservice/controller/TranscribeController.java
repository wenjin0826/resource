package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.vaxservice.config.ShareConfig;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.*;
import com.cloud.vaxservice.dto.TranscribeCreateParamDTO;
import com.cloud.vaxservice.dto.TranscribeQueryParamDTO;
import com.cloud.vaxservice.entity.Subscription;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.provider.TencentAsrProvider;
import com.cloud.vaxservice.provider.dto.TencentCreateTranscribeParamDTO;
import com.cloud.vaxservice.service.SubscriptionService;
import com.cloud.vaxservice.service.TranscribeService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * 转录接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@Controller
public class TranscribeController {
    @Autowired
    private TranscribeService transcribeService;

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private TencentAsrProvider tencentAsrProvider;

    @Autowired
    private VaxConfig vaxConfig;

    @Autowired
    private ShareConfig shareConfig;

    @Autowired
    private MessageSource messageSource;

    /**
     * 根据任务ID获取查看链接
     *
     * @param taskId 任务ID
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/getViewUrl")
    public ResultInfo<String> getTranscribeViewUrl(String taskId) {
        String viewUrl = shareConfig.getViewDomains().get(0);
        viewUrl = viewUrl + RequestContext.getRequest().getContextPath() + "/transcribe/view/" + taskId;
        return ResultInfo.success().setData(viewUrl);
    }

    /**
     * 根据任务ID查看详情
     *
     * @param taskId 任务ID
     * @return String 响应结果
     */
    @GetMapping("/transcribe/view/{taskId}")
    public String viewTranscribe(@PathVariable("taskId") String taskId, Model model) {
        Transcribe transcribe = transcribeService.getByTaskId(taskId);
        String result = transcribe != null ? transcribe.getTaskResult() : "";
        model.addAttribute("result", result);
        return "task";
    }

    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/query")
    public ResultInfo<PageInfo<Transcribe>> queryTranscribe(@Valid @RequestBody TranscribeQueryParamDTO paramDTO) {
        paramDTO.setUserId(SessionContext.getUserId());
        PageInfo<Transcribe> pageInfo = transcribeService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }

    /**
     * 删除
     *
     * @param id
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/delete")
    public ResultInfo<String> deleteTranscribe(Integer id) {
        Transcribe transcribe = transcribeService.getById(id);
        if (transcribe == null || !transcribe.getUserId().equals(SessionContext.getUserId())) {
            return ResultInfo.badRequest();
        }
        transcribeService.removeById(id);
        return ResultInfo.success();
    }

    /**
     * 创建数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @ResponseBody
    @PostMapping("/transcribe/create")
    @Limit(limitMode = 1, limitCount = 30, durationSeconds = 3600)
    public ResultInfo<String> createTranscribe(@Valid @RequestBody TranscribeCreateParamDTO paramDTO) {
        Long userId = SessionContext.getUserId();

        // 判断是否有正在处理中
        if (transcribeService.existRunning(userId)) {
            throw ErrorEnum.PROCESSING.exception();
        }

        // 转换为分钟
        int audioMinutes = paramDTO.getAudioSeconds() / 60;
        if (paramDTO.getAudioSeconds() % 60 > 0) {
            audioMinutes++;
        }

        // 查询用户数据
        int todayFreeCount = transcribeService.getTodayFreeCount(userId);
        Subscription subscription = subscriptionService.getSubscription(userId, ProductEnum.VOICE_TO_TEXT.name());
        int remainValue = subscription != null ? subscription.getRemainValue() : 0;

        if (audioMinutes <= vaxConfig.getFreeMinutes()) {
            // 判断免费的次数
            if (todayFreeCount >= vaxConfig.getFreeLimitCount() && remainValue < audioMinutes) {
                String message = messageSource.getMessage(ErrorEnum.TODAY_FREE_LIMITED.name(), null, LocaleContextHolder.getLocale());
                return ResultInfo.failure().setMessage(message);
            }
        } else if (remainValue < audioMinutes){
            String message = messageSource.getMessage(ErrorEnum.REMAIN_VALUE_NOT_ENOUGH.name(), null, LocaleContextHolder.getLocale());
            return ResultInfo.failure().setMessage(message);
        }

        String taskId = tencentCreateTask(paramDTO);
        if (StringUtils.isEmpty(taskId)) {
            return ResultInfo.failure();
        }
        Transcribe transcribe = new Transcribe();
        transcribe.setTaskId(taskId);
        transcribe.setLanguage(paramDTO.getLanguage());
        transcribe.setTaskTitle(paramDTO.getTaskTitle());
        transcribe.setProvider(CloudProviderEnum.TENCENT.name());
        transcribe.setTaskStatus(TaskStatusEnum.RUNNING.getStatus());
        transcribe.setAudioUrl(paramDTO.getAudioUrl());
        transcribe.setUserId(userId);
        transcribe.setCreateTime(new Date());
        transcribeService.save(transcribe);

        return ResultInfo.success();
    }

    private String tencentCreateTask(TranscribeCreateParamDTO paramDTO) {
        AsrTencentEngineTypeEnum engineType = AsrTencentEngineTypeEnum.valueOf(paramDTO.getLanguage());
        TencentCreateTranscribeParamDTO transcribeParamDTO = new TencentCreateTranscribeParamDTO();
        transcribeParamDTO.setEngineModelType(engineType.getCode());
        transcribeParamDTO.setAudioUrl(paramDTO.getAudioUrl());
        return tencentAsrProvider.create(transcribeParamDTO);
    }
}