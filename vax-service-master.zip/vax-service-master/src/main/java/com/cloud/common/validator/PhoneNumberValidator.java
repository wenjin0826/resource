package com.cloud.common.validator;

import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

/**
 * 手机号校验逻辑
 *
 * @author fengwenjin
 */
public class PhoneNumberValidator implements ConstraintValidator<PhoneNumberCheck, String> {
    public static final String REGEX = "^[1][2,3,4,5,6,7,8,9][0-9]{9}$";
    private PhoneNumberCheck annotation;

    @Override
    public void initialize(PhoneNumberCheck constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isEmpty(value)) {
            return true;
        }
        return Pattern.matches(REGEX, value);
    }
}
