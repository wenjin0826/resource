package com.cloud.vaxservice.provider;

import com.alibaba.fastjson.JSON;
import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.constant.ErrorEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 阿里云短信服务提供者
 *
 * @author fengwenjin
 * @since 2021/10/5
 */
@Slf4j
@Component
public class AliyunSmsProvider {
    @Value("${aliyun.accessKeyId}")
    private String accessKeyId;

    @Value("${aliyun.accessKeySecret}")
    private String accessKeySecret;

    @Value("${aliyun.region}")
    private String region;

    @Value("${aliyun.sms.signName}")
    private String signName;

    @Value("${aliyun.sms.templateCode}")
    private String templateCode;

    public ResultInfo sendSmsCode(String phone, String code) {
        try {
            CommonRequest request = new CommonRequest();
            request.setSysMethod(MethodType.POST);
            request.setSysProduct("Dysmsapi");
            request.setSysDomain("dysmsapi.aliyuncs.com");
            request.setSysVersion("2017-05-25");
            request.setSysAction("SendSms");
            request.putQueryParameter("RegionId", region);
            request.putQueryParameter("PhoneNumbers", phone);
            request.putQueryParameter("SignName", signName);
            request.putQueryParameter("TemplateCode", templateCode);

            Map<String, String> params = new HashMap<>();
            params.put("code", code);
            request.putQueryParameter("TemplateParam", JsonUtils.toJSONString(params));

            DefaultProfile.addEndpoint(region, "Dysmsapi", "dysmsapi.aliyuncs.com");
            DefaultProfile profile = DefaultProfile.getProfile(region, accessKeyId, accessKeySecret);
            IAcsClient client = new DefaultAcsClient(profile);
            CommonResponse response = client.getCommonResponse(request);
            log.info("sendSmsCode result >>> {}", response.getData());
            String resultCode = JSON.parseObject(response.getData()).getString("Code");
            if ("OK".equals(resultCode)) {
                return ResultInfo.success();
            }
            if ("isv.BUSINESS_LIMIT_CONTROL".equals(resultCode)) {
                return ResultInfo.manyRequest();
            }
            if ("isv.MOBILE_NUMBER_ILLEGAL".equals(resultCode)) {
                throw ErrorEnum.PHONE_NUMBER_ERROR.exception();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        throw ErrorEnum.SEND_SMS_FAILURE.exception();
    }
}
