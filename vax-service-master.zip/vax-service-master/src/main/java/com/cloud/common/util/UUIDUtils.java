package com.cloud.common.util;

import java.util.UUID;

/**
 * UUID工具类
 *
 * @author fengwenjin
 */
public class UUIDUtils {
    public static String get() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
}
