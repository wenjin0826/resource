package com.cloud.common.tcc;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.AppContext;
import com.cloud.common.util.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class TCCTransactionManager {

    private static final String TX_KEY_PREFIX = "Transaction:";

    private ThreadLocal<List<TCCRequest>> successHolder = new ThreadLocal();
    private ThreadLocal<Boolean> cancelHolder = new ThreadLocal();
    private ThreadLocal<String> xidHolder = new ThreadLocal<>();

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 全局事务ID
     *
     * @return
     */
    String getXid() {
        String dateTime = LocalDateTime.now().toString().substring(0, 19);
        dateTime = dateTime.replace("-", "").replace("T", "").replace(":", "");
        return dateTime + RandomStringUtils.randomNumeric(10);
    }

    /**
     * 开始事务
     */
    void begin() {
        successHolder.set(new ArrayList());
        cancelHolder.set(false);
        xidHolder.set(getXid());
    }

    /**
     * 执行
     *
     * @param request
     */
    public void execute(TCCRequest request) {
        if (cancelHolder.get()) {
            return;
        }
        request.setXid(xidHolder.get());
        request.setStatus(TCCRequest.STATUS_TRY);
        ResultInfo resultInfo = request.invoker.execute(request);
        if (resultInfo.successful()) {
            successHolder.get().add(request);
        } else {
            cancelHolder.set(true);
        }
    }

    /**
     * 提交事务
     */
    boolean commit() {
        List<TCCRequest> list = successHolder.get();
        String txData = JsonUtils.toJSONString(list);
        redisTemplate.opsForHash().put(TX_KEY_PREFIX + AppContext.getAppName(), xidHolder.get(), txData);
        log.info("transaction xid {} data >>> {}", xidHolder.get(), txData);

        if (cancelHolder.get()) {
            return false;
        }
        for (TCCRequest request : list) {
            request.setStatus(TCCRequest.STATUS_CONFIRM);
            ResultInfo resultInfo = request.invoker.execute(request);
            if (!resultInfo.successful()) {
                return false;
            }
        }
        redisTemplate.opsForHash().delete(TX_KEY_PREFIX + AppContext.getAppName(), xidHolder.get());
        successHolder.remove();
        cancelHolder.remove();
        xidHolder.remove();
        return true;
    }

    /**
     * 回滚事务
     */
    void rollback() {
        int rollbackCount = 0;
        List<TCCRequest> list = successHolder.get();
        for (TCCRequest request : list) {
            request.setStatus(TCCRequest.STATUS_CANCEL);
            ResultInfo resultInfo = request.invoker.execute(request);
            if (resultInfo.successful()) {
                rollbackCount++;
            }
        }
        if (list.size() == rollbackCount) {
            redisTemplate.opsForHash().delete(TX_KEY_PREFIX + AppContext.getAppName(), xidHolder.get());
        }
        successHolder.remove();
        cancelHolder.remove();
        xidHolder.remove();
    }

}
