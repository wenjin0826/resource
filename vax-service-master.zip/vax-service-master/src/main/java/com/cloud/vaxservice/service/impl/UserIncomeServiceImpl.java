package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.exception.AppException;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.DateTimeUtils;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.constant.PayChannelEnum;
import com.cloud.vaxservice.constant.PayStatusEnum;
import com.cloud.vaxservice.dao.UserIncomeDao;
import com.cloud.vaxservice.dto.UserIncomeQueryParamDTO;
import com.cloud.vaxservice.entity.TransferPayment;
import com.cloud.vaxservice.entity.UserIncome;
import com.cloud.vaxservice.service.TransferPaymentService;
import com.cloud.vaxservice.service.UserIncomeService;
import com.cloud.vaxservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * 用户收入服务实现类
 *
 * @author feng
 * @since 2022/10/10
 */
@Slf4j
@Service
public class UserIncomeServiceImpl extends ServiceImpl<UserIncomeDao, UserIncome> implements UserIncomeService {
    @Autowired
    private TransferPaymentService transferPaymentService;

    @Autowired
    private UserService userService;

    @Override
    public PageInfo<UserIncome> query(UserIncomeQueryParamDTO paramDTO) {
        QueryWrapper<UserIncome> wrapper = new QueryWrapper<>();
        if (paramDTO.getUserId() != null) {
            wrapper.eq(UserIncome.USER_ID, paramDTO.getUserId());
        }
        wrapper.orderByDesc(UserIncome.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public List<UserIncome> list(Long userId, Boolean paid, Date date) {
        QueryWrapper<UserIncome> wrapper = new QueryWrapper<>();
        if (userId != null) {
            wrapper.eq(UserIncome.USER_ID, userId);
        }
        if (paid != null) {
            wrapper.eq(UserIncome.PAID, paid);
        }
        if (date != null) {
            LocalDate localDate = DateTimeUtils.asLocalDate(date);
            Date beginDate = DateTimeUtils.asDate(localDate);
            Date endDate = DateTimeUtils.asDate(localDate.plusDays(1));
            wrapper.ge(UserIncome.CREATE_TIME, beginDate);
            wrapper.lt(UserIncome.CREATE_TIME, endDate);
        }
        return list(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchSave(List<UserIncome> list) {
        for (UserIncome userIncome : list) {
            save(userIncome);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean doPay(Integer id) {
        String lockKey = "UserIncome:LockDoPay:" + id;
        boolean lock = RemoteLock.lock(lockKey, 0);
        if (!lock) {
            throw ErrorEnum.PROCESSING.exception();
        }
        try {
            UserIncome userIncome = getById(id);
            if (userIncome == null) {
                throw new AppException(ResultInfo.badRequest().getMessage());
            }
            String openid = userService.getById(userIncome.getUserId()).getWxOpenId();

            TransferPayment transferPayment = new TransferPayment();
            transferPayment.setUserId(userIncome.getUserId());
            transferPayment.setOrderNo(DateTimeUtils.timeSequence());
            transferPayment.setPayChannel(PayChannelEnum.WX_PAY.getCode());
            transferPayment.setPayMoney(userIncome.getIncomeMoney());
            transferPayment.setPayStatus(PayStatusEnum.UNDO.getCode());
            transferPayment.setPayRemark("奖励");
            transferPayment.setCreateTime(new Date());
            boolean paySuccess = transferPaymentService.doPay(transferPayment, openid);
            if (paySuccess) {
                userIncome.setPaid(PayStatusEnum.PAID.getCode());
                updateById(userIncome);
            }
            return paySuccess;
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }
}
