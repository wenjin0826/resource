package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Share;

/**
 * 分享数据访问
 *
 * @author feng
 * @since 2022/06/11
 */
public interface ShareDao extends BaseMapper<Share> {
}