package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 广告新增参数
 *
 * @author feng
 * @since 2022/06/13
 */
@Data
public class AdvertiseInsertParamDTO {
    /**
     * 标题
     */
    @NotEmpty(message = "标题不能为空")
    private String title;

    /**
     * 内容
     */
    @NotEmpty(message = "内容不能为空")
    private String content;

    /**
     * 状态：1表示可用 0表示不可用
     */
    @NotNull(message = "状态不可用不能为空")
    private Integer status;

    /**
     * 图片地址
     */
    @NotEmpty(message = "图片地址不能为空")
    private String imgUrl;

    /**
     * 查看地址
     */
    @NotEmpty(message = "查看地址不能为空")
    private String viewUrl;

    /**
     * 跳转地址
     */
    private String redirectUrl;

    /**
     * 排序值
     */
    @NotNull(message = "排序值不能为空")
    private Integer sortIndex;
}