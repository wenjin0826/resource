package com.cloud.common.config;

import com.cloud.common.annotation.WebInterceptor;
import com.cloud.common.context.AppContext;
import com.cloud.common.context.ContextInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.data.util.Pair;
import org.springframework.http.client.OkHttp3ClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private ContextInterceptor contextInterceptor;

    private void registryInterceptor(InterceptorRegistry registry) {
        Map<String, Object> map = AppContext.getBeansWithAnnotation(WebInterceptor.class);
        if (map.isEmpty()) {
            return;
        }
        // Pair<HandlerInterceptor, Order>
        List<Pair<HandlerInterceptor, Integer>> pairs = new ArrayList<>();
        map.forEach((key, value) -> {
            try {
                int order = value.getClass().getAnnotation(WebInterceptor.class).order();
                pairs.add(Pair.of((HandlerInterceptor)value, order));
            } catch (Exception e) {
                log.error("registry interceptor error", e);
            }
        });
        List<Pair<HandlerInterceptor, Integer>> list = pairs.stream().sorted(Comparator.comparing(Pair::getSecond)).collect(Collectors.toList());
        for (Pair<HandlerInterceptor, Integer> pair : list) {
            log.info("registry interceptor " + pair.getFirst().getClass().getName());
            registry.addInterceptor(pair.getFirst()).order(pair.getSecond());
        }
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(contextInterceptor).order(Ordered.HIGHEST_PRECEDENCE);
        registryInterceptor(registry);
    }

    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.addAllowedOrigin("*");
        corsConfiguration.addAllowedHeader("*");
        corsConfiguration.addAllowedMethod("*");
        corsConfiguration.setAllowCredentials(true);
        corsConfiguration.setMaxAge(18000L);

        UrlBasedCorsConfigurationSource configurationSource = new UrlBasedCorsConfigurationSource();
        configurationSource.registerCorsConfiguration("/**", corsConfiguration);
        return new CorsFilter(configurationSource);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate(new OkHttp3ClientHttpRequestFactory());
    }

}
