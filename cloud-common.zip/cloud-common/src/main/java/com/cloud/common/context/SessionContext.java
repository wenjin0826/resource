package com.cloud.common.context;

import com.cloud.common.bean.SessionInfo;

public class SessionContext {

    public static final String SESSION_INFO = "SessionInfo";

    private static final ThreadLocal<SessionInfo> holder = new ThreadLocal();

    public static void set(SessionInfo sessionInfo) {
        holder.set(sessionInfo);
    }

    public static SessionInfo get() {
        return holder.get();
    }

    public static void remove() {
        holder.remove();
    }

}
