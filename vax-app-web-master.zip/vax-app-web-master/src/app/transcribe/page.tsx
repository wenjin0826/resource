"use client";
import Dragger from "antd/es/upload/Dragger";
import {InboxOutlined} from "@ant-design/icons";
import {getText} from "@/commons/locale";
import React, {useState} from "react";
import {Button, Drawer, message, Radio, RadioChangeEvent} from "antd";
import {BASE_PATH} from "@/commons/global";
import {createTranscribe} from "@/api/transcribeController";
import {uploadFile} from "@/commons/alioss";
import OSS from "ali-oss";

const getFileFormat = (file: any)=> {
    var format = "";
    if (file.type.endsWith("mp4")) {
        format = "mp4";
    } else if (file.type.endsWith("m4a")) {
        format = "m4a";
    } else if (file.type.endsWith("mpeg")) {
        format = "mp3";
    } else if (file.type.endsWith("wav")) {
        format = "wav";
    }
    return format;
}

let selectedFile: any;
let fileFormat: string = "";
let fileDuration: number = 0;
const parseFile = (file: any) : boolean => {
    console.log(file);

    if(!window.FileReader) {
        message.error(getText("browser_not_support"));
        return false;
    }

    fileFormat = getFileFormat(file);
    if (fileFormat == "") {
        let tip = getText("please_choose") + " " + getText("transcribe_support_media");
        message.error(tip);
        return false;
    }

    const objUrl = URL.createObjectURL(file);
    const audioElement = new Audio(objUrl);
    audioElement.addEventListener('loadedmetadata', (evt) => {
        fileDuration = Math.floor(audioElement.duration);
        console.log("fileDuration=" + fileDuration);
    });

    selectedFile = file;
    return true;
}


/**
 * 文字提取页面
 * @constructor
 */
const TranscribePage: React.FC = () => {
    const [visibleReviewDrawer, setVisibleReviewDrawer] = useState(false);
    const [selectedFileName, setChoosedFileName] = useState<string>(`${getText("transcribe_support_media")}`);
    const [language, setLanguage] = useState(navigator.language == "zh-CN" ? "CHINESE" : "ENGLISH");
    const [videoUrl, setVideoUrl] = useState("");

    const chooseFile = (file: any) => {
        console.log(file);
        if (!parseFile(file)) {
            return;
        }
        setChoosedFileName(file.name);
    }

    const previewFile = () => {
        if (selectedFile == null) {
            message.error(getText("please_choose_file"));
            return;
        }
        let fileUrl = URL.createObjectURL(selectedFile);
        setVideoUrl(fileUrl);
        setVisibleReviewDrawer(true);
    }

    const extractText = () => {
        // 不能小于10秒
        if (fileDuration < 10) {
            message.error(getText("transcribe_file_too_small"));
            return false;
        }
        // 不能大于3小时
        if (fileDuration > 10800) {
            message.error(getText("transcribe_file_too_big"));
            return false;
        }

        if (fileFormat == "m4a" || fileFormat == "mp3" || fileFormat == "wav") {
            var fileReader = new FileReader();
            fileReader.onload = async function(evt:any) {
                const hide = message.loading(getText("processing"));
                let audioUrl: string = await uploadAudio(evt.target.result);
                if (audioUrl != null && audioUrl != "") {
                    await transcribe(audioUrl);
                }
                hide();
            };
            fileReader.readAsArrayBuffer(selectedFile);
            return;
        }

        var worker = new Worker(BASE_PATH + '/media-worker.js')
        var fileReader = new FileReader();
        fileReader.onload = function(evt:any) {
            // 接收worker处理好的数据
            worker.onmessage = async function(result) {
                if (result.data) {
                    const hide = message.loading(getText("processing"));
                    let audioUrl: string = await uploadAudio(result.data.file.buffer);
                    if (audioUrl != null && audioUrl != "") {
                        await transcribe(audioUrl);
                    }
                    hide();
                };
            };
            // 向worker发送数据
            worker.postMessage({
                buffer: evt.target.result,
                file: selectedFile
            });
        };
        fileReader.readAsArrayBuffer(selectedFile);
    }

    async function uploadAudio(audioData: any) : Promise<string> {
        var filePath = 'audio/' + 'tmp_' + new Date().getTime() + ".mp3";
        return await uploadFile(filePath, new OSS.Buffer(audioData), selectedFile.type);
    }

    async function transcribe(audioUrl: string) {
        let param: API.TranscribeCreateParamDTO = {
            taskTitle : selectedFile.name,
            language : language,
            format : fileFormat,
            audioUrl : audioUrl,
            audioSeconds : fileDuration
        }
        // @ts-ignore
        let res: API.ResultInfoTranscribeCreateResultDTO = await createTranscribe(param);
    }

    const changeLanguage = (e: RadioChangeEvent) => {
        console.log('radio checked=' + e.target.value);
        setLanguage(e.target.value);
    };

    return (
        <div id="transcribePage">
            <Dragger showUploadList={false} customRequest={(options) => chooseFile(options.file)}>
                <p className="ant-upload-drag-icon">
                    <InboxOutlined />
                </p>
                <p className="ant-upload-text">{getText("please_choose_file")}</p>
                <p className="ant-upload-hint">{selectedFileName}</p>
            </Dragger>
            <Button onClick={previewFile} size="large" type="primary" block={true} style={{ marginTop: "30px" }}>
                {`${getText("preview_selected_file")}`}
            </Button>

            <Drawer
                destroyOnClose
                title={`${getText("preview")}`}
                open={visibleReviewDrawer}
                footer={null}
                width={'100vw'}
                height={'85vh'}
                placement={'bottom'}
                onClose={() => {
                    setVisibleReviewDrawer(false)
                }}
            >
                <div style={{textAlign: "center"}}>
                    <video src={videoUrl} controls preload="auto" v-show="false" autoPlay width="100%" height="80%">
                    </video>
                </div>
                <div style={{textAlign: "center", padding: "15px"}}>
                    <Radio.Group defaultValue={language} onChange={changeLanguage}>
                        <Radio value="CHINESE">{`${getText("chinese")}`}</Radio>
                        <Radio value="ENGLISH" style={{marginRight: "15px"}}>{`${getText("english")}`}</Radio>
                    </Radio.Group>
                </div>
                <div style={{textAlign: "center", marginTop: "15px"}}>
                    <Button onClick={extractText} size="large" type="primary" block={true} style={{ marginTop: "30px" }}>
                        {`${getText("extract_text")}`}
                    </Button>
                </div>
            </Drawer>
        </div>
    );
};

export default TranscribePage;