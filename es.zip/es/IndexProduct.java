package com.cloud.consumer.es;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
@Document(indexName = "demo-product", shards = 3, createIndex = false)
public class IndexProduct {
    @Id
    @Field(type = FieldType.Long)
    private Long id;

    @Field(type = FieldType.Text)
    private String name;

    @Field(type = FieldType.Keyword)
    private String type;

    @Field(type = FieldType.Keyword)
    private String label;

    @Field(type = FieldType.Keyword)
    private String color;

    @Field(type = FieldType.Integer)
    private Integer amount;

    @Field(type = FieldType.Integer)
    private Integer price;

    @Field(type = FieldType.Keyword)
    private String supplier;

    @Field(type = FieldType.Keyword)
    private String year;

    @Field(type = FieldType.Keyword)
    private String quarter;

    @Field(type = FieldType.Text, index = false)
    private String description;

    @Field(type = FieldType.Text, index = false)
    private String imgUrl;


    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String TYPE = "type";
    public static final String LABEL = "label";
    public static final String COLOR = "color";
    public static final String AMOUNT = "amount";
    public static final String PRICE = "price";
    public static final String SUPPLIER = "supplier";
    public static final String YEAR = "year";
    public static final String QUARTER = "quarter";
    public static final String DESCRIPTION = "description";
    public static final String imgurl = "imgUrl";

}
