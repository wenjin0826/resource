package com.cloud.vaxservice.constant;

public enum ProductEnum {
    VOICE_TO_TEXT,
    TEXT_TO_VOICE,
    CRYPTO_MONITORING;
}
