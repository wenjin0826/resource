package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户任务实体类
 *
 * @author feng
 * @since 2021-12-09
 */
@Data
@TableName("t_user_task")
public class UserTask implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 任务ID
     */
    @TableField("task_id")
    private String taskId;

    /**
     * 任务类型
     */
    @TableField("task_type")
    private Integer taskType;

    /**
     * 任务状态
     */
    @TableField("task_status")
    private Integer taskStatus;

    /**
     * 任务标题
     */
    @TableField("task_title")
    private String taskTitle;

    /**
     * 任务结果
     */
    @TableField("task_result")
    private String taskResult;

    /**
     * 支付积分
     */
    @TableField("pay_score")
    private Integer payScore;

    /**
     * 创建人ID
     */
    @TableField("create_user")
    private Long createUser;

    /**
     * 更新人ID
     */
    @TableField("update_user")
    private Long updateUser;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String TASK_ID = "task_id";
    public static final String TASK_TYPE = "task_type";
    public static final String TASK_STATUS = "task_status";
    public static final String TASK_TITLE = "task_title";
    public static final String TASK_RESULT = "task_result";
    public static final String PAY_SCORE = "pay_score";
    public static final String CREATE_USER = "create_user";
    public static final String UPDATE_USER = "update_user";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}