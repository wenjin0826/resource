package com.cloud.vaxservice.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

/**
 * APP用户查询参数
 *
 * @author makejava
 * @since 2024/11/16
 */
@Data
public class AppUserQueryParamDTO {
    /**
     * ID
     */
    private Long id;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 页码（1~100之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 100, message = "页码（1~100之间）")
    private Integer pageNo;

    /**
     * 分页大小（5~300之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 5, max = 300, message = "分页大小（5~300之间）")
    private Integer pageSize;
}
