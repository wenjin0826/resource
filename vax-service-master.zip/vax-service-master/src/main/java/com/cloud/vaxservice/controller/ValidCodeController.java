package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.limit.Limit;
import com.cloud.common.validator.PhoneNumberValidator;
import com.cloud.vaxservice.cache.ValidCodeCache;
import com.cloud.vaxservice.config.TestConfig;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.provider.AliyunSmsProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.regex.Pattern;

/**
 * 验证码接口
 *
 * @author fengwenjin
 * @since 2021/10/7
 */
@Slf4j
@RestController
public class ValidCodeController {
    @Autowired
    private ValidCodeCache validCodeCache;

    @Autowired
    private AliyunSmsProvider smsProvider;

    @Autowired
    private TestConfig testConfig;

    /**
     * 发送验证码
     *
     * @param phone
     * @return ResultInfo
     */
    @PostMapping("/validCode/send")
    @Limit(limitCount = 6, durationSeconds = 1800)
    public ResultInfo<String> send(String phone) {
        // 判断手机号
        if (StringUtils.isEmpty(phone) || !Pattern.matches(PhoneNumberValidator.REGEX, phone)) {
            return ErrorEnum.PHONE_NUMBER_ERROR.result();
        }
        // 测试手机号直接返回成功
        if (testConfig.getPhone().contains(phone)) {
            return ResultInfo.success();
        }
        String validCode = validCodeCache.getValidCode(phone);
        if (StringUtils.isNotEmpty(validCode)) {
            return ResultInfo.success();
        }
        validCode = RandomStringUtils.randomNumeric(6);
        validCodeCache.saveValidCode(phone, validCode);
        return smsProvider.sendSmsCode(phone, validCode);
    }
}
