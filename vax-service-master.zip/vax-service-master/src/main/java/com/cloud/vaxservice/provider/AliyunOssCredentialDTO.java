package com.cloud.vaxservice.provider;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AliyunOssCredentialDTO {
	private CredentialsDTO credentials;
	private String endpoint;
	private String bucket;
	private String region;
	private String url;

	@Data
	@NoArgsConstructor
	public static class CredentialsDTO {
		private String accessKeyId;
		private String accessKeySecret;
		private String securityToken;
		private long durationSeconds;
	}
}