package com.cloud.vaxservice.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

/**
 * 邮箱登录参数
 *
 * @author feng
 * @since 2024-11-09
 */
@Data
public class EmailLoginParamDTO {
    /**
     * 邮箱
     */
    @NotEmpty(message = "Email cannot be empty")
    @Email(message = "Email is incorrect")
    private String email;

    /**
     * 验证码
     */
    @NotEmpty(message = "Verify Code cannot be empty")
    private String verifyCode;

    /**
     * 邀请人ID
     */
    private Long inviterId;
}