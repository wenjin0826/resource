package com.cloud.common.support;

import lombok.Data;
import org.apache.commons.collections4.ListUtils;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Data
public class PageSlicer<T> {
    // 数据总数
    private int total;
    // 当前页
    private int pageNo;
    // 页大小
    private int pageSize;
    // 总页数
    private int pageCount;
    // 分片列表
    private List<T> sliceList;

    public static <T> PageSlicer slice(List<T> list, int pageNo, int pageSize) {
        PageSlicer<T> pageSlicer = new PageSlicer<>();
        if (CollectionUtils.isEmpty(list)) {
            return pageSlicer;
        }
        List<List<T>> partitionList = ListUtils.partition(list, pageSize);
        int pageCount = partitionList.size();

        pageNo = pageNo > pageCount ? pageCount : pageNo;
        pageNo = pageNo == 0 ? 1 : pageNo;

        pageSlicer.setPageNo(pageNo);
        pageSlicer.setPageSize(pageSize);
        pageSlicer.setPageCount(pageCount);
        pageSlicer.setTotal(list.size());
        pageSlicer.setSliceList(partitionList.get(pageNo - 1));
        return pageSlicer;
    }
}
