package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.vaxservice.dto.UserIncomeQueryParamDTO;
import com.cloud.vaxservice.entity.UserIncome;
import com.cloud.common.bean.PageInfo;

import java.util.Date;
import java.util.List;

/**
 * 小程序用户收入服务接口
 *
 * @author feng
 * @since 2022/10/10
 */
public interface UserIncomeService extends IService<UserIncome> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<UserIncome> query(UserIncomeQueryParamDTO paramDTO);

    List<UserIncome> list(Long userId, Boolean paid, Date date);

    void batchSave(List<UserIncome> list);

    boolean doPay(Integer id);
}
