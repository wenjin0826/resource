package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotEmpty;

/**
 * 角色添加参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class RoleInsertParamDTO {
    /**
     * 名称
     */
    @NotEmpty(message = "名称不能为空")
    private String name;

    /**
     * 访问路径
     */
    @NotEmpty(message = "访问路径不能为空")
    private String accessPath;
}