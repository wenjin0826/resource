package com.cloud.consumer.cache;

import com.cloud.common.sentinel.SentinelResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@SentinelResource
public class WechatCache {

    private static final String TICKET_KEY_PREFIX = "Demo:WechatTicket:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public String getTicket(String appId) {
        return (String) redisTemplate.opsForValue().get(TICKET_KEY_PREFIX + appId);
    }

    public void saveTicket(String appId, String ticket) {
        redisTemplate.opsForValue().set(TICKET_KEY_PREFIX + appId, ticket, 7000, TimeUnit.SECONDS);
    }

}
