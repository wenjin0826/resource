package com.cloud.vaxservice.provider.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 创建转写参数
 *
 * @author fengwenjin
 * @since 2021/12/31
 */
@Data
@NoArgsConstructor
public class TencentCreateTranscribeParamDTO {
    private String engineModelType;
    private String audioUrl;
}
