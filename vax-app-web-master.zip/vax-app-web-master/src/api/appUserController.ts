// @ts-ignore
/* eslint-disable */
import request from "@/commons/request";

/** 此处后端没有提供注释 POST /appuser/emailLogin */
export async function emailLogin(
  body: API.EmailLoginParamDTO,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoUserSessionDTO>("/appuser/emailLogin", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /appuser/getUserInfo */
export async function getUserInfo(options?: { [key: string]: any }) {
  return request<API.ResultInfoAppUserDTO>("/appuser/getUserInfo", {
    method: "POST",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /appuser/logout */
export async function userLogout(options?: { [key: string]: any }) {
  return request<API.ResultInfoString>("/appuser/logout", {
    method: "POST",
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /appuser/secretLogin */
export async function secretLogin(
  body: API.SecretLoginParamDTO,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoUserSessionDTO>("/appuser/secretLogin", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}
