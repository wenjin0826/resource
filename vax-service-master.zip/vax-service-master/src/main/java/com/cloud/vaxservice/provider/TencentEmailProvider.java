package com.cloud.vaxservice.provider;

import com.tencentcloudapi.common.Credential;
import com.tencentcloudapi.common.profile.ClientProfile;
import com.tencentcloudapi.common.profile.HttpProfile;
import com.tencentcloudapi.ses.v20201002.SesClient;
import com.tencentcloudapi.ses.v20201002.models.SendEmailRequest;
import com.tencentcloudapi.ses.v20201002.models.Template;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class TencentEmailProvider {
    @Value("${tencent.secretId}")
    private String secretId;

    @Value("${tencent.secretKey}")
    private String secretKey;

    private static final String END_POINT = "ses.tencentcloudapi.com";
    private static final String SES_CLIENT = "ap-hongkong";
    private static final long TEMPLATE_ID = 130592L;

    public void sendVerifyCode(String subject, String receiverEml, String verifyCode) {
        try {
            Credential cred = new Credential(secretId, secretKey);
            HttpProfile httpProfile = new HttpProfile();
            httpProfile.setEndpoint(END_POINT);
            ClientProfile clientProfile = new ClientProfile();
            clientProfile.setHttpProfile(httpProfile);
            SesClient client = new SesClient(cred, SES_CLIENT, clientProfile);

            SendEmailRequest req = new SendEmailRequest();
            req.setFromEmailAddress("AIAI To You <support@aiaitou.com>");

            req.setSubject(subject);
            String[] destination = {receiverEml};
            req.setDestination(destination);

            Template template = new Template();
            template.setTemplateID(TEMPLATE_ID);
            template.setTemplateData("{\"VerifyCode\": \"" + verifyCode + "\"}");
            req.setTemplate(template);

            client.SendEmail(req);
            log.info("Send email to {} success", receiverEml);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
