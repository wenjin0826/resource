package com.cloud.gateway.bean;

import lombok.Data;

import java.util.Set;

@Data
public class SessionInfo {

    private String secret;
    private String userId;
    private String userArea;
    private String userName;
    private String fullName;
    private String roleName;
    private Object otherInfo;
    private boolean traced;

    private Set<String> whitelistIps;
    private Set<String> authResources;

}
