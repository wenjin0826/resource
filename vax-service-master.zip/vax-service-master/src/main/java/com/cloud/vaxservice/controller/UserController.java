package com.cloud.vaxservice.controller;

import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.common.limit.Limit;
import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.IDUtils;
import com.cloud.common.util.RSAUtils;
import com.cloud.common.util.TokenUtils;
import com.cloud.vaxservice.cache.ValidCodeCache;
import com.cloud.vaxservice.config.TestConfig;
import com.cloud.vaxservice.config.VaxConfig;
import com.cloud.vaxservice.constant.AppEnum;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.constant.ErrorEnum;
import com.cloud.vaxservice.constant.RSAWeAppKeyEnum;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.Invite;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.InviteService;
import com.cloud.vaxservice.service.UserService;
import com.cloud.vaxservice.service.UserTaskService;
import com.cloud.vaxservice.support.SessionHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Date;

/**
 * 用户接口
 *
 * @author feng
 * @since 2021-09-02
 */
@Slf4j
@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private InviteService inviteService;

    @Autowired
    private UserTaskService userTaskService;

    @Autowired
    private ValidCodeCache validCodeCache;

    @Autowired
    private SessionHelper sessionHelper;

    @Autowired
    private VaxConfig vaxConfig;

    @Autowired
    private TestConfig testConfig;

    /**
     * 获取用户信息
     *
     * @return ResultInfo<User>
     */
    @PostMapping("/user/getUserInfo")
    public ResultInfo<User> getUserInfo() {
        User user = userService.getById(SessionContext.getUserId());
        return ResultInfo.success().setData(user);
    }

    /**
     * 注销账号
     *
     * @return
     */
    @PostMapping("/user/destroy")
    public ResultInfo<String> destroy() {
        Long userId = SessionContext.getUserId();
        userTaskService.deleteByUserId(userId);
        userService.removeById(userId);
        return ResultInfo.success();
    }

    /**
     * 退出登录
     *
     * @return
     */
    @PostMapping("/user/logout")
    public ResultInfo<String> logout() {
        sessionHelper.logout();
        return ResultInfo.success();
    }

    @ResponseBody
    @PostMapping("/user/secretLogin")
    public ResultInfo<UserSessionDTO> secretLogin(@Valid @RequestBody SecretLoginParamDTO paramDTO) throws Exception {
        Long userId = paramDTO.getUserId();
        String secret = paramDTO.getSecret();
        if (userId == null || StringUtils.isEmpty(secret)) {
            return ResultInfo.badRequest();
        }
        User user = userService.getById(userId);
        if (user == null) {
            log.warn("login failure user not exist, requestIP=" + RequestContext.getRequestIP());
            return ResultInfo.failure();
        }
        if (user.getStatus() == Constants.NO) {
            log.warn("login failure user disable, userId=" + userId);
            return ErrorEnum.USER_DISABLE.result();
        }

        secret = RSAUtils.decryptByPrivateKey(RSAWeAppKeyEnum.PRIVATE_KEY.getValue(), paramDTO.getSecret());
        if (!user.getSecret().equals(secret)) {
            log.warn("login failure secret error, userId=" + userId);
            return ErrorEnum.LOGIN_FAILURE.result();
        }

        UserSessionDTO sessionDTO = sessionHelper.createUserSession(user, AppEnum.EXTRACT);
        return ResultInfo.success().setData(sessionDTO);
    }

    /**
     * 用户登录
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/user/login")
    @Limit(limitCount = 10, durationSeconds = 3600)
    public ResultInfo<UserSessionDTO> phoneLogin(@Valid @RequestBody UserLoginParamDTO paramDTO) throws Exception {
        String correctValidCode = testConfig.getValidCode();
        if (!testConfig.getPhone().contains(paramDTO.getPhone())) {
            correctValidCode = validCodeCache.getValidCode(paramDTO.getPhone());
        }
        if (!paramDTO.getValidCode().equals(correctValidCode)) {
            return ErrorEnum.VALID_CODE_ERROR.result();
        }

        String lockKey = "Lock:UserLogin:" + paramDTO.getPhone();
        boolean locked = RemoteLock.lock(lockKey, 0);
        if (!locked) {
            return ResultInfo.manyRequest();
        }
        try {
            // 获取用户
            User user = userService.getByPhone(paramDTO.getPhone());
            if (user == null) {
                // 创建用户
                user = new User();
                user.setId(IDUtils.nextId());
                user.setNickName("手机用户");
                user.setHeadimgUrl(vaxConfig.getAvatarUrl());
                user.setPhone(paramDTO.getPhone());
                user.setApp(paramDTO.getApp());
                user.setSecret(RandomStringUtils.randomAlphanumeric(16));
                user.setStatus(Constants.OK);
                user.setCreateTime(new Date());
                userService.save(user);

                // 推广邀请处理
                if (paramDTO.getInviterId() != null) {
                    User inviter = userService.getById(paramDTO.getInviterId());
                    if (inviter != null) {
                        Invite invite = new Invite();
                        invite.setInviterId(inviter.getId());
                        invite.setInviteeId(user.getId());
                        invite.setCreateTime(new Date());
                        inviteService.save(invite);
                    }
                }
            } else {
                user.setSecret(RandomStringUtils.randomAlphanumeric(16));
                user.setUpdateTime(new Date());
                userService.updateById(user);
            }

            if (user.getStatus().intValue() == Constants.NO) {
                return ErrorEnum.USER_DISABLE.result();
            }

            UserSessionDTO sessionDTO = sessionHelper.createUserSession(user, AppEnum.EXTRACT);
            return ResultInfo.success().setData(sessionDTO);
        } finally {
            RemoteLock.unlock(lockKey);
        }
    }

    /**
     * 刷新令牌
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/user/refreshToken")
    public ResultInfo<UserSessionDTO> refreshToken(@Valid @RequestBody UserRefreshTokenParamDTO paramDTO) throws Exception {
        TokenUtils.AppUser appUser = TokenUtils.parse(paramDTO.getAccessToken());
        if (appUser == null) {
            return ResultInfo.badRequest();
        }
        String secret = sessionHelper.decrypt(paramDTO.getRefreshToken(), paramDTO.getAccessToken());
        User user = userService.getById(appUser.getUserId());
        if (user == null || !user.getSecret().equals(secret)) {
            return ResultInfo.badRequest();
        }
        if (user.getStatus().intValue() == Constants.NO) {
            return ErrorEnum.USER_DISABLE.result();
        }
        UserSessionDTO userSessionDTO = sessionHelper.createUserSession(user, AppEnum.EXTRACT);
        return ResultInfo.success().setData(userSessionDTO);
    }

    /**
     * 更新手机号数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/user/updatePhone")
    public ResultInfo<String> updatePhone(@Valid @RequestBody UserUpdatePhoneParamDTO paramDTO) {
        String validCode = validCodeCache.getValidCode(paramDTO.getPhone());
        if (!paramDTO.getValidCode().equals(validCode)) {
            return ErrorEnum.VALID_CODE_ERROR.result();
        }
        User user = userService.getById(SessionContext.getUserId());
        if (user == null) {
            return ResultInfo.badRequest();
        }
        user.setPhone(paramDTO.getPhone());
        userService.updateById(user);
        return ResultInfo.success();
    }
}