package com.cloud.common.exception;

/**
 * 参数异常
 */
public class ParameterException extends RuntimeException {

    public ParameterException(String message) {
        super(message);
    }

}
