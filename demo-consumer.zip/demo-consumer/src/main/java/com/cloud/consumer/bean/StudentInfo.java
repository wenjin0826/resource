package com.cloud.consumer.bean;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

@Data
public class StudentInfo {

    @ExcelProperty("编号")
    private String id;

    @ExcelProperty("姓名")
    private String name;

    @ExcelProperty("性别")
    private String sex;

    @ExcelProperty("年龄")
    private String age;
}
