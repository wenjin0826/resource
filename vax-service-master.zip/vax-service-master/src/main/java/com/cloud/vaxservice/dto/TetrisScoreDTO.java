package com.cloud.vaxservice.dto;

import lombok.Data;

import java.util.Date;

/**
 * 俄罗斯方块分数对象
 *
 * @author feng
 * @since 2022/09/21
 */
@Data
public class TetrisScoreDTO {
    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户IP
     */
    private String userIp;

    /**
     * 用户昵称
     */
    private String nickName;

    /**
     * 头像地址
     */
    private String headimgUrl;

    /**
     * 游戏最高分
     */
    private Integer gameScore;

    /**
     * 奖励级别
     */
    private Integer rewardLevel;

    /**
     * 奖励级别描述
     */
    private String rewardLevelDesc;

    /**
     * 更新时间
     */
    private Date updateTime;
}
