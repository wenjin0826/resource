package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 转录实体类
 *
 * @author feng
 * @since 2021-12-31
 */
@Data
@TableName("t_transcribe")
public class Transcribe implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 语言
     */
    @TableField("language")
    private String language;

    /**
     * 提供商
     */
    @TableField("provider")
    private String provider;

    /**
     * 任务ID
     */
    @TableField("task_id")
    private String taskId;

    /**
     * 任务标题
     */
    @TableField("task_title")
    private String taskTitle;

    /**
     * 任务状态
     */
    @TableField("task_status")
    private String taskStatus;

    /**
     * 转录的文案结果
     */
    @TableField("task_result")
    private String taskResult;

    /**
     * 音频地址
     */
    @TableField("audio_url")
    private String audioUrl;

    /**
     * 音频时长，单位秒
     */
    @TableField("audio_duration")
    private Long audioDuration;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String USER_ID = "user_id";
    public static final String LANGUAGE = "language";
    public static final String PROVIDER = "provider";
    public static final String TASK_ID = "task_id";
    public static final String TASK_TITLE = "task_title";
    public static final String TASK_STATUS = "task_status";
    public static final String TASK_RESULT = "task_result";
    public static final String AUDIO_URL = "audio_url";
    public static final String AUDIO_DURATION = "audio_duration";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}