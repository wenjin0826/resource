package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.Parameter;

/**
 * 参数服务接口
 *
 * @author feng
 * @since 2024/03/14
 */
public interface ParameterService extends IService<Parameter> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Parameter> query(ParameterQueryParamDTO paramDTO);

    Parameter getByKey(String key);
}
