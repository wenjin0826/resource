package com.cloud.vaxservice.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class VerifyCodeCache {

    private static final String VERIFY_CODE_KEY_PREFIX = "VerifyCode:";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public String getCode(String key) {
        String cacheKey = VERIFY_CODE_KEY_PREFIX + key;
        return (String) redisTemplate.opsForValue().get(cacheKey);
    }

    public void saveCode(String key, String code) {
        String cacheKey = VERIFY_CODE_KEY_PREFIX + key;
        redisTemplate.opsForValue().set(cacheKey, code, 5, TimeUnit.MINUTES);
    }
}
