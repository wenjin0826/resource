package com.cloud.consumer.provider;

import com.cloud.common.bean.Message;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.feign.FeignInvoke;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "cloud-message")
public interface MessageProvider {

    @FeignInvoke(rpc = true)
    @PostMapping("/message/send")
    ResultInfo<String> send(@RequestBody Message message);
}
