package com.cloud.vaxservice.controller;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.context.SessionContext;
import com.cloud.common.support.ListMapper;
import com.cloud.vaxservice.dto.InviteDTO;
import com.cloud.vaxservice.dto.InviteQueryParamDTO;
import com.cloud.vaxservice.entity.Invite;
import com.cloud.vaxservice.entity.User;
import com.cloud.vaxservice.service.InviteService;
import com.cloud.vaxservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 邀请接口
 *
 * @author feng
 * @since 2022/09/24
 */
@Slf4j
@RestController
public class InviteController {
    @Autowired
    private InviteService inviteService;

    @Autowired
    private UserService userService;

    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/invite/query")
    public ResultInfo<PageInfo<InviteDTO>> query(@Valid @RequestBody InviteQueryParamDTO paramDTO) {
        paramDTO.setInviterId(SessionContext.getUserId());
        PageInfo<Invite> pageInfo = inviteService.query(paramDTO);
        List<Invite> rows = pageInfo.getRows();
        List<InviteDTO> inviteList = new ArrayList<>(rows.size());
        if (CollectionUtils.isNotEmpty(rows)) {
            List<Long> ids = rows.stream().map(Invite::getInviteeId).collect(Collectors.toList());
            List<User> userList = userService.listByIds(ids);
            ListMapper<User> userListMapper = new ListMapper<>(userList, User::getId);
            for (Invite invite : pageInfo.getRows()) {
                User user = userListMapper.get(invite.getInviteeId());
                if (user != null) {
                    InviteDTO inviteDTO = new InviteDTO();
                    inviteDTO.setInviteeId(invite.getInviteeId());
                    inviteDTO.setInviteeName(user.getNickName());
                    inviteDTO.setInviteeHeadimgUrl(user.getHeadimgUrl());
                    inviteDTO.setCreateTime(invite.getCreateTime());
                    inviteList.add(inviteDTO);
                }
            }
        }
        return ResultInfo.success().setData(pageInfo.build(inviteList));
    }
}
