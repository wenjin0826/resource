package com.cloud.vaxservice.provider.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 百度创建转写参数
 *
 * @author fengwenjin
 * @since 2021/9/2
 */
@NoArgsConstructor
@Data
public class BaiduCreateTranscribeParamDTO {
    @JsonProperty("speech_url")
    private String speechUrl;
    private String format;
    private Integer pid;
    private Integer rate;
}
