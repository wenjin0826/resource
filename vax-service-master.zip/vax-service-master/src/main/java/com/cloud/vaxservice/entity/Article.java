package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 文章实体类
 *
 * @author feng
 * @since 2022/09/20
 */
@Data
@TableName("t_article")
public class Article implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 置顶
     */
    @TableField("top")
    private Integer top;

    /**
     * 分类
     */
    @TableField("type")
    private Integer type;

    /**
     * 标题
     */
    @TableField("title")
    private String title;

    /**
     * 内容
     */
    @TableField("content")
    private String content;

    /**
     * 状态：1表示可用 0表示不可用
     */
    @TableField("status")
    private Integer status;

    /**
     * 图片地址
     */
    @TableField("img_url")
    private String imgUrl;

    /**
     * 分享地址：多个逗号分割
     */
    @TableField("share_url")
    private String shareUrl;

    /**
     * 打开地址
     */
    @TableField("open_url")
    private String openUrl;

    /**
     * 打开Appid
     */
    @TableField("open_appid")
    private String openAppid;

    /**
     * 阅读数
     */
    @TableField("view_count")
    private Integer viewCount;

    /**
     * 发布时间
     */
    @TableField("publish_time")
    private Date publishTime;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String TOP = "top";
    public static final String TYPE = "type";
    public static final String TITLE = "title";
    public static final String CONTENT = "content";
    public static final String STATUS = "status";
    public static final String IMG_URL = "img_url";
    public static final String SHARE_URL = "share_url";
    public static final String OPEN_URL = "open_url";
    public static final String OPEN_APPID = "open_appid";
    public static final String VIEW_COUNT = "view_count";
    public static final String PUBLISH_TIME = "publish_time";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}
