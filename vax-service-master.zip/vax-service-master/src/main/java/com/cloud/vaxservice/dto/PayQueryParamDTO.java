package com.cloud.vaxservice.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

/**
 * 支付查询参数
 *
 * @author feng
 * @since 2021-09-24
 */
@Data
public class PayQueryParamDTO {
    /**
     * 状态
     */
    private Integer status;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 页码（1~100之间）
     */
    @NotNull(message = "页码不能为空")
    @Range(min = 1, max = 100, message = "页码（1~100之间）")
    private Integer pageNo;

    /**
     * 分页大小（5~300之间）
     */
    @NotNull(message = "分页大小不能为空")
    @Range(min = 5, max = 300, message = "分页大小（5~300之间）")
    private Integer pageSize;
}