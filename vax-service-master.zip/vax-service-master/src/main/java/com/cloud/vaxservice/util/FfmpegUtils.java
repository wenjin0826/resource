package com.cloud.vaxservice.util;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

/**
 * ffmpeg辅助类
 *
 * @author fengwenjin
 * @since 2022/2/9
 */
@Slf4j
public class FfmpegUtils {
    public static File extractAudio(File videoFile) {
        try {
            String videoFilePath = videoFile.getAbsolutePath();
            String audioFilePath = videoFilePath.substring(0, videoFilePath.lastIndexOf(".")) + ".mp3";

            StringBuffer commandLine = new StringBuffer();
            commandLine.append("ffmpeg");
            commandLine.append(" -y -i ");
            commandLine.append(videoFilePath);
            commandLine.append(" -acodec libmp3lame ");
            commandLine.append(audioFilePath);

            Process process = Runtime.getRuntime().exec(commandLine.toString());
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while (true) {
                if (reader.readLine() == null) {
                    break;
                }
            }
            return new File(audioFilePath);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }
}
