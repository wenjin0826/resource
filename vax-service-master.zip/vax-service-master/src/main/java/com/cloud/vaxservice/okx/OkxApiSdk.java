package com.cloud.vaxservice.okx;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.vaxservice.okx.dto.CandleDataDTO;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * API SDK
 */
@Slf4j
public class OkxApiSdk {
    private static final String baseURL = "https://www.okx.com";
    private static OkHttpClient httpClient;
    static {
        httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .callTimeout(45, TimeUnit.SECONDS)
                .pingInterval(5, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();
    }

    public static List<CandleDataDTO> getCandleList(String instId, String bar, int limit) {
        try {
            String apiPath = "/api/v5/market/candles?instId=" + instId + "&bar=" + bar + "&limit=" + limit;
            Request.Builder requestBuilder = buildRequestBuilder(apiPath);
            Response response = httpClient.newCall(requestBuilder.build()).execute();
            if (response.code() == 200) {
                String responseText = response.body().string();
                JSONObject jsonObject = JSON.parseObject(responseText);
                JSONArray jsonArray = jsonObject.getJSONArray("data");
                List<CandleDataDTO> candleList = new ArrayList<>(limit);
                for (int i = 0, size = jsonArray.size(); i < size; i++) {
                    JSONArray array = jsonArray.getJSONArray(i);
                    CandleDataDTO candleData = new CandleDataDTO();
                    candleData.setTs(array.getString(0));
                    candleData.setOpen(array.getString(1));
                    candleData.setHigh(array.getString(2));
                    candleData.setLow(array.getString(3));
                    candleData.setClose(array.getString(4));
                    candleData.setVol(array.getString(5));
                    candleData.setVolCcy(array.getString(6));
                    candleData.setVolCcyQuote(array.getString(7));
                    candleData.setConfirm(array.getString(8));
                    candleList.add(candleData);
                }
                return candleList;
            }
        } catch (Exception e) {
            log.error("getCandleList error", e);
        }
        return null;
    }

    private static Request.Builder buildRequestBuilder(String apiPath) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        String timestamp = sdf.format(new Date()) + "Z";
        String sign = getSHA256Str(timestamp + "GET" + apiPath);

        Request.Builder requestBuilder = new Request.Builder();
        requestBuilder.header("OK-ACCESS-KEY", "bba2f7a5-61bd-4e68-9184-73847f5b5ca2");
        requestBuilder.header("OK-ACCESS-PASSPHRASE", "Wenjin$0826");
        requestBuilder.header("OK-ACCESS-TIMESTAMP", timestamp);
        requestBuilder.header("OK-ACCESS-SIGN", sign);
        requestBuilder.url(baseURL + apiPath);
        return requestBuilder;
    }

    public static String getSHA256Str(String str) {
        try {
            String secret = "887DEBFDE3F26B9806AA9D7FFB648CCB";
            SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes("UTF-8"), "HmacSHA256");
            Mac hmacSHA256 = Mac.getInstance("HmacSHA256");
            hmacSHA256.init(secretKey);
            byte[] hash = hmacSHA256.doFinal(str.getBytes("UTF-8"));
            return Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            log.error("getSHA256Str error", e);
        }
        return null;
    }
}
