package com.cloud.common.broadcast;

/**
 * 订阅消息处理
 *
 * @author fengwenjin
 */
public interface MessageHandler {
    void handle(BroadcastMessage message);
}
