package com.cloud.vaxservice.adapter;

import com.cloud.common.support.RemoteLock;
import com.cloud.common.util.JsonUtils;
import com.cloud.vaxservice.config.WechatConfig;
import com.cloud.vaxservice.constant.PayStatusEnum;
import com.cloud.vaxservice.constant.TradeTypeEnum;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.service.PaymentService;
import com.egzosn.pay.common.api.PayMessageHandler;
import com.egzosn.pay.common.api.PayService;
import com.egzosn.pay.common.bean.CertStoreType;
import com.egzosn.pay.common.bean.PayOrder;
import com.egzosn.pay.common.bean.PayOutMessage;
import com.egzosn.pay.common.bean.TransferOrder;
import com.egzosn.pay.common.bean.result.PayError;
import com.egzosn.pay.common.exception.PayErrorException;
import com.egzosn.pay.common.http.HttpConfigStorage;
import com.egzosn.pay.common.util.sign.SignUtils;
import com.egzosn.pay.wx.api.WxConst;
import com.egzosn.pay.wx.api.WxPayConfigStorage;
import com.egzosn.pay.wx.api.WxPayService;
import com.egzosn.pay.wx.bean.WxPayMessage;
import com.egzosn.pay.wx.bean.WxTransactionType;
import com.egzosn.pay.wx.bean.WxTransferType;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

@Slf4j
@Component
public class WxPayAdapter implements PayMessageHandler<WxPayMessage, PayService> {
    @Autowired
    private WechatConfig wechatConfig;

    @Autowired
    private PaymentService paymentService;

    private WxPayService wxPayService;

    private WxPayService sslWxPayService;

    public String getQrcode(String payTitle, Integer payMoney, String orderNo) {
        BigDecimal money = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100));
        PayOrder payOrder = new PayOrder(payTitle, "", money, orderNo, WxTransactionType.NATIVE);
        return wxPayService.getQrPay(payOrder);
    }

    public String orderInfo(int tradeType, String payTitle, Integer payMoney, String orderNo, String openid) {
        BigDecimal money = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100));
        WxTransactionType transactionType = TradeTypeEnum.of(tradeType) == TradeTypeEnum.APP ? WxTransactionType.APP : WxTransactionType.JSAPI;
        PayOrder payOrder = new PayOrder(payTitle, "", money, orderNo, transactionType);
        payOrder.setOpenid(openid);
        Map<String, Object> resultMap = wxPayService.orderInfo(payOrder);
        return JsonUtils.toJSONString(resultMap);
    }

    public boolean transfer(Integer payMoney, String orderNo, String openid, String remark) {
        BigDecimal money = BigDecimal.valueOf(payMoney).divide(BigDecimal.valueOf(100));
        TransferOrder transferOrder = new TransferOrder();
        transferOrder.setTransferType(WxTransferType.TRANSFERS);
        transferOrder.setAmount(money);
        transferOrder.setPayeeAccount(openid);
        transferOrder.setOutNo(orderNo);
        transferOrder.setRemark(remark);
        Map result = sslWxPayService.transfer(transferOrder);
        if (WxConst.SUCCESS.equals(result.get(WxConst.RETURN_CODE))
                && WxConst.SUCCESS.equals(result.get(WxConst.RESULT_CODE))) {
            return true;
        }
        log.error("wxPay transfer failure, result >>> " + JsonUtils.toJSONString(result));
        return false;
    }

    public PayOutMessage payBack(Map<String, String[]> parameterMap, InputStream input) {
        try {
            return wxPayService.payBack(parameterMap, input);
        } catch (PayErrorException e) {
            PayError payError = e.getPayError();
            if (payError != null && payError.getErrorCode().equals("XML failure")) {
                return null;
            }
            throw e;
        }
    }

    /**
     * 微信支付回调的处理
     *
     * @param wxPayMessage 支付消息
     * @param contextMap   上下文
     * @param payService   支付服务
     * @throws PayErrorException 支付错误异常
     */
    @Override
    public PayOutMessage handle(WxPayMessage wxPayMessage, Map<String, Object> contextMap, PayService payService) throws PayErrorException {
        log.info("wxPayNotify >>> {}", JsonUtils.toJSONString(wxPayMessage.getPayMessage()));
        PayOutMessage failureMessage = payService.getPayOutMessage(WxConst.FAILURE, WxConst.FAILURE);

        if (!WxConst.SUCCESS.equals(wxPayMessage.getPayMessage().get(WxConst.RETURN_CODE))) {
            return failureMessage;
        }
        String orderNo = wxPayMessage.getOutTradeNo();
        if (StringUtils.isEmpty(orderNo)) {
            return failureMessage;
        }

        String lockKey = "Lock:WxPayment:" + orderNo;
        if (!RemoteLock.lock(lockKey, 0)) {
            return failureMessage;
        }

        try {
            Payment payment = paymentService.getByOrderNo(orderNo);
            if (payment == null || payment.getPayStatus() != PayStatusEnum.UNDO.getCode()) {
                return failureMessage;
            }
            payment.setTradeNo(wxPayMessage.getTransactionId());
            payment.setUpdateTime(new Date());
            if (WxConst.SUCCESS.equals(wxPayMessage.getResultCode())) {
                payment.setPayStatus(PayStatusEnum.PAID.getCode());
                paymentService.handlePaid(payment);
            } else {
                payment.setPayStatus(PayStatusEnum.PAID_FAIL.getCode());
                paymentService.updateById(payment);
            }
            return payService.getPayOutMessage(WxConst.SUCCESS, "OK");
        } catch (Exception e) {
            log.error("wxpay notify handle error", e);
        } finally {
            RemoteLock.unlock(lockKey);
        }
        return failureMessage;
    }

    /**
     * 创建微信支付服务
     */
    @PostConstruct
    public void createWxPayService() {
        HttpConfigStorage httpConfigStorage = new HttpConfigStorage();
        httpConfigStorage.setMaxTotal(200);
        httpConfigStorage.setDefaultMaxPerRoute(100);

        wxPayService = new WxPayService(buildConfigStorage());
        wxPayService.setRequestTemplateConfigStorage(httpConfigStorage);
        wxPayService.setPayMessageHandler(this);
    }

    /**
     * 创建SSL微信支付服务，付款到零钱使用
     */
    @PostConstruct
    private void createSslWxPayService() {
        HttpConfigStorage sslHttpConfigStorage = new HttpConfigStorage();
        sslHttpConfigStorage.setMaxTotal(50);
        sslHttpConfigStorage.setDefaultMaxPerRoute(10);
        sslHttpConfigStorage.setKeystore(wechatConfig.getPayApiCertPath());
        sslHttpConfigStorage.setStorePassword(wechatConfig.getPayAccountId());
        sslHttpConfigStorage.setCertStoreType(CertStoreType.PATH);

        sslWxPayService = new WxPayService(buildConfigStorage());
        sslWxPayService.setRequestTemplateConfigStorage(sslHttpConfigStorage);
    }

    private WxPayConfigStorage buildConfigStorage() {
        WxPayConfigStorage wxPayConfigStorage = new WxPayConfigStorage();
        wxPayConfigStorage.setAppid(wechatConfig.getAppId());
        wxPayConfigStorage.setMchId(wechatConfig.getPayAccountId());
        wxPayConfigStorage.setSecretKey(wechatConfig.getPayApiSecretKey());
        wxPayConfigStorage.setNotifyUrl(wechatConfig.getPayNotifyUrl());
        wxPayConfigStorage.setSignType(SignUtils.MD5.name());
        wxPayConfigStorage.setInputCharset("utf-8");
        return wxPayConfigStorage;
    }
}
