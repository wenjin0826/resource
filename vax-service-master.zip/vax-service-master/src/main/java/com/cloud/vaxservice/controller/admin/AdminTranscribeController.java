package com.cloud.vaxservice.controller.admin;

import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.vaxservice.dto.TranscribeQueryParamDTO;
import com.cloud.vaxservice.entity.Transcribe;
import com.cloud.vaxservice.service.TranscribeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 转录接口
 *
 * @author feng
 * @since 2021-11-28
 */
@Slf4j
@RestController
public class AdminTranscribeController {
    @Autowired
    private TranscribeService transcribeService;

    /**
     * 分页查询
     *
     * @param paramDTO 参数对象
     * @return ResultInfo 响应结果
     */
    @PostMapping("/admin/transcribe/query")
    public ResultInfo<PageInfo<Transcribe>> query(@Valid @RequestBody TranscribeQueryParamDTO paramDTO) {
        PageInfo<Transcribe> pageInfo = transcribeService.query(paramDTO);
        return ResultInfo.success().setData(pageInfo);
    }
}