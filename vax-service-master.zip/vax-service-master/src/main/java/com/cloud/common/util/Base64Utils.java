package com.cloud.common.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * base64工具类
 *
 * @author fengwenjin
 */
public class Base64Utils {
    /**
     * 编码
     *
     * @param value
     * @return
     */
    public static String encode(String value) {
        byte[] encodeValue = Base64.getEncoder().encode(value.getBytes(StandardCharsets.UTF_8));
        return new String(encodeValue, StandardCharsets.UTF_8);
    }

    /**
     * 编码（支持URL）
     *
     * @param value
     * @return
     */
    public static String encodeUrlSafe(String value) {
        byte[] encodeValue = Base64.getUrlEncoder().encode(value.getBytes(StandardCharsets.UTF_8));
        return new String(encodeValue, StandardCharsets.UTF_8);
    }

    /**
     * 解码
     *
     * @param value
     * @return
     */
    public static String decode(String value) {
        byte[] decodeValue = Base64.getDecoder().decode(value);
        return new String(decodeValue, StandardCharsets.UTF_8);
    }

    /**
     * 解码（支持URL）
     *
     * @param value
     * @return
     */
    public static String decodeUrlSafe(String value) {
        byte[] decodeValue = Base64.getUrlDecoder().decode(value);
        return new String(decodeValue, StandardCharsets.UTF_8);
    }
}
