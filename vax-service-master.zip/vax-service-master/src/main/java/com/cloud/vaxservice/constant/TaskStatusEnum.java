package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum TaskStatusEnum {
    // 正在处理
    RUNNING(1, "正在处理"),
    // 处理完成
    FINISH(2, "处理完成"),
    // 处理失败
    FAILURE(3, "处理失败");

    @Getter
    private int code;

    @Getter
    private String description;

    TaskStatusEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static TaskStatusEnum of(int code) {
        for (TaskStatusEnum statusEnum : values()) {
            if (statusEnum.code == code) {
                return statusEnum;
            }
        }
        return null;
    }
}
