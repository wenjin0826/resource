package com.cloud.vaxservice.provider;

import com.cloud.common.util.UUIDUtils;
import com.tencent.SpeechClient;
import com.tencent.tts.model.SpeechSynthesisRequest;
import com.tencent.tts.model.SpeechSynthesisResponse;
import com.tencent.tts.service.SpeechSynthesisListener;
import com.tencent.tts.service.SpeechSynthesizer;
import com.tencent.tts.utils.PcmUtils;
import com.tencent.tts.utils.Ttsutils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TencentSpeechProvider {
    @Value("${tencent.appId}")
    private String appId;

    @Value("${tencent.secretId}")
    private String secretId;

    @Value("${tencent.secretKey}")
    private String secretKey;

    public void createTask() {
        // 创建SpeechSynthesizerClient实例，目前是单例
        SpeechClient client = SpeechClient.newInstance(appId, secretId, secretKey);
        // 初始化SpeechSynthesizerRequest，SpeechSynthesizerRequest包含请求参数
        SpeechSynthesisRequest request = SpeechSynthesisRequest.initialize();
        request.setSessionId(UUIDUtils.get());
        request.setCodec("pcm");
        request.setSampleRate(16000);
        request.setVolume(10);
        // request.setSpeed(2f);
        request.setVoiceType(101007);
        // 使用客户端client创建语音合成实例
        SpeechSynthesizer speechSynthesizer = client.newSpeechSynthesizer(request, new MySpeechSynthesizerListener(request));
        // 执行语音合成
        String ttsText = "这可能并不是一句玩笑话。1月12日，灰豚数据数据显示，程前的抖音大号“程前朋友圈”和个人小号“程前Jason”分别位居掉粉榜第7位和第12位，抖音累计掉粉超过5万。但对于更多的吃瓜群众而言，没细看热搜的时候，压根儿不知道程前是谁。难道是那位主持过《正大综艺》的主持人程前？程前在“程前朋友圈”里有一条发布于2022年7月的置顶内容，讲述了自己为什么能做商业访谈以及打算怎么做这件事。他毕业于英国伦敦大学量化金融专业，在上海陆家嘴做了五年金融，考察过很多企业，也作为主持人或翻译和很多企业家、专家有过交流，能够以“上帝视角”看待商业行为，于是他决定创业做“商业访谈”。程前确实把自己做成了抖音商业访谈头部博主，大小号加起来有近800万粉丝。2023年风马牛年终秀选择的是老少配，冯仑本人和两位同为商界大佬的朋友，搭配年轻的程前。“程前朋友圈”更是在特意打上“排名不分先后”的“特邀合作媒体”中排在首位，“吴晓波频道”紧随其后。冯仑也接受了程前朋友圈的访问，差不多是被访问者中咖位最大的一位。在此之前，程前采访过的多数仍是年轻的中小企业创业者。";
        speechSynthesizer.synthesis(ttsText);
    }

    public static class MySpeechSynthesizerListener extends SpeechSynthesisListener {
        private SpeechSynthesisRequest request;

        public MySpeechSynthesizerListener(SpeechSynthesisRequest request) {
            this.request = request;
        }

        @Override
        public void onComplete(SpeechSynthesisResponse response) {
            log.info("onComplete SessionId={} Success={} Code={} End={} Message={}", request.getSessionId(), response.getSuccess(), response.getCode(), response.getEnd(), response.getMessage());
            if (response.getSuccess()) {
                // pcm转wav
                Ttsutils.responsePcm2Wav(request.getSampleRate(), response.getAudio(), response.getSessionId());
                //获取返回包大小
                int rspLen = response.getAudio().length;
                //wav大小为pcm字节+44wav头大小
                byte[] wav = new byte[44 + rspLen];
                int bitNum = request.getSampleRate() == 16000 ? 16 : 8;
                PcmUtils.pcm2WavBytes(response.getAudio(), wav, request.getSampleRate(), 1, bitNum);
                Ttsutils.saveResponseToFile(wav,"D:\\Workspace\\" + request.getSessionId() + ".wav");
            }
        }

        @Override
        public void onMessage(byte[] data) {
            // 语音合成的语音二进制数据
            log.info("onMessage SessionId={} DataSize={}", request.getSessionId(), data.length);
        }

        @Override
        public void onFail(SpeechSynthesisResponse response) {
            log.warn("onFail SessionId={} Code={} Message={}", request.getSessionId(), response.getCode(), response.getMessage());
        }
    }
}
