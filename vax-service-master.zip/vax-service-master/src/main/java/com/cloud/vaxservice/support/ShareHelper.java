package com.cloud.vaxservice.support;

import com.cloud.common.context.RequestContext;
import com.cloud.common.context.SessionContext;
import com.cloud.vaxservice.config.ShareConfig;
import com.cloud.vaxservice.entity.Article;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 分享辅助类
 *
 * @author fengwenjin
 * @since 2022/6/12
 */
@Slf4j
@Component
public class ShareHelper {
    private static final String SEPERATOR = "S";
    private static int shareIndex = 0;

    @Autowired
    private ShareConfig shareConfig;

    public String getShareUrl(Article article) {
        shareIndex = shareIndex++ > 10000 ? 0 : shareIndex;
        String shareUrl = article.getShareUrl();
        if (StringUtils.isEmpty(shareUrl)) {
            String idCode = encode(article.getId());
            List<String> shareDomains = shareConfig.getShareDomains();
            int index = shareIndex % shareDomains.size();
            shareUrl = shareDomains.get(index) + RequestContext.getRequest().getContextPath() + "/share/open/" + idCode;
        } else {
            String[] urls = shareUrl.split(",");
            int index = shareIndex % urls.length;
            shareUrl = urls[index];
        }
        shareUrl = shareUrl + "?uid=" + SessionContext.getUserId();
        return shareUrl;
    }

    public String getProxyUrl(String idCode) {
        List<String> proxyDomains = shareConfig.getProxyDomains();
        int index = RandomUtils.nextInt(1, 100) % proxyDomains.size();
        return proxyDomains.get(index) + RequestContext.getRequest().getContextPath() + "/share/proxy/" + idCode;
    }

    public String getViewUrl(String idCode) {
        List<String> viewDomains = shareConfig.getViewDomains();
        int index = RandomUtils.nextInt(1, 100) % viewDomains.size();
        return viewDomains.get(index) + RequestContext.getRequest().getContextPath() + "/share/view/" + idCode;
    }

    public String encode(Integer articleId) {
        return System.currentTimeMillis() + SEPERATOR + + articleId;
    }

    public Integer decode(String idCode) {
        try {
            String[] arr = idCode.split(SEPERATOR);
            if (arr.length != 2) {
                return 0;
            }
            return Integer.parseInt(arr[1]);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return 0;
    }
}
