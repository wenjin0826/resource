package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum PayStatusEnum {

    UNDO(0, "未支付"),
    PAID(1, "已支付"),
    PAID_FAIL(2,"支付失败");

    @Getter
    private int code;

    @Getter
    private String description;

    PayStatusEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public static PayStatusEnum of(int code) {
        for (PayStatusEnum statusEnum : values()) {
            if (statusEnum.code == code) {
                return statusEnum;
            }
        }
        return null;
    }

}
