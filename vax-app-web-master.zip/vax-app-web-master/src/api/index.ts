// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as verifyCodeController from "./verifyCodeController";
import * as transcribeController from "./transcribeController";
import * as paypalController from "./paypalController";
import * as appUserController from "./appUserController";
import * as aliPayController from "./aliPayController";
import * as fileController from "./fileController";
export default {
  verifyCodeController,
  transcribeController,
  paypalController,
  appUserController,
  aliPayController,
  fileController,
};
