// @ts-ignore
/* eslint-disable */
import request from "@/commons/request";

/** 此处后端没有提供注释 POST /transcribe/create */
export async function createTranscribe(
  body: API.TranscribeCreateParamDTO,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoTranscribeCreateResultDTO>(
    "/transcribe/create",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      data: body,
      ...(options || {}),
    }
  );
}

/** 此处后端没有提供注释 POST /transcribe/delete */
export async function deleteTranscribe(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteTranscribeParams,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoString>("/transcribe/delete", {
    method: "POST",
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /transcribe/getViewUrl */
export async function getTranscribeViewUrl(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getTranscribeViewUrlParams,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoString>("/transcribe/getViewUrl", {
    method: "POST",
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 POST /transcribe/query */
export async function queryTranscribe(
  body: API.TranscribeQueryParamDTO,
  options?: { [key: string]: any }
) {
  return request<API.ResultInfoPageInfoTranscribe>("/transcribe/query", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}
