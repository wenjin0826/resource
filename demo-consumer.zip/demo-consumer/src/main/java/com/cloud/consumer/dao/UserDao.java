package com.cloud.consumer.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.consumer.entity.User;

/**
 * <p>
 * 用户 Mapper 接口
 * </p>
 *
 * @author fengwenjin
 * @since 2019-02-16
 */
public interface UserDao extends BaseMapper<User> {

}
