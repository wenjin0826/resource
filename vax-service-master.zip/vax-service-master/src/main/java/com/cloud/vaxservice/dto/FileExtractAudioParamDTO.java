package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 文件提取音频参数
 *
 * @author feng
 * @since 2022-02-09
 */
@Data
public class FileExtractAudioParamDTO {
    /**
     * 视频文件路径
     */
    @NotEmpty(message = "视频文件路径不能为空")
    private String videoFilePath;

    /**
     * 手机信息
     */
    @NotEmpty(message = "手机信息不能为空")
    private String mobileInfo;
}