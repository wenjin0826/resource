package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * 用户新增参数
 *
 * @author feng
 * @since 2021-09-02
 */
@Data
public class UserInsertParamDTO {
    /**
     * 姓名
     */
    @NotEmpty(message = "姓名不能为空")
    private String name;

    /**
     * 手机号
     */
    @NotEmpty(message = "手机号不能为空")
    private String phone;
}