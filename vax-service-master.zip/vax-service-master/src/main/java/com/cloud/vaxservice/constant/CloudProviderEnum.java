package com.cloud.vaxservice.constant;

public enum CloudProviderEnum {
    TENCENT,
    BAIDU
}
