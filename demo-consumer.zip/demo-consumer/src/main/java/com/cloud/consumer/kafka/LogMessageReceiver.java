package com.cloud.consumer.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class LogMessageReceiver implements MessageListener<String, String> {

    @Override
    @KafkaListener(topics = "AmsLog")
    public void onMessage(ConsumerRecord<String, String> record) {
        String result = record.value();
        log.info("message >>> {}", result);
    }

}
