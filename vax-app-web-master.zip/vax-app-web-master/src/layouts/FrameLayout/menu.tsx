"use client";
import {MenuDataItem} from "@ant-design/pro-layout";
import {getText} from "@/commons/locale";

// 菜单列表
export const menus = [
  {
    path: "/transcribe",
    name: `${getText("speech_to_text")}`,
  },
  {
    path: "/crypto",
    name: `${getText("crypto_monitoring")}`,
  },
] as MenuDataItem[];



