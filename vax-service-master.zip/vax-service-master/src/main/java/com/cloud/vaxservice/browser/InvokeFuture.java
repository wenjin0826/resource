package com.cloud.vaxservice.browser;

import lombok.Data;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * 异步结果
 *
 * @author fengwenjin
 */
@Data
public class InvokeFuture<V> implements Future {
	V result;
	int timeout;
	HttpRequest request;
	CountDownLatch latch;

	public InvokeFuture(int timeout, HttpRequest request) {
		this.timeout = timeout;
		this.request = request;
		this.latch = new CountDownLatch(1);
	}

	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		return false;
	}

	@Override
	public boolean isCancelled() {
		return false;
	}

	@Override
	public boolean isDone() {
		return latch.getCount() <= 0;
	}

	@Override
	public V get() throws InterruptedException {
		return get(timeout, TimeUnit.MILLISECONDS);
	}

	@Override
	public V get(long timeout, TimeUnit unit) throws InterruptedException {
		if (!isDone()) {
			latch.await(timeout, unit);
		}
		return result;
	}

	public void setResult(V result) {
		this.result = result;
		latch.countDown();
	}
}
