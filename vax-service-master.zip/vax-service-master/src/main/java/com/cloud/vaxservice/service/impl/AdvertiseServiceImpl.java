package com.cloud.vaxservice.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.constant.Constants;
import com.cloud.vaxservice.dao.AdvertiseDao;
import com.cloud.vaxservice.dto.AdvertiseQueryParamDTO;
import com.cloud.vaxservice.entity.Advertise;
import com.cloud.vaxservice.service.AdvertiseService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 广告服务实现类
 *
 * @author feng
 * @since 2022/06/13
 */
@Slf4j
@Service
public class AdvertiseServiceImpl extends ServiceImpl<AdvertiseDao, Advertise> implements AdvertiseService {
    @Override
    public PageInfo<Advertise> query(AdvertiseQueryParamDTO paramDTO) {
        QueryWrapper<Advertise> wrapper = new QueryWrapper<>();
        if (StringUtils.isNotEmpty(paramDTO.getTitle())) {
            wrapper.like(Advertise.TITLE, paramDTO.getTitle());
        }
        wrapper.orderByDesc(Advertise.SORT_INDEX);
        wrapper.orderByDesc(Advertise.ID);
        IPage page = page(new Page(paramDTO.getPageNo(), paramDTO.getPageSize()), wrapper);
        return new PageInfo(page);
    }

    @Override
    public List<Advertise> getEnableList() {
        QueryWrapper<Advertise> wrapper = new QueryWrapper<>();
        wrapper.eq(Advertise.STATUS, Constants.OK);
        wrapper.orderByDesc(Advertise.SORT_INDEX);
        wrapper.orderByDesc(Advertise.ID);
        return list(wrapper);
    }
}