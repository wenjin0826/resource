package com.cloud.common.rpc;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class ResponseFutureManager {

	private static LinkedHashMap<Integer, ResponseFuture> futureMap = new LinkedHashMap(5000);

	public synchronized static void add(ResponseFuture future) {
		futureMap.put(future.sequence, future);
	}

	public synchronized static ResponseFuture remove(Integer sequence) {
		return futureMap.remove(sequence);
	}

	public synchronized static void clean() {
		Iterator<Map.Entry<Integer, ResponseFuture>> iterator = futureMap.entrySet().iterator();
		while (iterator.hasNext()) {
			ResponseFuture future = iterator.next().getValue();
			if (future == null || future.invalidTime > System.currentTimeMillis()) {
				break;
			}
			iterator.remove();
		}
	}

}
