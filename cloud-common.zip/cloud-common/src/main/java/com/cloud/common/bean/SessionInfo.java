package com.cloud.common.bean;

import com.cloud.common.util.JsonUtils;
import lombok.Data;

import java.util.Set;

@Data
public class SessionInfo {

    private String secret;
    private String userId;
    private String userArea;
    private String userName;
    private String fullName;
    private String roleName;
    private Object otherInfo;
    private Set<String> whitelistIps;
    private Set<String> authResources;
    private boolean traced;

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId.toString();
    }

    public Long getUserIdForLong() {
        if (this.userId != null) {
            return Long.parseLong(userId);
        }
        return null;
    }

    public <T> T getOtherInfo(Class<T> clazz) {
        if (this.otherInfo != null) {
            return JsonUtils.parseObject(otherInfo.toString(), clazz);
        }
        return null;
    }

    public void setOtherInfo(Object otherInfo) {
        if (otherInfo instanceof String) {
            this.otherInfo = otherInfo;
        } else {
            this.otherInfo = JsonUtils.toJSONString(otherInfo);
        }
    }

}
