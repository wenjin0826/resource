package com.cloud.vaxservice.constant;

import lombok.Getter;

/**
 * RSA公钥和私钥
 *
 * @author fengwenjin
 * @since 2021/11/7
 */
public enum RSAKeyEnum {
    PUBLIC_KEY("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCRRAwSBAAELnm2KlPhYVlscfP5G7fCEX0BwK5L2aNKq2msOtl+BrvV1zUlKeUtgnw7NshrhUy2kP3l7oH7xJfqGMi+877CXgyduXMmWIQOTeQSwn5vd/nvvZcEbf+sMnvT52bnSjaBsBIUeS9RIKK5OQobNTQyuccundGuYDcYpwIDAQAB"),
    PRIVATE_KEY("MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAJFEDBIEAAQuebYqU+FhWWxx8/kbt8IRfQHArkvZo0qraaw62X4Gu9XXNSUp5S2CfDs2yGuFTLaQ/eXugfvEl+oYyL7zvsJeDJ25cyZYhA5N5BLCfm93+e+9lwRt/6wye9PnZudKNoGwEhR5L1Egork5Chs1NDK5xy6d0a5gNxinAgMBAAECgYAzWuwtfk6HK+sJdKNc3W6gwRRwb9Uh/c7EzNqRpCpvXnQoWFHFlRnYupFmRw5nbWcABBkMsf5x2IZ6QDyhxlmx9zE1B/OrN3Pl0GVYMLLks1nskDB39lJmlyVO4yM85+Y4rDSvGtqxPhSAnUGE6kIXUjdx4YJ9PSVf/hU7wAyvEQJBANDrbQ2dm/BcYd056Bd/dLNmwjdEd2rqSSmEXWsl0ZtueEu3IRtbUlWKtqKlRKUp/DzimXw54dKIGiw1h6Swg58CQQCyAG6Uvnp9Y1x8RSt966V6jN928I5bMoi9SaTlU3YeI4ypfoYzsrA8C/X9JNMgzSuP/BqthADjgUY82Om3KA35AkAURkSXBayUbuKwbWYwoZXZsyc15dcQ8RuYg9ftBgaJZvcVoff8h6g91PBUaGV5AdIQtozemV9o5vxjPe6j9N1RAkAVvI3EZjpJA5AwsLWt68/KVleXi6qmolYmX07enkGHTqoHrKawu3pf6soAPrX1hHh0XcHYPI1rOscb+RUZQ6/pAkAPEm8+2XW06u9k3YJiIsunjoSlF6cU12Q87QdpghKKWGzIqSIJXHcIeyhs8DqVOceZNT+KUgkWtNGXdkDxDIdp");

    @Getter
    private String value;

    RSAKeyEnum(String value) {
        this.value = value;
    }
}
