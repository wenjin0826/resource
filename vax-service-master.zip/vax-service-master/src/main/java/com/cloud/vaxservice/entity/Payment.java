package com.cloud.vaxservice.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 付款单
 * </p>
 *
 * @author feng
 * @since 2021-09-25
 */
@Data
@TableName("t_payment")
public class Payment implements Serializable {

    private static final long serialVersionUID=1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 来源的APP
     */
    @TableField("app")
    private Integer app;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Long userId;

    /**
     * 订单号
     */
    @TableField("order_no")
    private String orderNo;

    /**
     * 交易号
     */
    @TableField("trade_no")
    private String tradeNo;

    /**
     * 交易类型：1表示扫码支付，2表示JSAPI支付，3表示APP支付
     */
    @TableField("trade_type")
    private Integer tradeType;

    /**
     * 支付渠道：1表示微信，2表示支付宝
     */
    @TableField("pay_channel")
    private Integer payChannel;

    /**
     * 支付金额（单位为分）
     */
    @TableField("pay_money")
    private Integer payMoney;

    /**
     * 支付标题
     */
    @TableField("pay_title")
    private String payTitle;

    /**
     * 支付状态：0表示未支付，1表示支付成功，2表示支付失败
     */
    @TableField("pay_status")
    private Integer payStatus;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField("update_time")
    private Date updateTime;


    public static final String ID = "id";
    public static final String APP = "app";
    public static final String USER_ID = "user_id";
    public static final String ORDER_NO = "order_no";
    public static final String TRADE_NO = "trade_no";
    public static final String TRADE_TYPE = "trade_type";
    public static final String PAY_CHANNEL = "pay_channel";
    public static final String PAY_MONEY = "pay_money";
    public static final String PAY_TITLE = "pay_title";
    public static final String PAY_STATUS = "pay_status";
    public static final String CREATE_TIME = "create_time";
    public static final String UPDATE_TIME = "update_time";
}
