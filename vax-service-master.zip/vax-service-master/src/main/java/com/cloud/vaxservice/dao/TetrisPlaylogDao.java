package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.TetrisPlaylog;

/**
 * 俄罗斯方块游戏日志数据访问
 *
 * @author feng
 * @since 2022/09/23
 */
public interface TetrisPlaylogDao extends BaseMapper<TetrisPlaylog> {
}
