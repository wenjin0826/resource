export default function Home() {
    console.log("Home page");
    return (
        <></>
    )
}
