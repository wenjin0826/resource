package com.cloud.consumer.dto;

import lombok.Data;

@Data
public class WebsocketMsgDTO {

    private Long senderId;
    private Long receiverId;
    private String data;

}
