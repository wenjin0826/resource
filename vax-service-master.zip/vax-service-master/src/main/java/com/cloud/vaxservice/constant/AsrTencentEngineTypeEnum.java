package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum AsrTencentEngineTypeEnum {
    // 中文
    ZH_CN("16k_zh"),
    // 英文
    EN_US("16k_en");

    @Getter
    private String code;

    AsrTencentEngineTypeEnum(String code) {
        this.code = code;
    }
}
