package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.vaxservice.entity.Subscription;

/**
 * 订阅服务接口
 *
 * @author makejava
 * @since 2024/11/26
 */
public interface SubscriptionService extends IService<Subscription> {
    /**
     * 查询用户订阅
     *
     * @param userId 用户ID
     * @param product 产品
     * @return 订阅信息
     */
    Subscription getSubscription(Long userId, String product);
}
