package com.cloud.vaxservice.dto;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 微信小程序用户新增参数
 *
 * @author feng
 * @since 2022/09/19
 */
@Data
public class SecretLoginParamDTO {
    /**
     * 用户ID
     */
    @NotNull(message = "用户ID不能为空")
    private Long userId;

    /**
     * 秘钥
     */
    @NotEmpty(message = "秘钥不能为空")
    private String secret;
}
