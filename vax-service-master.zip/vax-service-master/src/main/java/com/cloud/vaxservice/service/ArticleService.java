package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.dto.*;
import com.cloud.vaxservice.entity.Article;

/**
 * 文章服务接口
 *
 * @author feng
 * @since 2021-09-24
 */
public interface ArticleService extends IService<Article> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Article> query(ArticleQueryParamDTO paramDTO);

    /**
     * 获取今天最新一条
     *
     * @return
     */
    Article getTodayLatest();
}