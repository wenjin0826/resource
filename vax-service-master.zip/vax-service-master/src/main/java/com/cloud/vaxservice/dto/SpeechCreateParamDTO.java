package com.cloud.vaxservice.dto;

import lombok.Data;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/**
 * 配音新增参数
 *
 * @author feng
 * @since 2023-09-02
 */
@Data
public class SpeechCreateParamDTO {
    @NotEmpty(message = "配音内容不能为空")
    private String speechText;

    @NotNull(message = "音色不能为空")
    private Integer voiceType;

    private Integer voiceVolume = 0;

    private Float voiceSpeed = 0F;
}