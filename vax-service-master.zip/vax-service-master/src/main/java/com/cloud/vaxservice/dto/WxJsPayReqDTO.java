package com.cloud.vaxservice.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

/**
 * 微信JSAPI支付请求DTO
 *
 * @author fengwenjin
 * @since 2021/11/22
 */
@Data
public class WxJsPayReqDTO {
    @JsonAlias("appId")
    private String appId;

    @JsonAlias("nonceStr")
    private String nonceStr;

    @JsonAlias("timeStamp")
    private String timeStamp;

    @JsonAlias("package")
    private String packageValue;

    @JsonAlias("signType")
    private String signType;

    @JsonAlias("sign")
    private String sign;
}
