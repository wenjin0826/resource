// @ts-ignore
import CryptoJS from "crypto-js";
import LoginUser = Model.LoginUser;

export const BASE_PATH = "";
export const REQUEST_TIMEOUT = 30000;
export const SUCCESS_CODE = 200;

export function saveToken(token: string) {
    localStorage.setItem("token", token);
}

export function getToken(): string {
    // @ts-ignore
    let token: string = localStorage.getItem("token");
    return token;
}

export function removeToken() {
    localStorage.removeItem("token");
}

export function saveLoginUser(loginUser: LoginUser) {
    let loginUserStr = JSON.stringify(loginUser);
    localStorage.setItem("loginUser", loginUserStr);
}

export function getLoginUser(): LoginUser {
    let loginUserStr = localStorage.getItem("loginUser");
    if (loginUserStr == null) {
        // @ts-ignore
        return null;
    }
    return JSON.parse(loginUserStr);
}

export function removeLoginUser() {
    localStorage.removeItem("loginUser");
}

export function randomString(length: number): string {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charactersLength);
        result += characters[randomIndex];
    }
    return result;
}

const AES_KEY = CryptoJS.enc.Base64.parse('OWZhMmQzZGNzZmNiOGRiOQ==').toString(CryptoJS.enc.Utf8);
export function aesEncrypt(word: any) {
    var key = CryptoJS.enc.Utf8.parse(AES_KEY);
    var data = CryptoJS.enc.Utf8.parse(word);
    var encrypted = CryptoJS.AES.encrypt(data, key, {mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7});
    return encrypted.toString();
}

export function aesDecrypt(word: any) {
    var key = CryptoJS.enc.Utf8.parse(AES_KEY);
    var decrypted = CryptoJS.AES.decrypt(word, key, {mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7});
    return CryptoJS.enc.Utf8.stringify(decrypted).toString();
}

export function md5Encrypt(word: any) {
    return CryptoJS.MD5(word).toString();
}