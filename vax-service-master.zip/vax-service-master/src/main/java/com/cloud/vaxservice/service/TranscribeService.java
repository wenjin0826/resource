package com.cloud.vaxservice.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.bean.PageInfo;
import com.cloud.vaxservice.constant.StatusEnum;
import com.cloud.vaxservice.dto.TranscribeQueryParamDTO;
import com.cloud.vaxservice.entity.Transcribe;

import java.util.Date;
import java.util.List;

/**
 * 转录任务服务接口
 *
 * @author feng
 * @since 2021-09-02
 */
public interface TranscribeService extends IService<Transcribe> {
    /**
     * 根据条件分页查询
     *
     * @param paramDTO 参数对象
     * @return PageInfo 分页结果
     */
    PageInfo<Transcribe> query(TranscribeQueryParamDTO paramDTO);

    /**
     * 根据任务ID查询
     *
     * @param taskId
     * @return Transcribe
     */
    Transcribe getByTaskId(String taskId);

    /**
     * 根据任务ID批量查询
     *
     * @param taskIds
     * @return List<Transcribe>
     */
    List<Transcribe> getByTaskIds(List<String> taskIds);

    /**
     * 获取运行中的转写
     *
     * @return List<Transcribe>
     */
    List<Transcribe> getRunnings();

    /**
     * 更新结果
     *
     * @param statusEnum
     * @param transcribe
     */
    void updateResult(StatusEnum statusEnum, Transcribe transcribe);

    /**
     * 清除过期
     *
     * @param dateTime
     */
    void cleanExpired(Date dateTime);

    /**
     * 获取今日免费转录的次数
     *
     * @param userId
     * @return int
     */
    int getTodayFreeCount(Long userId);

    /**
     * 是否存在正在运行的转录
     *
     * @param userId
     * @return boolean
     */
    boolean existRunning(Long userId);
}