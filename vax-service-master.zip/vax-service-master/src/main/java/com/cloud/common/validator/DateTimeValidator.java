package com.cloud.common.validator;

import com.cloud.common.util.DateTimeUtils;
import org.apache.commons.lang3.StringUtils;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * 日期时间格式校验逻辑
 *
 * @author fengwenjin
 */
public class DateTimeValidator implements ConstraintValidator<DateCheck, String> {
    private DateCheck annotation;

    @Override
    public void initialize(DateCheck constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isEmpty(value)) {
            return true;
        }
        return DateTimeUtils.checkDateFormat(value, annotation.format());
    }
}
