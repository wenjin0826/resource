package com.cloud.common.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.apache.commons.codec.binary.Base64;
import org.springframework.data.util.Pair;
import org.springframework.util.StringUtils;

import java.nio.ByteBuffer;
import java.util.Date;

/**
 * JWT令牌工具类
 */
public class TokenUtils {

    /**
     * 分割符
     */
    private static final String TOKEN_SEPARATOR = ".";
    private static final String VALUE_SEPARATOR = "@";

    private static final String JWT_HEADER = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9";
    private static final String USER = "user";

    /**
     * 构建令牌
     *
     * @param appName
     * @param userId
     * @param secret
     * @param timeoutSeconds
     * @return
     */
    public static String build(String appName, String userId, String secret, long timeoutSeconds) {
        String value = appName + VALUE_SEPARATOR + userId;
        String token = buildToken(value, secret, timeoutSeconds);
        String[] arr = token.split("\\" + TOKEN_SEPARATOR);
        token = buildSecret(secret) + TOKEN_SEPARATOR + arr[1] + TOKEN_SEPARATOR + arr[2];
        return token;
    }

    /**
     * 解析令牌
     *
     * @param token
     * @return
     */
    public static Pair<String, String> parse(String token) {
        if (StringUtils.isEmpty(token)) {
            return null;
        }
        try {
            String secret = getSecret(token);
            String[] arr = token.split("\\" + TOKEN_SEPARATOR);
            token = JWT_HEADER + TOKEN_SEPARATOR + arr[1] + TOKEN_SEPARATOR + arr[2];
            String value = parseToken(token, secret);
            String[] values = value.split(VALUE_SEPARATOR);
            if (values.length == 2) {
                return Pair.of(values[0], values[1]);
            }
        } catch (Exception e) {
        }
        return null;
    }

    /**
     * 获取密钥
     *
     * @param token
     * @return
     */
    public static String getSecret(String token) {
        try {
            String[] arr = token.split("\\" + TOKEN_SEPARATOR);
            ByteBuffer buf = ByteBuffer.wrap(Base64.decodeBase64(arr[0]));
            buf.getLong();
            byte[] data = new byte[buf.getInt()];
            buf.get(data);
            return new String(data);
        } catch (Exception e) {
        }
        return null;
    }

    /**
     * 构建密钥
     *
     * @param secret
     * @return
     */
    private static String buildSecret(String secret) {
        try {
            int size = secret.getBytes().length;
            ByteBuffer buf = ByteBuffer.allocate(size + 12);
            buf.putLong(System.currentTimeMillis());
            buf.putInt(size);
            buf.put(secret.getBytes());
            return Base64.encodeBase64String(buf.array());
        } catch (Exception e) {
        }
        return null;
    }

    /**
     * 构建JWT令牌
     *
     * @param userId
     * @param secret
     * @param timeoutSeconds
     * @return
     */
    private static String buildToken(String userId, String secret, long timeoutSeconds) {
        Date expiresAt = new Date(System.currentTimeMillis() + timeoutSeconds * 1000L);
        JWTCreator.Builder builder = JWT.create().withExpiresAt(expiresAt).withClaim(USER, userId);
        return builder.sign(Algorithm.HMAC256(secret));
    }

    /**
     * 解析JWT令牌
     *
     * @param token
     * @param secret
     * @return
     */
    private static String parseToken(String token, String secret) {
        try {
            JWTVerifier verifier = JWT.require(Algorithm.HMAC256(secret)).build();
            DecodedJWT jwt = verifier.verify(token);
            return jwt.getClaims().get(USER).asString();
        } catch (Exception e) {
            return null;
        }
    }

}
