package com.cloud.vaxservice.constant;

import lombok.Getter;

public enum TaskTypeEnum {
    VIDEO_DOWNLOAD(1, "视频下载"),
    TEXT_EXTRACT(2, "文字提取"),
    ERASE_WATERMARK(3, "去除水印"),
    VIDEO_COMPRESS(4, "视频压缩");

    @Getter
    private int code;

    @Getter
    private String name;

    TaskTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public static TaskTypeEnum of(Integer code) {
        if (code != null) {
            for (TaskTypeEnum codeEnum : values()) {
                if (codeEnum.code == code.intValue()) {
                    return codeEnum;
                }
            }
        }
        return null;
    }
}
