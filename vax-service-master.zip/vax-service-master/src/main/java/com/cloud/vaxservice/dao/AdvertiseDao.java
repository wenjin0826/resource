package com.cloud.vaxservice.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.vaxservice.entity.Advertise;

/**
 * 广告数据访问
 *
 * @author feng
 * @since 2022/06/13
 */
public interface AdvertiseDao extends BaseMapper<Advertise> {
}