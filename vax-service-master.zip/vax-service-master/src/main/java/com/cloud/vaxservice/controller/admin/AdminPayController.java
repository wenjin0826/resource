package com.cloud.vaxservice.controller.admin;

import com.cloud.vaxservice.dto.PayQueryParamDTO;
import com.cloud.vaxservice.dto.PaymentDTO;
import com.cloud.vaxservice.entity.Payment;
import com.cloud.vaxservice.service.PaymentService;
import com.cloud.common.bean.PageInfo;
import com.cloud.common.bean.ResultInfo;
import com.cloud.common.util.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * 支付接口
 */
@Slf4j
@RestController
public class AdminPayController {
    @Autowired
    private PaymentService paymentService;

    /**
     * 分页查询支付数据
     *
     * @param paramDTO 参数对象
     * @return ResultInfo
     */
    @PostMapping("/admin/pay/query")
    public ResultInfo<PageInfo<PaymentDTO>> query(@Valid @RequestBody PayQueryParamDTO paramDTO) {
        PageInfo<Payment> pageInfo = paymentService.query(paramDTO);
        List<PaymentDTO> list = ObjectUtils.copy(pageInfo.getRows(), PaymentDTO.class);
        return ResultInfo.success().setData(pageInfo.build(list));
    }
}

